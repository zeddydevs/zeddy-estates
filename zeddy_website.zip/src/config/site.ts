/**
 * Central site configuration.
 * Change the values below once and they update the whole website
 * (header, footer, contact page, SEO tags, sitemap and structured data).
 */
export const SITE = {
  name: "Zeddy Real Estates Company Limited",
  shortName: "Zeddy",
  tagline: "Your Property. Our Priority.",
  /** Your live domain – used for canonical URLs, Open Graph and sitemap.xml (no trailing slash) */
  url: "https://zeddyrealestates.co.ke", // Updated without www
  locale: "en_KE",
  description:
    "Zeddy Real Estates lists verified land, houses, apartments and commercial property for sale and rent in Kisumu, Kenya. Your Property. Our Priority.",

  phone: "+254703287361",
  phoneDisplay: "0703 287 361",
  whatsappNumber: "254703287361",
  email: "info@zeddyrealestates.co.ke",

  address: {
    street: "Kisumu, Kenya",
    locality: "Kisumu",
    region: "Kisumu County",
    country: "KE",
    countryName: "Kenya",
  },
  geo: { lat: -0.0917, lng: 34.7679 },

  hours: [
    { days: "Monday – Friday", time: "8:00 AM – 6:00 PM" },
    { days: "Saturday", time: "8:00 AM – 5:00 PM" },
    { days: "Sunday", time: "By appointment" },
  ],

  defaultOgImage:
    "/banner_home.jpeg",

  /** Footer credit */
  developer: {
    name: "INFINITY254",
    url: "https://www.infinity254.co.ke",
    display: "INFINITY254",
    color: "#ff4d00",
  },
} as const;

export const NAV_LINKS = [
  { label: "Home", to: "/" },
  { label: "Properties", to: "/properties" },
  { label: "About Us", to: "/about" },
  { label: "Blog", to: "/blog" },
  { label: "Contact", to: "/contact" },
] as const;