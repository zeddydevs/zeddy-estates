export interface Faq {
  q: string;
  a: string;
}

export const faqs: Faq[] = [
  {
    q: "How do I book a site visit?",
    a: "Call or WhatsApp us on 0703 287 361, or fill in the enquiry form on any property page. Tell us which property you are interested in and your preferred date, and we will confirm a time and meet you on site.",
  },
  {
    q: "Which areas do you cover?",
    a: "We focus on Kisumu city and its surrounding neighbourhoods, including Milimani, Riat, Nyamasaria, Dunga, Gambogi, Kondele and the CBD. If you are looking in a specific area, let us know and we will help you find options.",
  },
  {
    q: "Should I carry out due diligence before buying?",
    a: "Absolutely. We encourage every buyer to conduct an official search, confirm ownership and boundaries with a licensed surveyor and work with a qualified advocate. We are happy to share the documents we hold for a listing and guide you through the process.",
  },
  {
    q: "Some listings say 'Price on Request'. How do I get the price?",
    a: "Simply call, WhatsApp or email us and mention the property name or reference number. Our team will share the asking price and any available payment options.",
  },
  {
    q: "Can I pay in instalments?",
    a: "Payment terms depend on the property and the seller. Some listings may allow flexible payment plans – ask us about the specific property and we will confirm what is available.",
  },
  {
    q: "Can I list my property with Zeddy Real Estates?",
    a: "Yes. If you want to sell or rent out land, a house, an apartment or a commercial building, contact us with a few details and photos. We will help you price, present and market it.",
  },
];
