export type IconKey =
  | "building"
  | "home"
  | "droplets"
  | "toilet"
  | "bricks"
  | "expand"
  | "shield"
  | "trending"
  | "cash"
  | "hotel"
  | "store"
  | "school"
  | "route"
  | "bed"
  | "bath"
  | "car"
  | "zap"
  | "wifi"
  | "cctv"
  | "fence"
  | "trees"
  | "lock"
  | "key"
  | "file"
  | "sofa"
  | "utensils"
  | "waves"
  | "sun"
  | "compass"
  | "layers"
  | "warehouse"
  | "landmark"
  | "pin"
  | "ruler"
  | "users"
  | "mountain"
  | "check";

export type PropertyStatus = "For Sale" | "For Rent";
export type PropertyType = "Land" | "House" | "Apartment" | "Commercial";

export interface PropertyImage {
  src: string;
  alt: string;
}

export interface PropertyFeature {
  icon: IconKey;
  title: string;
  detail?: string;
}

export interface Property {
  id: string;
  slug: string;
  title: string;
  status: PropertyStatus;
  type: PropertyType;
  /** null = price on request */
  price: number | null;
  pricePeriod?: "month";
  priceNote?: string;

  location: string;
  area: string;
  address: string;
  mapQuery: string;

  landSize: string;
  floorArea?: string;
  bedrooms?: number;
  bathrooms?: number;
  parking?: number;
  floors?: number;
  condition: string;

  summary: string;
  description: string[];
  highlights: PropertyFeature[];
  amenities: string[];
  idealFor: { icon: IconKey; label: string }[];
  whyInvest: string[];
  images: PropertyImage[];

  featured: boolean;
  badge?: string;
  datePosted: string;
  tags: string[];
}

export type BlogBlock =
  | { type: "p"; text: string }
  | { type: "h2"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] }
  | { type: "callout"; title: string; text: string };

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
  imageAlt: string;
  tags: string[];
  content: BlogBlock[];
}
