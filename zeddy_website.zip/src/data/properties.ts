import type { Property } from "./types";

/**
 * Serves any file from public/images (any name, any extension).
 *   img("gambogi-front.webp")   ->  /images/gambogi-front.webp
 *   img("gambogi/front.avif")   ->  /images/gambogi/front.avif
 */
export const img = (file: string) => `/images/${encodeURI(file)}`;

/**
 * Builds an image list from a folder inside public/images.
 *   gallery("gambogi", [{ file: "front.jpg", alt: "..." }])
 */
export const gallery = (folder: string, files: { file: string; alt: string }[]) =>
  files.map(({ file, alt }) => ({ src: img(`${folder}/${file}`), alt }));

/** Legacy helper, kept so any file that still imports `px` doesn't crash. Prefer img(). */
export const px = (slug: string, index: number, ext: string = "jpeg") =>
  img(`${slug}-${index}.${ext}`);

/* Filename prefixes of your current images (change the filenames below to anything you like) */
const GAMBOGI = "gambogi";
const MILIMANI = "milimani";
const RIAT = "riat";
const NYAMASARIA = "nyamasaria";
const DUNGA = "dunga";
const CBD = "cbd";

export const properties: Property[] = [
  /* ------------------------------------------------------------------ */
  /* 1. Gambogi                                                         */
  /* ------------------------------------------------------------------ */
  {
    id: "ZRE-001",
    slug: "prime-half-acre-plot-3-storey-building-gambogi-kisumu",
    title: "Prime Half-Acre Plot with 3-Storey Building Under Construction",
    status: "For Sale",
    type: "Commercial",
    price: null,
    priceNote: "Call 0703 287 361 for the asking price",
    location: "Gambogi Township",
    area: "Gambogi, Kisumu",
    address: "Gambogi Township, next to Tigoi National School, Kisumu, Kenya",
    mapQuery: "Tigoi National School, Gambogi, Kisumu, Kenya",
    landSize: "Slightly over ½ acre",
    floorArea: "3-storey structure",
    floors: 3,
    condition: "Under construction – everything brand new",
    summary:
      "Slightly over ½ an acre in Gambogi Township, second plot from the tarmac and next to Tigoi National School, with a 3-storey building under construction, a brand-new site house, septic tank and 5,000-litre water tank already in place.",
    description: [
      "Great location. Great investment. Endless possibilities. This prime property sits in Gambogi Township right next to Tigoi National School and is only the second plot from the tarmac road, giving you easy, all-weather access in a secure and rapidly developing neighbourhood.",
      "The plot measures slightly over half an acre and already carries a 3-storey building under construction – the heavy lifting is done and the project is ready for completion. A brand-new site house, a fully constructed septic tank and a 5,000-litre POA water tank are all in place, and building materials are available on site so work can continue without delay.",
      "There is ample room left in the compound for expansion, making this an ideal opportunity for apartments and rental units, a hotel or Airbnb development, a commercial complex, an institution, or a residential home. Book a site visit today and see the potential for yourself.",
    ],
    highlights: [
      { icon: "building", title: "3-storey building", detail: "Under construction" },
      { icon: "home", title: "Brand-new site house", detail: "Ready for use by caretaker or site team" },
      { icon: "toilet", title: "Fully constructed septic tank" },
      { icon: "droplets", title: "5,000-litre POA water tank" },
      { icon: "bricks", title: "All materials available on site" },
      { icon: "expand", title: "Ample room for expansion", detail: "Spacious compound" },
    ],
    amenities: [
      "Second plot from the tarmac road",
      "Next to Tigoi National School",
      "Secure neighbourhood",
      "Brand-new site house",
      "Septic tank constructed",
      "5,000-litre water tank installed",
      "Building materials on site",
      "Space for extra units or parking",
    ],
    idealFor: [
      { icon: "building", label: "Apartments & rental units" },
      { icon: "hotel", label: "Hotel or Airbnb development" },
      { icon: "store", label: "Commercial complex" },
      { icon: "home", label: "Institution or residential home" },
    ],
    whyInvest: [
      "Excellent location next to Tigoi National School",
      "Second plot from the tarmac with easy access",
      "Ideal for residential, rental, commercial or institutional development",
      "High growth potential in a secure neighbourhood",
    ],
    images: [
      { src: img(`${GAMBOGI}-1.jfif`), alt: "3-storey building under construction on a half-acre plot in Gambogi Township, Kisumu" },
      
    ],
    featured: true,
    badge: "Slightly over ½ acre",
    datePosted: "2026-01-12",
    tags: ["Gambogi", "Tigoi", "Half acre", "Under construction", "Investment"],
  },

  /* ------------------------------------------------------------------ */
  /* 2. Milimani maisonette                                             */
  /* ------------------------------------------------------------------ */
  {
    id: "ZRE-002",
    slug: "4-bedroom-maisonette-for-sale-milimani-kisumu",
    title: "Executive 4-Bedroom Maisonette in Milimani",
    status: "For Sale",
    type: "House",
    price: 28500000,
    location: "Milimani",
    area: "Milimani, Kisumu",
    address: "Milimani Estate, Kisumu, Kenya",
    mapQuery: "Milimani, Kisumu, Kenya",
    landSize: "¼ acre",
    floorArea: "3,200 sq ft",
    bedrooms: 4,
    bathrooms: 4,
    parking: 3,
    floors: 2,
    condition: "Newly built",
    summary:
      "A beautifully finished 4-bedroom maisonette with a DSQ, landscaped garden and 24-hour security in Kisumu's sought-after Milimani neighbourhood.",
    description: [
      "Set in one of Kisumu's most established residential neighbourhoods, this executive maisonette combines modern design with everyday practicality. The open-plan living and dining area flows into a fully fitted kitchen and out onto a private, landscaped garden – perfect for family gatherings.",
      "Upstairs, four generously sized bedrooms each enjoy built-in wardrobes and natural light, with the master suite featuring a walk-in dressing area and a private bathroom. A separate domestic staff quarter (DSQ) and covered parking for three vehicles complete the package.",
      "The home sits within a gated, secure compound with an electric fence, CCTV and a borehole backup, so you never worry about water. Close to hospitals, schools, supermarkets and the CBD.",
    ],
    highlights: [
      { icon: "bed", title: "4 bedrooms", detail: "All with fitted wardrobes" },
      { icon: "bath", title: "4 bathrooms", detail: "Master ensuite" },
      { icon: "car", title: "Parking for 3 cars", detail: "Covered" },
      { icon: "sofa", title: "Open-plan living", detail: "Living and dining" },
      { icon: "utensils", title: "Modern fitted kitchen" },
      { icon: "trees", title: "Landscaped garden" },
    ],
    amenities: [
      "Domestic staff quarter (DSQ)",
      "Borehole water backup",
      "Electric fence & CCTV",
      "Gated community",
      "Backup generator connection",
      "Fibre internet ready",
      "Ample visitor parking",
      "Near schools & hospitals",
    ],
    idealFor: [
      { icon: "home", label: "Growing families" },
      { icon: "users", label: "Executives & professionals" },
      { icon: "trending", label: "Long-term investment" },
    ],
    whyInvest: [
      "Prime, established neighbourhood with strong resale demand",
      "Modern finish – move in without renovation costs",
      "Secure gated compound with water and power backup",
    ],
    images: [
      { src: img(`${MILIMANI}-1.jfif`), alt: "Exterior of a modern 4-bedroom maisonette with a green yard in Milimani, Kisumu" },
      
    ],
    featured: true,
    badge: "New Listing",
    datePosted: "2026-01-20",
    tags: ["Milimani", "Maisonette", "Gated", "DSQ"],
  },

  /* ------------------------------------------------------------------ */
  /* 3. Riat Hills plots                                                */
  /* ------------------------------------------------------------------ */
  {
    id: "ZRE-003",
    slug: "residential-plots-for-sale-riat-hills-kisumu",
    title: "Residential Plots with Ready Title Deeds – Riat Hills",
    status: "For Sale",
    type: "Land",
    price: 1800000,
    priceNote: "Starting price per 50×100 ft plot",
    location: "Riat Hills",
    area: "Riat, Kisumu",
    address: "Riat Hills, Kisumu, Kenya",
    mapQuery: "Riat Hills, Kisumu, Kenya",
    landSize: "50 × 100 ft (⅛ acre)",
    condition: "Vacant land – ready title",
    summary:
      "Affordable 50×100 ft residential plots on the Riat Hills side of Kisumu with ready title deeds, access roads and breathtaking views over the city and the lake.",
    description: [
      "Riat Hills continues to attract homeowners looking for cool breezes, open skies and panoramic views over Kisumu city and Lake Victoria. These ⅛-acre plots are neatly surveyed, beaconed and ready for you to start building.",
      "Each plot comes with a ready title deed, so you can complete the transfer quickly and start construction with confidence. Murram access roads, nearby electricity and piped/borehole water options make development straightforward.",
      "Whether you want to build your forever home, a rental block or simply bank land for the future, Riat Hills plots offer one of the best entry points into Kisumu's property market. Flexible viewing days are available.",
    ],
    highlights: [
      { icon: "ruler", title: "50 × 100 ft", detail: "Standard ⅛ acre plots" },
      { icon: "file", title: "Ready title deeds" },
      { icon: "mountain", title: "Hill-top views", detail: "City and lake views" },
      { icon: "route", title: "Access roads", detail: "Murram, all-season" },
      { icon: "zap", title: "Electricity nearby" },
      { icon: "droplets", title: "Water options", detail: "Borehole or piped" },
    ],
    amenities: [
      "Surveyed and beaconed plots",
      "Ready title deeds",
      "Cool, scenic neighbourhood",
      "Access roads in place",
      "Electricity nearby",
      "Close to schools and shopping centres",
      "Flexible viewing days",
      "Payment plans can be discussed",
    ],
    idealFor: [
      { icon: "home", label: "Build your own home" },
      { icon: "building", label: "Rental units" },
      { icon: "trending", label: "Land banking" },
    ],
    whyInvest: [
      "Affordable entry price with strong appreciation potential",
      "Ready title – faster transfer and peace of mind",
      "Scenic, cool location that suits residential living",
    ],
    images: [
      { src: img(`${RIAT}-1.jfif`), alt: "Expansive green plots with trees on the horizon at Riat Hills, Kisumu" },
      
    ],
    featured: true,
    badge: "Title Ready",
    datePosted: "2025-12-18",
    tags: ["Riat", "Plots", "Title deed", "Land"],
  },

  /* ------------------------------------------------------------------ */
  /* 4. Nyamasaria apartments (rent)                                    */
  /* ------------------------------------------------------------------ */
  {
    id: "ZRE-004",
    slug: "2-bedroom-apartment-for-rent-nyamasaria-kisumu",
    title: "Modern 2-Bedroom Apartment to Let in Nyamasaria",
    status: "For Rent",
    type: "Apartment",
    price: 35000,
    pricePeriod: "month",
    location: "Nyamasaria",
    area: "Nyamasaria, Kisumu",
    address: "Nyamasaria, Kisumu, Kenya",
    mapQuery: "Nyamasaria, Kisumu, Kenya",
    landSize: "Apartment block",
    floorArea: "950 sq ft",
    bedrooms: 2,
    bathrooms: 2,
    parking: 1,
    floors: 4,
    condition: "Newly built",
    summary:
      "Spacious 2-bedroom apartment with a balcony, ensuite master, ample parking and 24-hour security in a modern block in Nyamasaria.",
    description: [
      "Enjoy comfortable, low-maintenance living in this modern 2-bedroom apartment in Nyamasaria. The bright open-plan lounge and kitchen lead out to a private balcony, and both bedrooms come with fitted wardrobes – the master bedroom is ensuite.",
      "The block offers reliable water supply with a backup tank, secure gated parking, CCTV monitoring and a 24-hour guard. Fibre internet is available in the building, making it a great fit for professionals working from home.",
      "Located close to the airport road, supermarkets, schools and public transport, so your daily commute and errands are quick and easy. Viewings are available any day by appointment.",
    ],
    highlights: [
      { icon: "bed", title: "2 bedrooms", detail: "Master ensuite" },
      { icon: "bath", title: "2 bathrooms" },
      { icon: "layers", title: "Private balcony" },
      { icon: "car", title: "Secure parking" },
      { icon: "wifi", title: "Fibre-ready" },
      { icon: "cctv", title: "CCTV & 24/7 guard" },
    ],
    amenities: [
      "Backup water tank",
      "Fitted wardrobes",
      "Modern fitted kitchen",
      "Balcony",
      "Gated compound",
      "CCTV surveillance",
      "Visitor parking",
      "Close to main road",
    ],
    idealFor: [
      { icon: "users", label: "Young families" },
      { icon: "key", label: "Working professionals" },
      { icon: "home", label: "Couples" },
    ],
    whyInvest: [
      "Affordable monthly rent for a modern finish",
      "Great location with easy access to town and the airport road",
      "Secure, well-managed block",
    ],
    images: [
      { src: img(`${NYAMASARIA}-1.jfif`), alt: "Modern apartment building exterior with balconies in Nyamasaria, Kisumu" },
      
    ],
    featured: true,
    badge: "Available Now",
    datePosted: "2026-01-05",
    tags: ["Nyamasaria", "Apartment", "To let", "Balcony"],
  },

  /* ------------------------------------------------------------------ */
  /* 5. Dunga lakeview bungalow                                         */
  /* ------------------------------------------------------------------ */
  {
    id: "ZRE-005",
    slug: "3-bedroom-lakeview-bungalow-for-sale-dunga-kisumu",
    title: "3-Bedroom Lakeview Bungalow in Dunga",
    status: "For Sale",
    type: "House",
    price: 14800000,
    location: "Dunga",
    area: "Dunga, Kisumu",
    address: "Dunga, Lake Victoria shoreline, Kisumu, Kenya",
    mapQuery: "Dunga Beach, Kisumu, Kenya",
    landSize: "⅛ acre",
    floorArea: "1,900 sq ft",
    bedrooms: 3,
    bathrooms: 3,
    parking: 2,
    floors: 1,
    condition: "Well maintained",
    summary:
      "A peaceful 3-bedroom bungalow close to the Dunga shoreline with lake breezes, a mature garden, a veranda and room for an extension.",
    description: [
      "Wake up to cool lake breezes and golden sunsets in this charming bungalow near the Dunga shoreline. The home offers a bright lounge, separate dining room, three spacious bedrooms (master ensuite) and a covered veranda ideal for evenings outdoors.",
      "The mature, fully fenced garden is perfect for children, pets and entertaining, and there is space within the compound for a future extension or a guest cottage. Parking for two vehicles and a borehole make day-to-day living convenient.",
      "Dunga is known for its relaxed pace, fresh fish and lakeside leisure – and it is just a short drive to the CBD. A great choice for a family home, a weekend retreat, or a short-stay rental investment.",
    ],
    highlights: [
      { icon: "bed", title: "3 bedrooms", detail: "Master ensuite" },
      { icon: "bath", title: "3 bathrooms" },
      { icon: "waves", title: "Near the lake", detail: "Cool lake breezes" },
      { icon: "trees", title: "Mature garden", detail: "Fully fenced" },
      { icon: "car", title: "Parking for 2 cars" },
      { icon: "expand", title: "Room to extend" },
    ],
    amenities: [
      "Covered veranda",
      "Borehole water",
      "Perimeter wall & gate",
      "Separate dining room",
      "Fitted kitchen",
      "Tiled floors",
      "Near Dunga Beach",
      "Quiet neighbourhood",
    ],
    idealFor: [
      { icon: "home", label: "Family home" },
      { icon: "hotel", label: "Short-stay / Airbnb" },
      { icon: "sun", label: "Lakeside retreat" },
    ],
    whyInvest: [
      "Lakeside lifestyle at an accessible price",
      "Strong tourism and short-stay potential",
      "Extra space for future expansion",
    ],
    images: [
      { src: img(`${DUNGA}-1.jfif`), alt: "Charming bungalow by the lake with blooming trees near Dunga, Kisumu" },
      
    ],
    featured: false,
    badge: "Lake View",
    datePosted: "2025-12-02",
    tags: ["Dunga", "Lake Victoria", "Bungalow", "Airbnb"],
  },

  /* ------------------------------------------------------------------ */
  /* 6. Kisumu CBD commercial space (rent)                              */
  /* ------------------------------------------------------------------ */
  {
    id: "ZRE-006",
    slug: "commercial-space-for-rent-kisumu-cbd",
    title: "Prime Commercial Space to Let in Kisumu CBD",
    status: "For Rent",
    type: "Commercial",
    price: 150000,
    pricePeriod: "month",
    location: "Kisumu CBD",
    area: "CBD, Kisumu",
    address: "Oginga Odinga Street, Kisumu CBD, Kenya",
    mapQuery: "Oginga Odinga Street, Kisumu, Kenya",
    landSize: "Commercial building",
    floorArea: "2,400 sq ft",
    bathrooms: 4,
    parking: 6,
    floors: 3,
    condition: "Ready for occupation",
    summary:
      "2,400 sq ft of open-plan commercial space in the heart of Kisumu CBD with a lift, backup power, ample parking and high foot traffic.",
    description: [
      "Put your business where the customers are. This commercial space is in the heart of Kisumu CBD, with excellent street visibility and constant foot traffic – ideal for banks, SACCOs, clinics, boutiques, training centres and corporate offices.",
      "The open-plan floor can be partitioned to your needs, and the building provides a passenger lift, backup generator, ample parking and four washrooms. Fibre connectivity and 24-hour security are available.",
      "Flexible lease terms are available for serious tenants. Contact us to arrange a viewing and discuss your fit-out requirements.",
    ],
    highlights: [
      { icon: "ruler", title: "2,400 sq ft", detail: "Open-plan floor" },
      { icon: "building", title: "3-storey building" },
      { icon: "layers", title: "Passenger lift" },
      { icon: "zap", title: "Backup generator" },
      { icon: "car", title: "Parking for 6+ cars" },
      { icon: "wifi", title: "Fibre connectivity" },
    ],
    amenities: [
      "High foot traffic location",
      "Ground-floor signage opportunity",
      "24-hour security & CCTV",
      "Backup water supply",
      "4 washrooms",
      "Easy access to matatu stages",
      "Near banks and government offices",
      "Flexible lease terms",
    ],
    idealFor: [
      { icon: "landmark", label: "Banks & SACCOs" },
      { icon: "store", label: "Retail & showrooms" },
      { icon: "users", label: "Corporate offices" },
    ],
    whyInvest: [
      "Central position in the region's commercial hub",
      "Modern amenities that reduce your running costs",
      "Flexible layout to match your brand",
    ],
    images: [
      { src: img(`${CBD}-1.jfif`), alt: "Modern commercial office building facade in Kisumu CBD" },
     
    ],
    featured: false,
    badge: "Prime Location",
    datePosted: "2025-11-24",
    tags: ["CBD", "Commercial", "Office", "Retail"],
  },
];

export const propertyTypes: { type: Property["type"]; description: string }[] = [
  { type: "Land", description: "Residential & commercial plots" },
  { type: "House", description: "Maisonettes, bungalows & villas" },
  { type: "Apartment", description: "Modern flats to rent or buy" },
  { type: "Commercial", description: "Offices, shops & developments" },
];

export const getPropertyBySlug = (slug?: string) => properties.find((p) => p.slug === slug);