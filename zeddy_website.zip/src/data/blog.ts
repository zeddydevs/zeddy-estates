import type { BlogPost } from "./types";
import { img } from "./properties";

const AUTHOR = "Zeddy Real Estates";

export const blogPosts: BlogPost[] = [
  {
    slug: "how-to-buy-land-in-kisumu-step-by-step-guide",
    title: "How to Buy Land in Kisumu: A Step-by-Step Guide for First-Time Buyers",
    excerpt:
      "Buying land is one of the biggest decisions you will ever make. Follow this practical, step-by-step process to buy a plot in Kisumu safely and confidently.",
    category: "Buying Guide",
    author: AUTHOR,
    date: "2026-02-10",
    readTime: "7 min read",
    image: img("How to Buy Land in Kisumu.webp"),
    imageAlt: "Keys being handed over beside a home for sale sign",
    tags: ["Buying land", "Kisumu", "First-time buyer"],
    content: [
      {
        type: "p",
        text: "Kisumu's lakeside lifestyle, growing economy and improving infrastructure have made it one of the most exciting places in Kenya to own land. But buying a plot is not like buying a phone – it needs planning, paperwork and patience. This guide walks you through the process from budget to title.",
      },
      { type: "h2", text: "1. Set your budget and define your purpose" },
      {
        type: "p",
        text: "Decide what you want the land for: a family home, rental units, a commercial building, or simply to hold as an investment. Your purpose shapes the location, plot size and price you should target. Remember to budget beyond the purchase price – include legal fees, stamp duty, survey costs and the cost of fencing or developing the plot.",
      },
      { type: "h2", text: "2. Shortlist locations and view the plots" },
      {
        type: "p",
        text: "Visit several areas at different times of day. Check road access, distance to schools and hospitals, availability of water and electricity, and the character of the neighbourhood. Always view the physical plot with the seller or an agent, and ask to see the beacons.",
      },
      { type: "h2", text: "3. Carry out due diligence" },
      {
        type: "ul",
        items: [
          "Request a copy of the title deed and the seller's ID and KRA PIN.",
          "Conduct an official search at the lands registry (or through the Ardhisasa platform) to confirm ownership and check for caveats, charges or disputes.",
          "Confirm the land use and zoning with the county physical planning office.",
          "Ask for a land rates clearance certificate from the county government.",
          "Have a licensed surveyor confirm the boundaries and beacons on the ground.",
        ],
      },
      { type: "h2", text: "4. Negotiate and sign the sale agreement" },
      {
        type: "p",
        text: "Once you are satisfied, agree on the price and payment terms. Your advocate should draft or review the sale agreement. Pay the deposit through a traceable channel – bank transfer or the advocate's client account – and never pay cash to an individual without documentation.",
      },
      { type: "h2", text: "5. Obtain consents and complete the transfer" },
      {
        type: "p",
        text: "For agricultural land, Land Control Board consent is required before the transfer. Your advocate will then prepare the transfer documents, pay stamp duty (typically 4% of the value in urban areas and 2% in rural areas) and lodge everything at the land registry for registration in your name.",
      },
      {
        type: "callout",
        title: "Our advice",
        text: "Always involve a practising advocate from the start and never rush because of pressure from sellers. A genuine plot will still be there after you have done your checks. This article is for general information only and is not legal advice.",
      },
      {
        type: "p",
        text: "Looking for a verified plot in Kisumu? Browse our listings or contact Zeddy Real Estates and we will arrange a guided site visit for you.",
      },
    ],
  },
  {
    slug: "why-kisumu-is-a-fast-growing-property-market",
    title: "Why Kisumu Is One of East Africa's Fastest-Growing Property Markets",
    excerpt:
      "From the lakefront to the hills, Kisumu is attracting investors, families and businesses. Here is what is driving demand and where the opportunities are.",
    category: "Market Insights",
    author: AUTHOR,
    date: "2026-01-28",
    readTime: "5 min read",
    image: img("kisumu.avif"),
    imageAlt: "Floating fish cages on Lake Victoria near Kisumu",
    tags: ["Kisumu", "Market", "Investment"],
    content: [
      {
        type: "p",
        text: "Kisumu – Kenya's third-largest city and the commercial heart of the western region – sits on the shores of Lake Victoria and acts as a gateway to the wider Lake Region and neighbouring countries. That position has turned it into one of the most talked-about property destinations in the country.",
      },
      { type: "h2", text: "What is driving demand?" },
      {
        type: "ul",
        items: [
          "Lake Victoria economy: fishing, trade, tourism and the blue economy bring steady business activity.",
          "Education and healthcare: universities, colleges and referral hospitals attract students, staff and medical professionals who need housing.",
          "Connectivity: improved roads, the airport and regional trade links make Kisumu easier to reach and do business from.",
          "Lifestyle: warm weather, lake views and a relaxed pace of life appeal to families and returning diaspora.",
        ],
      },
      { type: "h2", text: "Neighbourhoods to watch" },
      {
        type: "p",
        text: "Established areas such as Milimani remain popular for executive homes, while Nyamasaria, Kondele and Kisumu CBD see strong demand for rental apartments and commercial space. Hill-top areas such as Riat offer cool breezes, views and affordable plots, and townships such as Gambogi are drawing developers looking for land close to the tarmac with room to build.",
      },
      { type: "h2", text: "Where are the opportunities?" },
      {
        type: "p",
        text: "Affordable residential plots for owner-occupiers, rental apartments for young professionals and students, short-stay accommodation near the lakeshore, and small commercial buildings along growing roads all offer attractive potential. As with any market, success comes from choosing the right location, verifying documents and buying at a fair price.",
      },
      {
        type: "callout",
        title: "Tip",
        text: "Visit the area, speak to neighbours and compare at least three similar properties before you commit. Local knowledge is worth its weight in gold.",
      },
    ],
  },
  
  {
    slug: "how-to-prepare-your-property-for-sale",
    title: "How to Prepare Your Property for Sale: 8 Tips to Sell Faster and for More",
    excerpt:
      "First impressions matter. These practical steps help your home or plot stand out and attract serious buyers quickly.",
    category: "Selling Tips",
    author: AUTHOR,
    date: "2025-12-08",
    readTime: "5 min read",
    image: img("gambogi-1.jpeg"),
    imageAlt: "Realtor holding a keychain and clipboard in an office",
    tags: ["Selling", "Home staging", "Tips"],
    content: [
      {
        type: "p",
        text: "Whether you are selling a home, an apartment or a plot, how you present the property can make a real difference to the price and the time it takes to close. Try these tips before you list.",
      },
      {
        type: "ol",
        items: [
          "Price it right. Compare similar properties in your area; overpricing keeps buyers away, while a fair price attracts offers.",
          "Gather your documents early. Title deed, rates clearance, approved plans and receipts show buyers you are serious and speed up the transaction.",
          "Clear and clean. Remove clutter, cut grass, clear debris on plots and give the property a deep clean.",
          "Fix the small things. Leaking taps, cracked tiles and faulty locks give buyers reasons to negotiate down.",
          "Freshen up with paint. A fresh coat of neutral paint is one of the cheapest ways to add perceived value.",
          "Boost curb appeal. Tidy the gate, fence and landscaping so the first view is a good one.",
          "Take quality photos. Bright, wide, uncluttered photos in daylight get far more enquiries than dark phone snaps.",
          "Work with a trusted agent. A good agent markets your property widely, screens buyers and manages viewings and negotiations.",
        ],
      },
      {
        type: "callout",
        title: "Selling with Zeddy",
        text: "Want your property listed on our website? Call or WhatsApp 0703 287 361 and our team will help you present and market it professionally.",
      },
    ],
  },
  
];

export const blogCategories = Array.from(new Set(blogPosts.map((p) => p.category)));

export const getPostBySlug = (slug?: string) => blogPosts.find((p) => p.slug === slug);