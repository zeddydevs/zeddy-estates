import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Download, FileCode2, FileText, Map } from "lucide-react";
import { Container, PageHero } from "@/components/ui";
import { NAV_LINKS } from "@/config/site";
import { useSeo } from "@/seo/useSeo";
import { sitemapPageMeta } from "@/seo/meta";

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-neutral-200 bg-white p-7">
      <h2 className="text-xl font-extrabold text-ink">{title}</h2>
      <ul className="mt-4 space-y-2.5 text-[15.5px]">{children}</ul>
    </div>
  );
}

const linkCls = "font-semibold text-brand-700 underline-offset-4 hover:underline";

export default function SitemapPage() {
  useSeo(sitemapPageMeta());

  const [properties, setProperties] = useState<any[]>([]);
  const [blogPosts, setBlogPosts] = useState<any[]>([]);

  // Fetch properties and blog posts client-side
  useEffect(() => {
    // Load your list data from your API or mock store here
  }, []);

  return (
    <>
      <PageHero
        title="Sitemap"
        subtitle="Every page of the Zeddy Real Estates website in one place."
        breadcrumbs={[{ label: "Home", to: "/" }, { label: "Sitemap" }]}
      />

      <section className="bg-sand py-14 sm:py-20">
        <Container>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Group title="Main Pages">
              {NAV_LINKS.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className={linkCls}>
                    {l.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link to="/saved" className={linkCls}>
                  Saved Properties
                </Link>
              </li>
              <li>
                <Link to="/sitemap" className={linkCls}>
                  Sitemap
                </Link>
              </li>
            </Group>

            <Group title="Properties">
              <li>
                <Link to="/properties" className={linkCls}>
                  All Properties
                </Link>
              </li>
              {properties.map((p) => (
                <li key={p.id}>
                  <Link to={`/properties/${p.slug}`} className={linkCls}>
                    {p.title}
                  </Link>
                </li>
              ))}
            </Group>

            <Group title="Blog">
              <li>
                <Link to="/blog" className={linkCls}>
                  All Articles
                </Link>
              </li>
              {blogPosts.map((b) => (
                <li key={b.slug}>
                  <Link to={`/blog/${b.slug}`} className={linkCls}>
                    {b.title}
                  </Link>
                </li>
              ))}
            </Group>

            <Group title="Browse by Category">
              {["Land", "House", "Apartment", "Commercial"].map((t) => (
                <li key={t}>
                  <Link to={`/properties?type=${t}`} className={linkCls}>
                    {t} listings
                  </Link>
                </li>
              ))}
              <li>
                <Link to="/properties?status=For%20Sale" className={linkCls}>
                  Properties for sale
                </Link>
              </li>
              <li>
                <Link to="/properties?status=For%20Rent" className={linkCls}>
                  Properties for rent
                </Link>
              </li>
            </Group>

            <Group title="For Search Engines">
              <li className="flex items-center gap-2">
                <a href="/sitemap.xml" className={linkCls}>
                  sitemap.xml
                </a>
              </li>
              <li className="flex items-center gap-2">
                <FileText size={16} className="text-brand-600" aria-hidden="true" />
                <a href="/robots.txt" className={linkCls}>
                  robots.txt
                </a>
              </li>
            </Group>

            <div className="rounded-xl bg-brand-900 p-7 text-white">
              <FileCode2 size={32} className="text-accent-400" aria-hidden="true" />
              <h2 className="mt-4 text-xl font-extrabold">Vite + React SPA Application</h2>
              <p className="mt-2 text-[15px] leading-relaxed text-white/80">
                Powered by Vite, React Router, PostgreSQL, and Drizzle ORM.
              </p>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}