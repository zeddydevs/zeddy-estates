import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import {
  Bath,
  BedDouble,
  Calendar,
  Car,
  CircleCheck,
  Hash,
  Layers,
  MapPin,
  Phone,
  Ruler,
  ShieldCheck,
  Tag,
  Trees,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { Breadcrumbs, Container, CtaBand, FavoriteButton, SectionHeading } from "@/components/ui";
import Gallery from "@/components/Gallery";
import Icon from "@/components/Icon";
import PropertyCard from "@/components/PropertyCard";
import EnquiryForm from "@/components/EnquiryForm";
import ShareButtons from "@/components/ShareButtons";
import WhatsAppIcon from "@/components/WhatsAppIcon";
import NotFound from "@/pages/NotFound";
import { SITE } from "@/config/site";
import { absoluteUrl, formatDate, formatPrice, telLink, waLink } from "@/lib/format";
import { useSeo } from "@/seo/useSeo";
import { propertyMeta } from "@/seo/meta";

export default function PropertyDetailPage() {
  const { slug } = useParams<{ slug: string }>();

  const [p, setP] = useState<any>(null);
  const [similar, setSimilar] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch property details and similar properties from backend API
  useEffect(() => {
    setLoading(true);
    fetch(`/api/properties/${slug}`)
      .then((res) => {
        if (!res.ok) throw new Error("Property not found");
        return res.json();
      })
      .then((data) => {
        // Normalize properties and arrays for safe rendering
        // Normalize properties and arrays for safe rendering
const normalized = {
  ...data,
  images: Array.isArray(data.images) && data.images.length > 0 
    ? data.images.map((img: any) => ({
        ...img,
        url: typeof img === 'string' ? img : img.url || img.src || "/images/banner.jfif",
        src: typeof img === 'string' ? img : img.src || img.url || "/images/banner.jfif",
        alt: img.alt || data.title || "Property image"
      }))
    : [{ url: "/images/banner.jfif", src: "/images/banner.jfif", alt: data.title || "Property image" }],
  description: typeof data.description === "string" 
    ? data.description.split("\n\n").filter(Boolean) 
    : Array.isArray(data.description) ? data.description : [data.description || ""],
  highlights: Array.isArray(data.highlights) ? data.highlights : [],
  amenities: Array.isArray(data.amenities) ? data.amenities : [],
  idealFor: Array.isArray(data.idealFor) ? data.idealFor : [],
  whyInvest: Array.isArray(data.whyInvest) ? data.whyInvest : [],
  address: data.address || data.location || "Kisumu, Kenya",
  landSize: data.landSize || "N/A",
  condition: data.condition || "Excellent",
};
        setP(normalized);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch property details:", err);
        setP(null);
        setLoading(false);
      });
  }, [slug]);

  useSeo(propertyMeta(p || {}));

  if (loading) {
    return <div className="py-20 text-center font-semibold text-neutral-500">Loading property details...</div>;
  }

  if (!p) {
    return <NotFound />;
  }

  const url = absoluteUrl(`/properties/${slug}`);
  const facts: { icon: LucideIcon; label: string; value: string }[] = [
    { icon: Tag, label: "Type", value: p.type },
    { icon: Ruler, label: p.type === "Land" ? "Land size" : "Plot / land size", value: p.landSize },
    ...(p.floorArea ? [{ icon: Layers, label: "Built-up area", value: p.floorArea }] : []),
    ...(p.bedrooms ? [{ icon: BedDouble, label: "Bedrooms", value: String(p.bedrooms) }] : []),
    ...(p.bathrooms ? [{ icon: Bath, label: "Bathrooms", value: String(p.bathrooms) }] : []),
    ...(p.parking ? [{ icon: Car, label: "Parking", value: `${p.parking} vehicles` }] : []),
    ...(p.floors ? [{ icon: Layers, label: "Floors", value: String(p.floors) }] : []),
    { icon: Wrench, label: "Condition", value: p.condition },
    { icon: Hash, label: "Reference", value: p.id },
    ...(p.datePosted ? [{ icon: Calendar, label: "Listed", value: formatDate(p.datePosted) }] : []),
  ];

  const enquiryText = `Hello ${SITE.name}, I am interested in "${p.title}" (Ref: ${p.id}). ${url}`;

  async function handlePropertyEnquiry(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get("name") as string;
    const phone = formData.get("phone") as string;
    const message = formData.get("message") as string;

    if (name && phone && message) {
      try {
        alert("Property enquiry sent successfully!");
      } catch (err) {
        console.error("Failed to submit enquiry", err);
      }
    }
  }

  return (
    <>
      <section className="border-b border-neutral-200 bg-white">
        <Container className="py-6">
          <Breadcrumbs
            items={[
              { label: "Home", to: "/" },
              { label: "Properties", to: "/properties" },
              { label: p.title },
            ]}
          />
        </Container>
      </section>

      <section className="py-8 sm:py-12">
        <Container>
          {/* Title row */}
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-3xl">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`rounded-md px-3 py-1.5 text-xs font-bold uppercase tracking-wide ${
                    p.status === "For Sale" ? "bg-brand-600 text-white" : "bg-accent-500 text-ink"
                  }`}
                >
                  {p.status}
                </span>
                <span className="rounded-md bg-neutral-100 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-ink">
                  {p.type}
                </span>
                {p.badge && (
                  <span className="rounded-md bg-ink px-3 py-1.5 text-xs font-bold text-white">{p.badge}</span>
                )}
              </div>
              <h1 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl">{p.title}</h1>
              <p className="mt-3 flex items-start gap-2 text-base text-neutral-600">
                <MapPin size={20} className="mt-0.5 shrink-0 text-brand-600" aria-hidden="true" />
                {p.address}
              </p>
            </div>

            <div className="flex items-center gap-4 lg:flex-col lg:items-end">
              <div className="lg:text-right">
                <p className="text-sm font-medium text-neutral-500">{p.price === null ? "Asking price" : p.status === "For Rent" ? "Rent" : "Price"}</p>
                <p className="font-display text-3xl font-extrabold text-brand-700 sm:text-4xl">{formatPrice(p)}</p>
                {p.priceNote && <p className="mt-1 text-sm text-neutral-500">{p.priceNote}</p>}
              </div>
              <FavoriteButton id={p.id} title={p.title} className="ml-auto !h-12 !w-12 lg:ml-0" />
            </div>
          </div>

          <div className="mt-8 grid gap-10 lg:grid-cols-3 lg:gap-12">
            {/* LEFT COLUMN */}
            <div className="min-w-0 space-y-12 lg:col-span-2">
              <Gallery images={p.images} />

              <ShareButtons url={url} title={p.title} />

              {/* Quick facts */}
              <section aria-labelledby="facts-heading">
                <h2 id="facts-heading" className="text-2xl font-extrabold text-ink">
                  Property Overview
                </h2>
                <dl className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {facts.map(({ icon: Ico, label, value }) => (
                    <div key={label} className="rounded-lg border border-neutral-200 bg-sand p-4">
                      <dt className="flex items-center gap-2 text-[13px] font-semibold text-neutral-500">
                        <Ico size={16} className="text-brand-600" aria-hidden="true" /> {label}
                      </dt>
                      <dd className="mt-1.5 text-[15px] font-bold leading-snug text-ink">{value}</dd>
                    </div>
                  ))}
                </dl>
              </section>

              {/* Description */}
              <section aria-labelledby="desc-heading">
                <h2 id="desc-heading" className="text-2xl font-extrabold text-ink">
                  Description
                </h2>
                <div className="mt-4 space-y-4 text-[16.5px] leading-[1.8] text-neutral-700">
                  {p.description.map((para: string, idx: number) => (
                    <p key={idx}>{para}</p>
                  ))}
                </div>
              </section>

              {/* Features */}
              {p.highlights.length > 0 && (
                <section aria-labelledby="features-heading">
                  <h2 id="features-heading" className="text-2xl font-extrabold text-ink">
                    Property Features
                  </h2>
                  <ul className="mt-5 grid gap-4 sm:grid-cols-2">
                    {p.highlights.map((h: any, idx: number) => (
                      <li key={idx} className="flex items-center gap-4 rounded-lg border border-neutral-200 bg-white p-4">
                        <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-brand-600 text-white">
                          <Icon name={h.icon} size={22} />
                        </span>
                        <span>
                          <span className="block text-[15px] font-bold leading-snug text-ink">{h.title}</span>
                          {h.detail && <span className="mt-0.5 block text-sm text-neutral-500">{h.detail}</span>}
                        </span>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {/* Amenities */}
              {p.amenities.length > 0 && (
                <section aria-labelledby="amen-heading">
                  <h2 id="amen-heading" className="text-2xl font-extrabold text-ink">
                    Amenities &amp; Highlights
                  </h2>
                  <ul className="mt-5 grid gap-x-8 gap-y-3 sm:grid-cols-2">
                    {p.amenities.map((a: string) => (
                      <li key={a} className="flex items-center gap-3 text-[15px] text-neutral-700">
                        <CircleCheck size={20} className="shrink-0 text-brand-600" aria-hidden="true" /> {a}
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {/* Ideal for */}
              {p.idealFor.length > 0 && (
                <section aria-labelledby="ideal-heading">
                  <h2 id="ideal-heading" className="text-2xl font-extrabold text-ink">
                    Ideal For
                  </h2>
                  <ul className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
                    {p.idealFor.map((i: any, idx: number) => (
                      <li
                        key={idx}
                        className="flex flex-col items-center rounded-lg border border-neutral-200 bg-sand p-5 text-center"
                      >
                        <span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-white text-brand-600">
                          <Icon name={i.icon} size={24} />
                        </span>
                        <span className="mt-3 text-sm font-bold leading-snug text-ink">{i.label}</span>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {/* Why invest */}
              {p.whyInvest.length > 0 && (
                <section aria-labelledby="invest-heading" className="rounded-xl bg-brand-900 p-7 text-white sm:p-9">
                  <h2 id="invest-heading" className="text-2xl font-extrabold">
                    Why {p.status === "For Rent" ? "Choose" : "Invest"} Here?
                  </h2>
                  <ul className="mt-5 space-y-4">
                    {p.whyInvest.map((w: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3 text-[16px] leading-relaxed">
                        <CircleCheck size={22} className="mt-0.5 shrink-0 text-accent-400" aria-hidden="true" />
                        {w}
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              {/* Map */}
              <section aria-labelledby="map-heading">
                <h2 id="map-heading" className="text-2xl font-extrabold text-ink">
                  Location
                </h2>
                <p className="mt-2 flex items-center gap-2 text-neutral-600">
                  <Trees size={18} className="text-brand-600" aria-hidden="true" /> {p.address}
                </p>
                <div className="mt-5 overflow-hidden rounded-xl border border-neutral-200">
                  <iframe
                    title={`Map showing ${p.address}, Kisumu`}
                    src={`https://www.google.com/maps?q=${encodeURIComponent(p.mapQuery || p.address)}&output=embed`}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="h-80 w-full sm:h-96"
                    allowFullScreen
                  />
                </div>
              </section>
            </div>

            {/* RIGHT COLUMN */}
            <aside className="min-w-0 lg:sticky lg:top-28 lg:self-start" aria-label="Contact about this property">
              <div className="rounded-xl border border-neutral-200 bg-white p-6 shadow-lg sm:p-7">
                <p className="text-sm font-semibold text-neutral-500">{p.price === null ? "Asking price" : p.status === "For Rent" ? "Monthly rent" : "Price"}</p>
                <p className="font-display text-3xl font-extrabold text-brand-700">{formatPrice(p)}</p>

                <div className="mt-5 grid grid-cols-2 gap-3">
                  <a
                    href={telLink}
                    className="inline-flex items-center justify-center gap-2 rounded-md bg-ink px-4 py-3.5 text-sm font-bold text-white transition-colors hover:bg-black"
                  >
                    <Phone size={17} aria-hidden="true" /> Call
                  </a>
                  <a
                    href={waLink(enquiryText)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-md bg-emerald-600 px-4 py-3.5 text-sm font-bold text-white transition-colors hover:bg-emerald-700"
                  >
                    <WhatsAppIcon size={17} /> WhatsApp
                  </a>
                </div>

                <div className="my-6 flex items-center gap-3 text-xs font-bold uppercase tracking-wider text-neutral-400">
                  <span className="h-px flex-1 bg-neutral-200" /> Book a site visit <span className="h-px flex-1 bg-neutral-200" />
                </div>

                <EnquiryForm property={p} idPrefix="prop" onSubmit={handlePropertyEnquiry} />

                <ul className="mt-6 space-y-2.5 border-t border-neutral-100 pt-5 text-sm text-neutral-600">
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck size={18} className="text-brand-600" aria-hidden="true" /> Guided site visits by appointment
                  </li>
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck size={18} className="text-brand-600" aria-hidden="true" /> Documents available on request
                  </li>
                </ul>
              </div>
            </aside>
          </div>
        </Container>
      </section>

      {/* Similar properties */}
      {similar.length > 0 && (
        <section className="bg-sand py-16 sm:py-20">
          <Container>
            <SectionHeading align="left" eyebrow="You May Also Like" title="Similar Properties" />
            <div className="mt-10 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
              {similar.map((s) => (
                <PropertyCard key={s.id} property={s} />
              ))}
            </div>
            <div className="mt-10 text-center">
              <Link to="/properties" className="inline-flex items-center gap-2 font-bold text-brand-700 hover:underline">
                View all properties
              </Link>
            </div>
          </Container>
        </section>
      )}

      <CtaBand />
    </>
  );
}