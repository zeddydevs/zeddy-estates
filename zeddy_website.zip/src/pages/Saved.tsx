import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Heart } from "lucide-react";
import { Container, PageHero } from "@/components/ui";
import PropertyCard from "@/components/PropertyCard";
import { useFavorites } from "@/lib/useFavorites";
import { useSeo } from "@/seo/useSeo";
import { savedMeta } from "@/seo/meta";

export default function SavedPage() {
  useSeo(savedMeta());
  const { ids } = useFavorites();
  const [savedProperties, setSavedProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchSaved() {
      if (ids.length === 0) {
        setSavedProperties([]);
        setLoading(false);
        return;
      }

      try {
        const res = await fetch('/api/properties');
        if (res.ok) {
          const all = await res.json();
          setSavedProperties(all.filter((p: any) => ids.includes(p.id)));
        }
      } catch (err) {
        console.error("Failed to fetch saved properties", err);
      } finally {
        setLoading(false);
      }
    }

    fetchSaved();
  }, [ids]);

  return (
    <>
      <PageHero
        title="Saved Properties"
        subtitle="Your shortlist is stored privately in this browser – no account needed."
        breadcrumbs={[{ label: "Home", to: "/" }, { label: "Saved Properties" }]}
      />
      <section className="bg-sand py-14 sm:py-20">
        <Container>
          {loading ? (
            <div className="py-20 text-center text-neutral-500">Loading your saved shortlist...</div>
          ) : savedProperties.length > 0 ? (
            <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
              {savedProperties.map((p) => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          ) : (
            <div className="mx-auto max-w-lg rounded-xl border border-dashed border-neutral-300 bg-white px-6 py-16 text-center">
              <Heart size={44} className="mx-auto text-neutral-400" aria-hidden="true" />
              <h2 className="mt-4 text-xl font-extrabold text-ink">No saved properties yet</h2>
              <p className="mt-2 text-neutral-600">
                Tap the heart on any property to add it to your shortlist and compare later.
              </p>
              <Link
                to="/properties"
                className="mt-6 inline-flex items-center gap-2 rounded-md bg-brand-600 px-7 py-3.5 font-bold text-white hover:bg-brand-700"
              >
                Browse Properties <ArrowRight size={18} aria-hidden="true" />
              </Link>
            </div>
          )}
        </Container>
      </section>
    </>
  );
}