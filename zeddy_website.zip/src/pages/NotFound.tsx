import { Link } from "react-router-dom";
import { ArrowRight, Home, Phone } from "lucide-react";
import { Container } from "@/components/ui";
import { SITE } from "@/config/site";
import { telLink } from "@/lib/format";
import { useSeo } from "@/seo/useSeo";
import { notFoundMeta } from "@/seo/meta";

export default function NotFound() {
  useSeo(notFoundMeta());
  return (
    <section className="bg-sand py-24 sm:py-32">
      <Container className="text-center">
        <p className="font-display text-8xl font-extrabold text-brand-600 sm:text-9xl">404</p>
        <h1 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl">This page has moved out</h1>
        <p className="mx-auto mt-4 max-w-lg text-lg text-neutral-600">
          The page you are looking for doesn't exist or may have been sold. Let's get you back to something great.
        </p>
        <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-md bg-brand-600 px-7 py-4 font-bold text-white hover:bg-brand-700"
          >
            <Home size={18} aria-hidden="true" /> Back to Home
          </Link>
          <Link
            to="/properties"
            className="inline-flex items-center gap-2 rounded-md border-2 border-brand-600 px-7 py-4 font-bold text-brand-700 hover:bg-brand-50"
          >
            Browse Properties <ArrowRight size={18} aria-hidden="true" />
          </Link>
          <a href={telLink} className="inline-flex items-center gap-2 px-4 py-4 font-bold text-ink hover:text-brand-600">
            <Phone size={18} aria-hidden="true" /> {SITE.phoneDisplay}
          </a>
        </div>
      </Container>
    </section>
  );
}