import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CalendarCheck,
  Check,
  FileCheck,
  Handshake,
  House,
  MapPin,
  MessageCircle,
  Phone,
  Search,
  ShieldCheck,
  Store,
  TrendingUp,
  Trees,
  Star,
  Quote,
  type LucideIcon,
} from "lucide-react";
import { Container, CtaBand, SectionHeading } from "@/components/ui";
import PropertyCard from "@/components/PropertyCard";
import BlogCard from "@/components/BlogCard";
import WhatsAppIcon from "@/components/WhatsAppIcon";
import Icon from "@/components/Icon";
import { SITE } from "@/config/site";
import { waLink } from "@/lib/format";
import type { PropertyType } from "@/types";

const HERO_IMAGE = "/banner_home_11.jpeg";

const TYPE_TILES: { type: PropertyType; label: string; icon: LucideIcon; text: string }[] = [
  { type: "Land", label: "Land & Plots", icon: Trees, text: "Residential and commercial plots with title" },
  { type: "House", label: "Houses", icon: House, text: "Maisonettes, bungalows and family homes" },
  { type: "Apartment", label: "Apartments", icon: Building2, text: "Modern flats to rent or buy" },
  { type: "Commercial", label: "Commercial", icon: Store, text: "Offices, shops and development sites" },
];

const REVIEWS = [
  {
    name: "James Ochieng",
    role: "Plot Buyer, Gambogi",
    comment: "Finding a verified title deed used to stress me, but the team walked me through every search and documentation step. Very honest and transparent!",
    rating: 5,
  },
  {
    name: "Sarah Wanjiku",
    role: "Homeowner",
    comment: "The guided site visit was fantastic. No pressure sales, just genuine advice about the neighborhood and growth potential. Highly recommended!",
    rating: 5,
  },
  {
    name: "David Kipkorir",
    role: "Real Estate Investor",
    comment: "Fast responses on WhatsApp and smooth coordination from viewing to final paperwork. Exceptional service all round.",
    rating: 5,
  },
];

const WHY: { icon: LucideIcon; title: string; text: string }[] = [
  {
    icon: ShieldCheck,
    title: "Secure Locations",
    text: "We list properties in safe, well-connected neighbourhoods with good road access and nearby amenities.",
  },
  {
    icon: TrendingUp,
    title: "High Growth Potential",
    text: "Our focus is on fast-developing areas where land and rental values are on the rise.",
  },
  {
    icon: FileCheck,
    title: "Documentation Guidance",
    text: "We point you to the right searches, agreements and transfer steps so you can buy with confidence.",
  },
  {
    icon: CalendarCheck,
    title: "Guided Site Visits",
    text: "Book a visit and we walk the property with you – see the plot, the building and the neighbourhood first-hand.",
  },
  {
    icon: Handshake,
    title: "Honest, Transparent Advice",
    text: "No pressure and no hidden surprises. We tell you the strengths and the risks of every property.",
  },
  {
    icon: MessageCircle,
    title: "Fast, Friendly Response",
    text: "Call or WhatsApp us and get answers quickly – from pricing and payment options to viewing times.",
  },
];

export default function Home() {
  const navigate = useNavigate();
  const [allProperties, setAllProperties] = useState<any[]>([]);
  const [latestPosts, setLatestPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch properties & posts client-side from backend API
  useEffect(() => {
    Promise.all([
      fetch("/api/properties").then((res) => (res.ok ? res.json() : [])),
      fetch("/api/blog").then((res) => (res.ok ? res.json() : [])),
    ])
      .then(([props, posts]) => {
        if (Array.isArray(props)) {
          setAllProperties(
            props.map((p) => ({
              ...p,
              images: Array.isArray(p.images) && p.images.length > 0
                ? p.images
                : [{ src: "/images/banner.jfif", url: "/images/banner.jfif", alt: p.title || "Property" }],
            }))
          );
        }
        if (Array.isArray(posts)) {
          setLatestPosts(posts.slice(0, 3));
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to load home data:", err);
        setLoading(false);
      });
  }, []);

  // Find the featured/spotlight property from state, or fallback to default Gambogi spotlight data
  const spotlightProperty = allProperties.find((p) => p.isFeatured || p.isSpotlight) || {
    title: "Everything Brand New. Ready for Completion!",
    slug: "gambogi-prime-property",
    location: "Gambogi Township – next to Tigoi National School",
    description: "A rare investment opportunity in a rapidly developing area.",
    status: "3-storey building under construction",
    images: [{ url: "/images/banner.jfif", alt: "Gambogi Property" }],
    highlights: [
      { title: 'Tarmac Access', icon: 'Road' },
      { title: 'Ready Title Deed', icon: 'FileText' },
      { title: 'Water & Electricity', icon: 'Zap' },
      { title: 'High Rental Yield', icon: 'TrendingUp' }
    ]
  };

  function onSearch(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const q = formData.get("q") as string;
    const type = formData.get("type") as string;
    const status = formData.get("status") as string;

    const params = new URLSearchParams();
    if (q?.trim()) params.set("q", q.trim());
    if (type) params.set("type", type);
    if (status) params.set("status", status);

    navigate(`/properties${params.toString() ? `?${params}` : ""}`);
  }

  const select =
    "w-full rounded-md border border-neutral-300 bg-white px-4 py-3.5 text-[15px] text-ink focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-600/20";

  return (
    <>
      {/* ================= HERO ================= */}
      <section className="relative isolate overflow-hidden bg-brand-950">
        <img
          src={HERO_IMAGE}
          alt="Modern home with a glass-walled courtyard and green lawn"
          width={1920}
          height={1080}
          className="absolute inset-0 -z-10 h-full w-full object-cover"
        />
        <div className="absolute inset-0 -z-10 bg-brand-950/70" aria-hidden="true" />

        <Container className="pb-32 pt-20 sm:pt-28 lg:pb-40 lg:pt-32">
          <div className="fade-up max-w-3xl">
            <p className="inline-flex items-center gap-2 rounded-full bg-accent-500 px-4 py-1.5 text-[13px] font-bold uppercase tracking-wider text-ink">
              <BadgeCheck size={16} aria-hidden="true" /> {SITE.tagline}
            </p>
            <h1 className="mt-6 text-4xl font-extrabold leading-[1.08] text-white sm:text-5xl lg:text-6xl">
              Find Your Perfect <span className="text-accent-400">Property</span> Anywhere in Kenya
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/85 sm:text-xl">
              Verified land, homes, apartments and commercial property in prime locations – with guided site
              visits and honest advice from a team that puts your property first.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/properties"
                className="inline-flex items-center justify-center gap-2 rounded-md bg-accent-500 px-8 py-4 text-base font-bold text-ink transition-colors hover:bg-accent-400"
              >
                Browse Properties <ArrowRight size={18} aria-hidden="true" />
              </Link>
              <a
                href={waLink(`Hello ${SITE.name}, I would like to book a site visit.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-md border-2 border-white px-8 py-4 text-base font-bold text-white transition-colors hover:bg-white hover:text-brand-900"
              >
                <WhatsAppIcon size={20} /> Book a Site Visit
              </a>
            </div>
          </div>
        </Container>
      </section>

      {/* ================= SEARCH ================= */}
      <Container className="relative z-10 -mt-20 lg:-mt-24">
        <form
          onSubmit={onSearch}
          role="search"
          aria-label="Search properties"
          className="grid gap-4 rounded-xl border border-neutral-200 bg-white p-5 shadow-2xl sm:p-6 md:grid-cols-2 lg:grid-cols-[1.6fr_1fr_1fr_auto] lg:items-end"
        >
          <div>
            <label htmlFor="home-q" className="mb-1.5 block text-sm font-bold text-ink">
              Location or keyword
            </label>
            <div className="relative">
              <MapPin size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-brand-600" aria-hidden="true" />
              <input
                id="home-q"
                name="q"
                type="search"
                placeholder="e.g. Milimani, Gambogi, plots…"
                className={`${select} pl-11`}
              />
            </div>
          </div>
          <div>
            <label htmlFor="home-type" className="mb-1.5 block text-sm font-bold text-ink">
              Property type
            </label>
            <select id="home-type" name="type" className={select}>
              <option value="">All types</option>
              <option value="Land">Land</option>
              <option value="House">House</option>
              <option value="Apartment">Apartment</option>
              <option value="Commercial">Commercial</option>
            </select>
          </div>
          <div>
            <label htmlFor="home-status" className="mb-1.5 block text-sm font-bold text-ink">
              For sale / rent
            </label>
            <select id="home-status" name="status" className={select}>
              <option value="">Sale &amp; Rent</option>
              <option value="For Sale">For Sale</option>
              <option value="For Rent">For Rent</option>
            </select>
          </div>
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 rounded-md bg-brand-600 px-8 py-3.5 text-base font-bold text-white transition-colors hover:bg-brand-700 md:col-span-2 lg:col-span-1"
          >
            <Search size={18} aria-hidden="true" /> Search
          </button>
        </form>
      </Container>

      {/* ================= PROPERTY TYPES GRID ================= */}
      <section className="py-16 sm:py-24">
        <Container>
          <SectionHeading
            eyebrow="Explore By Type"
            title="What Are You Looking For?"
            subtitle="Browse our verified portfolio of land, residential homes, apartments and commercial opportunities."
          />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {TYPE_TILES.map((t) => {
              const IconComp = t.icon;
              return (
                <Link
                  key={t.type}
                  to={`/properties?type=${t.type}`}
                  className="group relative flex flex-col rounded-xl border border-neutral-200 bg-white p-7 transition-all hover:border-brand-600 hover:shadow-xl"
                >
                  <span className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition-colors group-hover:bg-brand-600 group-hover:text-white">
                    <IconComp size={28} aria-hidden="true" />
                  </span>
                  <h2 className="mt-6 text-xl font-extrabold text-ink group-hover:text-brand-600">{t.label}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-neutral-600">{t.text}</p>
                  <span className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-brand-700">
                    Explore {t.label} <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                  </span>
                </Link>
              );
            })}
          </div>
        </Container>
      </section>

      {/* ================= FEATURED PROPERTIES ================= */}
      <section className="bg-sand py-16 sm:py-24">
        <Container>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <SectionHeading
              align="left"
              eyebrow="Latest Listings"
              title="Featured Properties Nationwide"
              subtitle="Hand-picked plots, family homes and investments currently available."
            />
            <Link
              to="/properties"
              className="inline-flex items-center gap-2 font-bold text-brand-700 hover:underline"
            >
              View all properties <ArrowRight size={18} />
            </Link>
          </div>

          {loading ? (
            <div className="py-16 text-center text-neutral-500 font-semibold">Loading properties...</div>
          ) : allProperties.length > 0 ? (
            <div className="mt-12 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
              {allProperties.slice(0, 6).map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          ) : (
            <div className="mt-12 rounded-xl border border-neutral-200 bg-white p-12 text-center">
              <p className="text-neutral-600 font-medium">No properties listed yet.</p>
            </div>
          )}
        </Container>
      </section>

      {/* ================= DYNAMIC FEATURED SPOTLIGHT ================= */}
      <section className="bg-brand-900 py-20 text-white sm:py-24" aria-labelledby="spotlight-heading">
        <Container>
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="relative">
              <img
                src={spotlightProperty.images?.[0]?.url || spotlightProperty.images?.[0]?.src || "/images/banner.jfif"}
                alt={spotlightProperty.title}
                width={1000}
                height={800}
                loading="lazy"
                className="aspect-[5/4] w-full rounded-xl object-cover"
              />
              <div className="absolute right-5 top-0 w-36 bg-brand-950 px-4 pb-6 pt-5 text-center shadow-xl sm:w-40">
                <p className="text-[11px] font-bold uppercase leading-tight tracking-wide text-white/90">Featured</p>
                <p className="font-display text-2xl font-extrabold leading-none text-accent-400 mt-2">SPOTLIGHT</p>
              </div>
              {spotlightProperty.status && (
                <div className="absolute bottom-5 left-5 rounded-md bg-accent-500 px-4 py-2 text-sm font-extrabold uppercase text-ink">
                  {spotlightProperty.status}
                </div>
              )}
            </div>

            <div>
              <p className="inline-flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.18em] text-accent-400">
                <span className="h-[3px] w-8 bg-accent-400" aria-hidden="true" /> 
              </p>
              <h2 id="spotlight-heading" className="mt-3 text-3xl font-extrabold leading-tight sm:text-4xl lg:text-[2.6rem]">
                {spotlightProperty.title}
              </h2>

              <ul className="mt-6 space-y-3 text-[15px]">
                <li className="flex items-start gap-3">
                  <MapPin size={20} className="mt-0.5 shrink-0 text-accent-400" aria-hidden="true" />
                  <span>
                    <strong className="font-bold">Location:</strong> {spotlightProperty.location}
                  </span>
                </li>
              </ul>

              {Array.isArray(spotlightProperty.highlights) && spotlightProperty.highlights.length > 0 && (
                <ul className="mt-7 grid gap-3 sm:grid-cols-2">
                  {spotlightProperty.highlights.map((h: any, idx: number) => (
                    <li key={idx} className="flex items-center gap-3 rounded-lg bg-brand-800 px-4 py-3">
                      <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-brand-950 text-accent-400">
                        <Icon name={h.icon || "Check"} size={20} />
                      </span>
                      <span className="text-sm font-bold leading-snug">{h.title || h}</span>
                    </li>
                  ))}
                </ul>
              )}

              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Link
                  to={`/properties/${spotlightProperty.slug || 'gambogi-prime-property'}`}
                  className="inline-flex items-center justify-center gap-2 rounded-md bg-accent-500 px-7 py-4 text-base font-bold text-ink transition-colors hover:bg-accent-400"
                >
                  View Full Details <ArrowRight size={18} aria-hidden="true" />
                </Link>
                <a
                  href={`tel:${SITE.phoneDisplay}`}
                  className="inline-flex items-center justify-center gap-2 rounded-md border-2 border-white px-7 py-4 text-base font-bold text-white transition-colors hover:bg-white hover:text-brand-900"
                >
                  <Phone size={18} aria-hidden="true" /> {SITE.phoneDisplay}
                </a>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* ================= REVIEWS SECTION ================= */}
      <section className="bg-neutral-50 py-16 sm:py-24 border-y border-neutral-200">
        <Container>
          <SectionHeading
            eyebrow="Client Testimonials"
            title="Trusted by Homeowners & Investors"
            subtitle="Read what our clients have to say about finding their properties and working with us."
          />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {REVIEWS.map((review, idx) => (
              <div key={idx} className="relative rounded-xl border border-neutral-200 bg-white p-7 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1 text-amber-500 mb-4">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                  </div>
                  <Quote size={32} className="text-brand-200 mb-2" aria-hidden="true" />
                  <p className="text-neutral-700 text-sm leading-relaxed italic">
                    "{review.comment}"
                  </p>
                </div>
                <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-ink text-sm">{review.name}</h3>
                    <p className="text-xs text-neutral-500">{review.role}</p>
                  </div>
                  <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-brand-50 text-brand-700 font-bold text-xs">
                    ✓
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* ================= WHY CHOOSE US ================= */}
      <section className="py-16 sm:py-24">
        <Container>
          <SectionHeading
            eyebrow="The Zeddy Advantage"
            title="Why Buy or Rent With Us?"
            subtitle="We combine local market expertise with transparent guidance and hands-on support."
          />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {WHY.map((w) => {
              const IconComp = w.icon;
              return (
                <div key={w.title} className="rounded-xl border border-neutral-200 bg-white p-7">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
                    <IconComp size={24} aria-hidden="true" />
                  </span>
                  <h3 className="mt-5 text-lg font-extrabold text-ink">{w.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-neutral-600">{w.text}</p>
                </div>
              );
            })}
          </div>
        </Container>
      </section>

      {/* ================= LATEST BLOG POSTS ================= */}
      {latestPosts.length > 0 && (
        <section className="py-16 sm:py-24">
          <Container>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <SectionHeading
                align="left"
                eyebrow="Expert Insights"
                title="Real Estate Tips & Guides"
                subtitle="Read our latest advice on buying land, building, and investing."
              />
              <Link to="/blog" className="inline-flex items-center gap-2 font-bold text-brand-700 hover:underline">
                View all articles <ArrowRight size={18} />
              </Link>
            </div>
            <div className="mt-12 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
              {latestPosts.map((post) => (
                <BlogCard key={post.slug} post={post} />
              ))}
            </div>
          </Container>
        </section>
      )}

      <CtaBand />
    </>
  );
}