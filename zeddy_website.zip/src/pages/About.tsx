import { Link } from "react-router-dom";
import {
  ArrowRight,
  Banknote,
  Building2,
  Eye,
  Handshake,
  HeartHandshake,
  House,
  KeyRound,
  LineChart,
  Map,
  Scale,
  ShieldCheck,
  Target,
  Trees,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";
import { Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { SITE } from "@/config/site";
import { useSeo } from "@/seo/useSeo";
import { aboutMeta } from "@/seo/meta";

const SERVICES: { icon: LucideIcon; title: string; text: string }[] = [
  { icon: Trees, title: "Land & Plot Sales", text: "Surveyed, well-located plots for homes, rentals and commercial projects." },
  { icon: House, title: "Houses for Sale", text: "Maisonettes, bungalows and family homes in Kisumu's best neighbourhoods." },
  { icon: KeyRound, title: "Rentals & Letting", text: "Apartments, houses and commercial space for tenants and landlords." },
  { icon: Building2, title: "Development Sites", text: "Plots and partly-built properties ready for completion and returns." },
  { icon: Map, title: "Guided Site Visits", text: "We walk you through the property, the access and the neighbourhood." },
  { icon: LineChart, title: "Investment Advice", text: "Honest guidance on where to buy and how to get the best returns." },
];

const VALUES: { icon: LucideIcon; title: string; text: string }[] = [
  { icon: Scale, title: "Integrity", text: "We do what is right, even when nobody is watching." },
  { icon: Eye, title: "Transparency", text: "Clear information on prices, documents and risks – always." },
  { icon: HeartHandshake, title: "Service", text: "Your property is our priority, from first call to final keys." },
];

const HERO_IMAGE = "/images/banner.jfif";

export default function About() {
  useSeo(aboutMeta());

  return (
    <>
      <PageHero
        title="About Zeddy Real Estates"
        subtitle="Your Property. Our Priority. We help people buy, sell, rent and invest in secure, high-potential property across Kenya."
        breadcrumbs={[{ label: "Home", to: "/" }, { label: "About Us" }]}
      />

      {/* Story */}
      <section className="py-20 sm:py-24">
        <Container>
          <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
            <div className="relative">
              <img
                src={HERO_IMAGE}
                alt="Fishing boats and a wooden dock on Lake Victoria, Kenya"
                width={1000}
                height={800}
                loading="lazy"
                className="aspect-[5/4] w-full rounded-xl object-cover"
              />
              <div className="absolute -bottom-6 right-6 hidden rounded-lg bg-brand-600 p-6 text-white shadow-xl sm:block">
                <p className="font-display text-xl font-extrabold">Based in Kisumu</p>
                <p className="mt-1 text-sm text-white/85">Lake Victoria region, Kenya</p>
              </div>
            </div>
            <div>
              <SectionHeading
                align="left"
                eyebrow="Our Story"
                title="Rooted in Trust. Focused on You."
              />
              <div className="mt-6 space-y-4 text-[16.5px] leading-[1.8] text-neutral-700">
                <p>
                  {SITE.name} is a Kenya-based real estate company dedicated to connecting people with secure,
                  high-potential property. From a half-acre plot with a building already under construction to modern
                  apartments and lakeside homes, we focus on locations with strong growth and real value.
                </p>
                <p>
                  We believe buying or renting property should feel exciting, not stressful. That is why we give you
                  clear information, guided site visits and honest advice – including the risks as well as the
                  opportunities – so you can decide with confidence.
                </p>
                <p>
                  Whether you are a first-time buyer, a diaspora investor, a growing family or a business looking for
                  space, our team is ready to help you find the right property and see the process through.
                </p>
              </div>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link
                  to="/properties"
                  className="inline-flex items-center justify-center gap-2 rounded-md bg-brand-600 px-7 py-4 font-bold text-white hover:bg-brand-700"
                >
                  View Properties <ArrowRight size={18} aria-hidden="true" />
                </Link>
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 rounded-md border-2 border-brand-600 px-7 py-4 font-bold text-brand-700 hover:bg-brand-50"
                >
                  Contact Us
                </Link>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* Mission / Vision */}
      <section className="bg-brand-900 py-20 text-white sm:py-24">
        <Container>
          <div className="grid gap-8 md:grid-cols-2">
            <div className="rounded-xl bg-brand-800 p-8 sm:p-10">
              <span className="inline-flex h-14 w-14 items-center justify-center rounded-lg bg-accent-500 text-ink">
                <Target size={28} aria-hidden="true" />
              </span>
              <h2 className="mt-6 text-2xl font-extrabold">Our Mission</h2>
              <p className="mt-3 text-[16.5px] leading-relaxed text-white/85">
                To connect people with secure, high-potential property through honest advice, transparent dealings and
                exceptional customer service.
              </p>
            </div>
            <div className="rounded-xl bg-brand-800 p-8 sm:p-10">
              <span className="inline-flex h-14 w-14 items-center justify-center rounded-lg bg-accent-500 text-ink">
                <Eye size={28} aria-hidden="true" />
              </span>
              <h2 className="mt-6 text-2xl font-extrabold">Our Vision</h2>
              <p className="mt-3 text-[16.5px] leading-relaxed text-white/85">
                To be the most trusted name in real estate around Lake Victoria – known for secure locations, fast-growth
                opportunities and high returns for our clients.
              </p>
            </div>
          </div>

          <div className="mt-8 grid gap-8 md:grid-cols-3">
            {VALUES.map(({ icon: Ico, title, text }) => (
              <div key={title} className="flex gap-4">
                <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/10 text-accent-400">
                  <Ico size={22} aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-lg font-extrabold">{title}</h3>
                  <p className="mt-1 text-[15px] leading-relaxed text-white/75">{text}</p>
                </div>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* Services */}
      <section className="py-20 sm:py-24">
        <Container>
          <SectionHeading
            eyebrow="What We Do"
            title="Property Services Built Around You"
            subtitle="Everything you need to buy, rent, sell or invest – under one roof."
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map(({ icon: Ico, title, text }) => (
              <div key={title} className="rounded-xl border border-neutral-200 bg-white p-7 transition-shadow hover:shadow-lg">
                <span className="inline-flex h-14 w-14 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
                  <Ico size={26} aria-hidden="true" />
                </span>
                <h3 className="mt-5 text-xl font-extrabold text-ink">{title}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-neutral-600">{text}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* Promise */}
      <section className="bg-sand py-16 sm:py-20">
        <Container>
          <div className="grid gap-6 md:grid-cols-3">
            {[
              { icon: ShieldCheck, title: "Secure Location", text: "Safe neighbourhoods with reliable access and amenities." },
              { icon: TrendingUp, title: "Fast Growth", text: "Areas where infrastructure and demand are rising quickly." },
              { icon: Banknote, title: "High Returns", text: "Opportunities with strong resale and rental potential." },
            ].map(({ icon: Ico, title, text }) => (
              <div key={title} className="flex items-start gap-4 rounded-xl bg-white p-7">
                <span className="inline-flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-white">
                  <Ico size={26} aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-lg font-extrabold uppercase tracking-wide text-ink">{title}</h3>
                  <p className="mt-1 text-[15px] leading-relaxed text-neutral-600">{text}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="mt-10 flex items-center justify-center gap-3 text-center text-lg font-semibold text-brand-800">
            <Handshake size={24} aria-hidden="true" /> Great location. Great investment. Endless possibilities.
          </p>
        </Container>
      </section>

      <CtaBand />
    </>
  );
}