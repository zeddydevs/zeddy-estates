import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { ArrowRight, Calendar, Clock, Search, SearchX } from "lucide-react";
import { Container, CtaBand, PageHero } from "@/components/ui";
import BlogCard from "@/components/BlogCard";
import { SITE } from "@/config/site";
import { formatDate, sized } from "@/lib/format";
import { useSeo } from "@/seo/useSeo";
import { blogIndexMeta } from "@/seo/meta";

export default function BlogPage() {
  useSeo(blogIndexMeta());
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get("q") ?? "";
  const category = searchParams.get("category") ?? "All";

  const [posts, setPosts] = useState<any[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch blog posts and extract categories from backend API
  useEffect(() => {
    setLoading(true);
    fetch("/api/blog")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch blog posts");
        return res.json();
      })
      .then((data) => {
        if (Array.isArray(data)) {
          const sanitized = data.map((p) => ({
            ...p,
            id: p.id || Math.random(),
            title: p.title || "Untitled Article",
            slug: p.slug || "",
            category: p.category || "General",
            excerpt: p.excerpt || p.summary || "",
            content: p.content || "",
            image: p.image || p.imageUrl || "/images/banner.jfif",
            imageAlt: p.imageAlt || p.title || "Blog image",
            date: p.date || p.createdAt || new Date().toISOString().split("T")[0],
            readTime: p.readTime || "5 min read",
            tags: Array.isArray(p.tags) ? p.tags : [],
          }));
          setPosts(sanitized);

          // Extract unique categories dynamically
          const uniqueCats = Array.from(new Set(sanitized.map((p) => p.category).filter(Boolean)));
          setCategories(uniqueCats);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to load blog posts:", err);
        setLoading(false);
      });
  }, []);

  // Filter posts based on category and search query
  const filtered = posts.filter((p) => {
    if (category !== "All" && p.category !== category) return false;
    if (q.trim()) {
      const term = q.trim().toLowerCase();
      const haystack = `${p.title} ${p.excerpt} ${(p.tags || []).join(" ")}`.toLowerCase();
      if (!haystack.includes(term)) return false;
    }
    return true;
  });

  const showFeatured = category === "All" && !q.trim() && filtered.length > 0;
  const featured = showFeatured ? filtered[0] : null;
  const rest = showFeatured ? filtered.slice(1) : filtered;

  function handleCategoryClick(c: string) {
    const newParams = new URLSearchParams(searchParams);
    if (c === "All") {
      newParams.delete("category");
    } else {
      newParams.set("category", c);
    }
    setSearchParams(newParams);
  }

  function handleSearchSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const query = formData.get("q") as string;
    const newParams = new URLSearchParams(searchParams);
    if (query?.trim()) {
      newParams.set("q", query.trim());
    } else {
      newParams.delete("q");
    }
    setSearchParams(newParams);
  }

  return (
    <>
      <PageHero
        title="Real Estate Blog & Property Tips"
        subtitle="Guides, market insights and practical advice on buying land, investing, building and selling property in Kisumu and across Kenya."
        breadcrumbs={[{ label: "Home", to: "/" }, { label: "Blog" }]}
      />

      <section className="py-12 sm:py-16">
        <Container>
          {/* Filters and Search Bar */}
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div className="flex flex-wrap gap-2" role="group" aria-label="Filter articles by category">
              {["All", ...categories].map((c) => {
                const isActive = category === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => handleCategoryClick(c)}
                    className={`rounded-full border px-5 py-2 text-sm font-bold transition-colors ${
                      isActive
                        ? "border-brand-600 bg-brand-600 text-white"
                        : "border-neutral-300 bg-white text-ink hover:border-brand-600 hover:text-brand-600"
                    }`}
                  >
                    {c}
                  </button>
                );
              })}
            </div>

            <form onSubmit={handleSearchSubmit} className="relative w-full md:max-w-xs">
              <label htmlFor="blog-search" className="sr-only">
                Search articles
              </label>
              <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" aria-hidden="true" />
              <input
                id="blog-search"
                name="q"
                type="search"
                defaultValue={q}
                placeholder="Search articles…"
                className="w-full rounded-md border border-neutral-300 bg-white py-3 pl-11 pr-4 text-[15px] focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-600/20"
              />
            </form>
          </div>

          {loading ? (
            <div className="py-24 text-center font-semibold text-neutral-500">Loading articles...</div>
          ) : (
            <>
              {/* Featured Article */}
              {featured && (
                <article className="group relative mt-10 grid overflow-hidden rounded-xl border border-neutral-200 bg-white transition-shadow hover:shadow-xl lg:grid-cols-2">
                  <div className="relative aspect-[16/10] overflow-hidden bg-neutral-100 lg:aspect-auto lg:min-h-[380px]">
                    <img
                      src={sized(featured.image, 1200, 800)}
                      alt={featured.imageAlt}
                      width={1200}
                      height={800}
                      className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <span className="absolute left-4 top-4 rounded-md bg-accent-500 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-ink">
                      Featured · {featured.category}
                    </span>
                  </div>
                  <div className="flex flex-col justify-center p-7 sm:p-10">
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-neutral-500">
                      <span className="inline-flex items-center gap-1.5">
                        <Calendar size={15} aria-hidden="true" />
                        <time dateTime={featured.date}>{formatDate(featured.date)}</time>
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Clock size={15} aria-hidden="true" /> {featured.readTime}
                      </span>
                    </div>
                    <h2 className="mt-4 text-2xl font-extrabold leading-tight text-ink sm:text-3xl">
                      <Link to={`/blog/${featured.slug}`} className="after:absolute after:inset-0 after:content-[''] hover:text-brand-600">
                        {featured.title}
                      </Link>
                    </h2>
                    <p className="mt-4 text-base leading-relaxed text-neutral-600">{featured.excerpt}</p>
                    <span className="mt-6 inline-flex items-center gap-2 font-bold text-brand-600">
                      Read article <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" aria-hidden="true" />
                    </span>
                  </div>
                </article>
              )}

              {/* Article Grid */}
              {rest.length > 0 && (
                <div className="mt-10 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
                  {rest.map((post) => (
                    <BlogCard key={post.slug} post={post as any} />
                  ))}
                </div>
              )}

              {/* Empty State */}
              {filtered.length === 0 && (
                <div className="mt-10 rounded-xl border border-dashed border-neutral-300 px-6 py-16 text-center">
                  <SearchX size={44} className="mx-auto text-neutral-400" aria-hidden="true" />
                  <h2 className="mt-4 text-xl font-extrabold text-ink">No articles found</h2>
                  <p className="mt-2 text-neutral-600">Try a different keyword or category.</p>
                  <Link
                    to="/blog"
                    className="mt-5 inline-block rounded-md bg-brand-600 px-6 py-3 font-bold text-white hover:bg-brand-700"
                  >
                    Show all articles
                  </Link>
                </div>
              )}
            </>
          )}
        </Container>
      </section>

      <CtaBand title="Have a question about property in Kisumu?" text="Our team is happy to help – call or WhatsApp us for free, friendly advice." />
    </>
  );
}