import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Calendar, Clock, Lightbulb, MapPin, Phone, User } from "lucide-react";
import { Breadcrumbs, Container, SectionHeading } from "@/components/ui";
import BlogCard from "@/components/BlogCard";
import ShareButtons from "@/components/ShareButtons";
import WhatsAppIcon from "@/components/WhatsAppIcon";
import NotFound from "@/pages/NotFound";
import { SITE } from "@/config/site";
import { absoluteUrl, formatDate, formatPrice, sized, telLink, waLink } from "@/lib/format";
import { useSeo } from "@/seo/useSeo";
import { blogPostMeta } from "@/seo/meta";
import type { BlogBlock } from "@/types";

function Block({ block }: { block: BlogBlock }) {
  if (!block) return null;
  switch (block.type) {
    case "h2":
      return <h2>{block.text}</h2>;
    case "p":
      return <p>{block.text}</p>;
    case "ul":
      return (
        <ul>
          {(block.items || []).map((i, idx) => (
            <li key={idx}>{i}</li>
          ))}
        </ul>
      );
    case "ol":
      return (
        <ol>
          {(block.items || []).map((i, idx) => (
            <li key={idx}>{i}</li>
          ))}
        </ol>
      );
    case "callout":
      return (
        <aside className="my-8 rounded-xl border-l-4 border-brand-600 bg-brand-50 p-6">
          <p className="!mb-2 flex items-center gap-2 !text-base font-extrabold !text-brand-800">
            <Lightbulb size={20} aria-hidden="true" /> {block.title}
          </p>
          <p className="!mb-0 !text-[16px] !leading-relaxed">{block.text}</p>
        </aside>
      );
    default:
      return null;
  }
}

export default function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>();

  const [post, setPost] = useState<any>(null);
  const [allPosts, setAllPosts] = useState<any[]>([]);
  const [latestProps, setLatestProps] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch post, all posts, and latest properties client-side
  useEffect(() => {
    setLoading(true);
    Promise.all([
      fetch(`/api/blog/${slug}`).then((res) => (res.ok ? res.json() : null)),
      fetch("/api/blog").then((res) => (res.ok ? res.json() : [])),
      fetch("/api/properties").then((res) => (res.ok ? res.json() : [])),
    ])
      .then(([singlePost, postsList, propsList]) => {
        if (singlePost) {
          setPost({
            ...singlePost,
            content: Array.isArray(singlePost.content) 
              ? singlePost.content 
              : typeof singlePost.content === "string" 
                ? [{ type: "p", text: singlePost.content }] 
                : [],
            tags: Array.isArray(singlePost.tags) ? singlePost.tags : [],
            author: singlePost.author || SITE.name,
            date: singlePost.date || singlePost.createdAt || new Date().toISOString().split("T")[0],
            readTime: singlePost.readTime || "5 min read",
            image: singlePost.image || singlePost.imageUrl || "/images/banner.jfif",
            imageAlt: singlePost.imageAlt || singlePost.title || "Blog cover",
          });
        }
        
        if (Array.isArray(postsList)) {
          setAllPosts(postsList);
        }

        if (Array.isArray(propsList)) {
          const sanitizedProps = propsList.slice(0, 3).map((p) => ({
            ...p,
            images: Array.isArray(p.images) && p.images.length > 0 
              ? p.images 
              : [{ src: "/images/banner.jfif", url: "/images/banner.jfif", alt: p.title || "Property" }],
            location: p.location || "Kisumu",
          }));
          setLatestProps(sanitizedProps);
        }

        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch blog post details:", err);
        setLoading(false);
      });
  }, [slug]);

  useSeo(blogPostMeta(post || {}));
  const url = absoluteUrl(`/blog/${slug}`);

  if (loading) {
    return <div className="py-20 text-center font-semibold text-neutral-500">Loading article...</div>;
  }

  if (!post) {
    return <NotFound />;
  }

  const categories = Array.from(new Set(allPosts.map((p) => p.category).filter(Boolean)));
  const related = allPosts
    .filter((p) => p.slug !== slug)
    .slice(0, 3);

  return (
    <>
      <section className="border-b border-neutral-200 bg-white">
        <Container className="py-6">
          <Breadcrumbs items={[{ label: "Home", to: "/" }, { label: "Blog", to: "/blog" }, { label: post.title }]} />
        </Container>
      </section>

      <article className="py-10 sm:py-14">
        <Container>
          <header className="mx-auto max-w-4xl text-center">
            <Link
              to="/blog"
              className="inline-block rounded-md bg-accent-500 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-ink hover:bg-accent-400"
            >
              {post.category}
            </Link>
            <h1 className="mt-5 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">{post.title}</h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-neutral-600">{post.excerpt}</p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-neutral-500">
              <span className="inline-flex items-center gap-1.5">
                <User size={16} aria-hidden="true" /> {post.author}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Calendar size={16} aria-hidden="true" />
                <time dateTime={post.date}>{formatDate(post.date)}</time>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Clock size={16} aria-hidden="true" /> {post.readTime}
              </span>
            </div>
          </header>

          <img
            src={sized(post.image, 1400, 700)}
            alt={post.imageAlt}
            width={1400}
            height={700}
            className="mx-auto mt-10 aspect-[2/1] w-full max-w-5xl rounded-xl object-cover"
          />

          <div className="mx-auto mt-12 grid max-w-6xl gap-12 lg:grid-cols-[minmax(0,1fr)_320px]">
            <div>
              <div className="prose-zeddy">
                {post.content.map((b: BlogBlock, i: number) => (
                  <Block key={i} block={b} />
                ))}
              </div>

              {post.tags.length > 0 && (
                <div className="mt-10 flex flex-wrap gap-2 border-t border-neutral-200 pt-6">
                  {post.tags.map((t: string) => (
                    <span key={t} className="rounded-full bg-neutral-100 px-4 py-1.5 text-sm font-semibold text-neutral-700">
                      #{t}
                    </span>
                  ))}
                </div>
              )}

              <ShareButtons url={url} title={post.title} className="mt-6" />

              <Link to="/blog" className="mt-10 inline-flex items-center gap-2 font-bold text-brand-700 hover:underline">
                <ArrowLeft size={18} aria-hidden="true" /> Back to all articles
              </Link>
            </div>

            <aside className="space-y-8 lg:sticky lg:top-28 lg:self-start" aria-label="Sidebar">
              <div className="rounded-xl bg-brand-900 p-6 text-white">
                <h2 className="text-xl font-extrabold">Talk to a property expert</h2>
                <p className="mt-2 text-[15px] leading-relaxed text-white/80">
                  Questions about buying, selling or renting in Kisumu? We're happy to help.
                </p>
                <div className="mt-5 space-y-3">
                  <a
                    href={telLink}
                    className="flex items-center justify-center gap-2 rounded-md bg-accent-500 px-4 py-3.5 font-bold text-ink hover:bg-accent-400"
                  >
                    <Phone size={18} aria-hidden="true" /> {SITE.phoneDisplay}
                  </a>
                  <a
                    href={waLink(`Hello ${SITE.name}, I just read "${post.title}" and have a question.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 rounded-md border-2 border-white px-4 py-3 font-bold text-white hover:bg-white hover:text-brand-900"
                  >
                    <WhatsAppIcon size={18} /> WhatsApp us
                  </a>
                </div>
              </div>

              {latestProps.length > 0 && (
                <div className="rounded-xl border border-neutral-200 bg-white p-6">
                  <h2 className="text-lg font-extrabold text-ink">Latest properties</h2>
                  <ul className="mt-5 space-y-5">
                    {latestProps.map((p) => {
                      const img = p.images?.[0] || {};
                      const imgSrc = img.src || img.url || "/images/banner.jfif";
                      return (
                        <li key={p.id}>
                          <Link to={`/properties/${p.slug}`} className="group flex gap-4">
                            <img
                              src={sized(imgSrc, 200, 160)}
                              alt={img.alt || p.title}
                              width={100}
                              height={80}
                              className="h-20 w-24 shrink-0 rounded-md object-cover"
                            />
                            <span className="min-w-0">
                              <span className="block text-sm font-bold leading-snug text-ink group-hover:text-brand-600">{p.title}</span>
                              <span className="mt-1 flex items-center gap-1 text-xs text-neutral-500">
                                <MapPin size={12} aria-hidden="true" /> {p.location}
                              </span>
                              <span className="mt-1 block text-sm font-extrabold text-brand-700">{formatPrice(p)}</span>
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}

              {categories.length > 0 && (
                <div className="rounded-xl border border-neutral-200 bg-white p-6">
                  <h2 className="text-lg font-extrabold text-ink">Categories</h2>
                  <ul className="mt-4 space-y-2">
                    {categories.map((c: any) => (
                      <li key={c}>
                        <Link to={`/blog?category=${encodeURIComponent(c)}`} className="flex items-center justify-between rounded-md px-3 py-2 text-[15px] font-semibold text-neutral-700 hover:bg-brand-50 hover:text-brand-700">
                          {c}
                          <span className="rounded-full bg-neutral-100 px-2.5 py-0.5 text-xs font-bold">
                            {allPosts.filter((p) => p.category === c).length}
                          </span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </aside>
          </div>
        </Container>
      </article>

      {related.length > 0 && (
        <section className="bg-sand py-16 sm:py-20">
          <Container>
            <SectionHeading align="left" eyebrow="Keep Reading" title="Related Articles" />
            <div className="mt-10 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
              {related.map((p) => (
                <BlogCard key={p.slug} post={p} />
              ))}
            </div>
          </Container>
        </section>
      )}
    </>
  );
}