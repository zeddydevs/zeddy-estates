import { useState, useEffect } from "react";
import { ChevronDown, Clock, Mail, MapPin, Phone } from "lucide-react";
import { Container, PageHero, SectionHeading } from "@/components/ui";
import EnquiryForm from "@/components/EnquiryForm";
import WhatsAppIcon from "@/components/WhatsAppIcon";
import { SITE } from "@/config/site";
import { telLink, waLink } from "@/lib/format";
import { useSeo } from "@/seo/useSeo";
import { contactMeta } from "@/seo/meta";

export default function Contact() {
  useSeo(contactMeta());

  const [faqs, setFaqs] = useState<{ q: string; a: string }[]>([]);

  // Fetch FAQs from API or mock data on client side
  useEffect(() => {
    // Example: fetch('/api/faqs')...
  }, []);

  // Handle Enquiry submissions on the client side
  async function handleEnquiry(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get("name") as string;
    const phone = formData.get("phone") as string;
    const email = formData.get("email") as string;
    const message = formData.get("message") as string;

    if (name && phone && message) {
      try {
        // Send to your backend API endpoint (e.g., POST /api/enquiries)
        // await fetch('/api/enquiries', { method: 'POST', body: JSON.stringify({ name, phone, email, message }) });
        alert("Enquiry sent successfully!");
      } catch (err) {
        console.error("Failed to send enquiry", err);
      }
    }
  }

  const cards = [
    {
      icon: Phone,
      title: "Call Us",
      lines: [SITE.phoneDisplay],
      href: telLink,
      cta: "Call now",
    },
    {
      icon: WhatsAppIcon,
      title: "WhatsApp",
      lines: ["Chat with our team"],
      href: waLink(`Hello ${SITE.name}, I would like to enquire about a property.`),
      cta: "Start chat",
      external: true,
    },
    {
      icon: Mail,
      title: "Email",
      lines: [SITE.email],
      href: `mailto:${SITE.email}`,
      cta: "Send email",
    },
    {
      icon: MapPin,
      title: "Visit Us",
      lines: [SITE.address.street],
      href: `https://www.google.com/maps?q=${encodeURIComponent("Kisumu, Kenya")}`,
      cta: "Get directions",
      external: true,
    },
  ];

  return (
    <>
      <PageHero
        title="Contact Zeddy Real Estates"
        subtitle="Book a site visit, ask about a property or tell us what you're looking for. We usually reply within hours."
        breadcrumbs={[{ label: "Home", to: "/" }, { label: "Contact" }]}
      />

      <section className="py-16 sm:py-20">
        <Container>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {cards.map(({ icon: Ico, title, lines, href, cta, external }) => (
              <a
                key={title}
                href={href}
                {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                className="group rounded-xl border border-neutral-200 bg-white p-7 transition-colors hover:border-brand-600 hover:bg-brand-600"
              >
                <span className="inline-flex h-14 w-14 items-center justify-center rounded-lg bg-brand-50 text-brand-600 transition-colors group-hover:bg-accent-500 group-hover:text-ink">
                  <Ico size={26} aria-hidden="true" />
                </span>
                <h2 className="mt-5 text-xl font-extrabold text-ink group-hover:text-white">{title}</h2>
                {lines.map((l) => (
                  <p key={l} className="mt-1 break-all text-[15px] text-neutral-600 group-hover:text-white/85">
                    {l}
                  </p>
                ))}
                <p className="mt-4 text-sm font-bold text-brand-600 group-hover:text-accent-400">{cta} →</p>
              </a>
            ))}
          </div>

          <div className="mt-16 grid gap-12 lg:grid-cols-5">
            <div className="lg:col-span-3">
              <SectionHeading align="left" eyebrow="Send an Enquiry" title="Tell Us How We Can Help" />
              <p className="mt-4 text-neutral-600">
                Fill in the form to send us your enquiry directly. Our team will review your request and get back to you promptly.
              </p>
              <div className="mt-8 rounded-xl border border-neutral-200 bg-white p-6 shadow-sm sm:p-8">
                {/* Note: Pass your client form submission handler to EnquiryForm */}
                <EnquiryForm idPrefix="contact" onSubmit={handleEnquiry} />
              </div>
            </div>

            <div className="space-y-6 lg:col-span-2">
              <div className="rounded-xl bg-brand-900 p-7 text-white">
                <h2 className="flex items-center gap-2 text-xl font-extrabold">
                  <Clock size={22} className="text-accent-400" aria-hidden="true" /> Opening Hours
                </h2>
                <ul className="mt-5 divide-y divide-white/10">
                  {SITE.hours.map((h) => (
                    <li key={h.days} className="flex items-center justify-between gap-4 py-3 text-[15px]">
                      <span className="text-white/80">{h.days}</span>
                      <span className="font-bold">{h.time}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-4 text-sm text-white/70">Site visits can be arranged outside these hours by appointment.</p>
              </div>

              <div className="overflow-hidden rounded-xl border border-neutral-200">
                <iframe
                  title="Map of Kisumu, Kenya"
                  src={`https://www.google.com/maps?q=${encodeURIComponent("Kisumu, Kenya")}&output=embed`}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="h-72 w-full"
                  allowFullScreen
                />
              </div>
            </div>
          </div>
        </Container>
      </section>

      
    </>
  );
}