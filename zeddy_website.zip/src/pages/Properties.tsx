import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { RotateCcw, Search, SearchX, SlidersHorizontal } from "lucide-react";
import { Container, CtaBand, PageHero } from "@/components/ui";
import PropertyCard from "@/components/PropertyCard";
import { useSeo } from "@/seo/useSeo";
import { propertiesMeta } from "@/seo/meta";

const TYPES = ["Land", "House", "Apartment", "Commercial"] as const;
const STATUSES = ["For Sale", "For Rent"] as const;

const control =
  "w-full rounded-md border border-neutral-300 bg-white px-4 py-3 text-[15px] text-ink focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-600/20";

export default function Properties() {
  useSeo(propertiesMeta());
  const [searchParams, setSearchParams] = useSearchParams();

  const q = searchParams.get("q") ?? "";
  const type = searchParams.get("type") ?? "";
  const status = searchParams.get("status") ?? "";
  const beds = searchParams.get("beds") ? Number(searchParams.get("beds")) : 0;
  const sort = searchParams.get("sort") ?? "newest";

  const [allProperties, setAllProperties] = useState<any[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);

  // Fetch properties from your Express backend API connected to PostgreSQL
  useEffect(() => {
    fetch("/api/properties")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          const sanitized = data.map((p) => ({
            ...p,
            id: p.id || Math.random(),
            title: p.title || "Untitled Property",
            slug: p.slug || "",
            type: p.type || "Land",
            status: p.status || "For Sale",
            price: p.price ? Number(p.price) : 0,
            location: p.location || "Kisumu",
            bedrooms: p.bedrooms ? Number(p.bedrooms) : 0,
            bathrooms: p.bathrooms ? Number(p.bathrooms) : 0,
            summary: p.summary || "",
            description: p.description || "",
            images: Array.isArray(p.images) && p.images.length > 0 
              ? p.images 
              : [{ url: "/images/banner.jfif", alt: p.title || "Property image" }],
          }));
          setAllProperties(sanitized);
          setTotalCount(sanitized.length);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch properties from API:", err);
        setLoading(false);
      });
  }, []);

  // Filter and sort properties client-side
  const results = allProperties.filter((p) => {
    if (type && p.type !== type) return false;
    if (status && p.status !== status) return false;
    if (beds > 0 && (p.bedrooms || 0) < beds) return false;
    if (q.trim()) {
      const term = q.trim().toLowerCase();
      const haystack = `${p.title || ""} ${p.location || ""} ${p.area || ""} ${p.summary || ""} ${p.description || ""}`.toLowerCase();
      if (!haystack.includes(term)) return false;
    }
    return true;
  }).sort((a, b) => {
    if (sort === "price-asc") return (Number(a.price) || 0) - (Number(b.price) || 0);
    if (sort === "price-desc") return (Number(b.price) || 0) - (Number(a.price) || 0);
    return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
  });

  const hasFilters = Boolean(q || type || status || beds > 0 || sort !== "newest");

  function handleFilterSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newParams = new URLSearchParams();

    const query = formData.get("q") as string;
    const propType = formData.get("type") as string;
    const propStatus = formData.get("status") as string;
    const propBeds = formData.get("beds") as string;
    const propSort = formData.get("sort") as string;

    if (query?.trim()) newParams.set("q", query.trim());
    if (propType) newParams.set("type", propType);
    if (propStatus) newParams.set("status", propStatus);
    if (propBeds) newParams.set("beds", propBeds);
    if (propSort && propSort !== "newest") newParams.set("sort", propSort);

    setSearchParams(newParams);
  }

  return (
    <>
      <PageHero
        title="Properties for Sale & Rent"
        subtitle="Browse verified land, houses, apartments and commercial property. Filter by type, status and bedrooms to find the right match."
        breadcrumbs={[{ label: "Home", to: "/" }, { label: "Properties" }]}
      />

      <section className="bg-sand py-10 sm:py-14">
        <Container>
          {/* Filters Form */}
          <form
            role="search"
            aria-label="Filter properties"
            onSubmit={handleFilterSubmit}
            className="rounded-xl border border-neutral-200 bg-white p-5 shadow-sm sm:p-6"
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="inline-flex items-center gap-2 text-lg font-extrabold text-ink">
                <SlidersHorizontal size={20} className="text-brand-600" aria-hidden="true" /> Filter Properties
              </h2>
              {hasFilters && (
                <Link
                  to="/properties"
                  className="inline-flex items-center gap-1.5 text-sm font-bold text-brand-700 hover:underline"
                >
                  <RotateCcw size={14} aria-hidden="true" /> Reset
                </Link>
              )}
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
              <div className="lg:col-span-2">
                <label htmlFor="f-q" className="mb-1.5 block text-sm font-semibold text-ink">
                  Search
                </label>
                <div className="relative">
                  <Search size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" aria-hidden="true" />
                  <input
                    id="f-q"
                    name="q"
                    type="search"
                    defaultValue={q}
                    placeholder="Location, keyword or title…"
                    className={`${control} pl-11`}
                  />
                </div>
              </div>
              <div>
                <label htmlFor="f-type" className="mb-1.5 block text-sm font-semibold text-ink">
                  Type
                </label>
                <select id="f-type" name="type" defaultValue={type} className={control}>
                  <option value="">All types</option>
                  {TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="f-beds" className="mb-1.5 block text-sm font-semibold text-ink">
                  Bedrooms
                </label>
                <select id="f-beds" name="beds" defaultValue={beds || ""} className={control}>
                  <option value="">Any</option>
                  {[1, 2, 3, 4].map((n) => (
                    <option key={n} value={n}>
                      {n}+ bedrooms
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="f-sort" className="mb-1.5 block text-sm font-semibold text-ink">
                  Sort by
                </label>
                <select id="f-sort" name="sort" defaultValue={sort} className={control}>
                  <option value="newest">Newest first</option>
                  <option value="price-asc">Price: low to high</option>
                  <option value="price-desc">Price: high to low</option>
                </select>
              </div>
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-2" role="group" aria-label="Sale or rent">
              <input type="hidden" name="status" value={status} />
              {[{ label: "All", value: "" }, ...STATUSES.map((s) => ({ label: s, value: s }))].map((s) => (
                <button
                  key={s.label}
                  type="submit"
                  name="status"
                  value={s.value}
                  className={`rounded-full border px-5 py-2 text-sm font-bold transition-colors ${
                    status === s.value
                      ? "border-brand-600 bg-brand-600 text-white"
                      : "border-neutral-300 bg-white text-ink hover:border-brand-600 hover:text-brand-600"
                  }`}
                >
                  {s.label}
                </button>
              ))}
              <button type="submit" className="hidden">Apply Filters</button>
            </div>
          </form>

          {/* Results */}
          <div className="mt-10 flex items-center justify-between">
            <p className="text-[15px] text-neutral-700" aria-live="polite">
              Showing <strong className="text-ink">{results.length}</strong> of {totalCount || results.length} properties
            </p>
          </div>

          {loading ? (
            <div className="mt-12 py-20 text-center text-neutral-500 font-semibold">Loading properties from database...</div>
          ) : results.length > 0 ? (
            <div className="mt-6 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
              {results.map((p, i) => (
                <PropertyCard key={p.id} property={p as any} priority={i < 3} />
              ))}
            </div>
          ) : (
            <div className="mt-6 rounded-xl border border-dashed border-neutral-300 bg-white px-6 py-16 text-center">
              <SearchX size={44} className="mx-auto text-neutral-400" aria-hidden="true" />
              <h3 className="mt-4 text-xl font-extrabold text-ink">No properties match your search</h3>
              <p className="mx-auto mt-2 max-w-md text-neutral-600">
                Try removing a filter or searching a different area. Or tell us what you need and we will help you find it.
              </p>
              <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Link
                  to="/properties"
                  className="rounded-md bg-brand-600 px-6 py-3 font-bold text-white hover:bg-brand-700"
                >
                  Clear all filters
                </Link>
                <Link to="/contact" className="rounded-md border-2 border-brand-600 px-6 py-3 font-bold text-brand-700 hover:bg-brand-50">
                  Tell us what you need
                </Link>
              </div>
            </div>
          )}
        </Container>
      </section>

      <CtaBand title="Can't find what you're looking for?" text="We have more properties that are not listed online yet. Call or WhatsApp us with your requirements." />
    </>
  );
}