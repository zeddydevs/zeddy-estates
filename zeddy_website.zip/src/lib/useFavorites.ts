import { useCallback, useSyncExternalStore } from "react";

const KEY = "zeddy-saved-properties";
const listeners = new Set<() => void>();

function read(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

let snapshot: string[] = read();

function write(next: string[]) {
  snapshot = next;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable – keep in memory only */
  }
  listeners.forEach((l) => l());
}

const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => listeners.delete(cb);
};

/** Saved / favourite properties stored in the browser (no backend needed). */
export function useFavorites() {
  const ids = useSyncExternalStore(
    subscribe,
    () => snapshot,
    () => [] as string[],
  );

  const toggle = useCallback((id: string) => {
    write(snapshot.includes(id) ? snapshot.filter((x) => x !== id) : [...snapshot, id]);
  }, []);

  const isSaved = useCallback((id: string) => ids.includes(id), [ids]);

  return { ids, toggle, isSaved, count: ids.length };
}
