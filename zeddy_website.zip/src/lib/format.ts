import type { Property } from "../data/types";
import { SITE } from "../config/site";

export const formatKES = (n: number | string | null | undefined) => {
  if (n === null || n === undefined || n === "") return "Price on Request";
  const num = Number(n);
  if (isNaN(num)) return "Price on Request";
  return `KES ${num.toLocaleString("en-KE")}`;
};

export const formatPrice = (p: Pick<Property, "price" | "pricePeriod"> | null | undefined) => {
  if (!p || p.price === null || p.price === undefined || p.price === "") return "Price on Request";
  return `${formatKES(p.price)}${p.pricePeriod === "month" ? " / month" : ""}`;
};

export const formatDate = (iso: string | null | undefined) => {
  if (!iso) return "";
  const date = new Date(iso);
  if (isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-KE", { year: "numeric", month: "long", day: "numeric" });
};

export const waLink = (message: string) =>
  `https://wa.me/${SITE.whatsappNumber}?text=${encodeURIComponent(message)}`;

export const telLink = `tel:${SITE.phone}`;
export const mailLink = (subject = "", body = "") =>
  `mailto:${SITE.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

/** Resize a Pexels CDN url for cards / thumbnails. Other urls are returned untouched. */
export const sized = (src: string | null | undefined, w: number, h: number) => {
  if (!src) return "/images/banner.jfif";
  return src.includes("images.pexels.com") ? src.replace(/h=\d+/, `h=${h}`).replace(/w=\d+/, `w=${w}`) : src;
};

/** Canonical absolute URL. Non-root pages use a trailing slash (matches pre-rendered folders on static hosts). */
export const absoluteUrl = (path: string) => (path === "/" ? `${SITE.url}/` : `${SITE.url}${path}/`);

export const truncate = (text: string | null | undefined, max = 158) => {
  if (!text) return "";
  return text.length <= max ? text : `${text.slice(0, max - 1).replace(/\s+\S*$/, "")}…`;
};