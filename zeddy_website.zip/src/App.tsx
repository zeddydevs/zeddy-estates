import { BrowserRouter, HashRouter, Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Properties from "./pages/Properties";
import PropertyDetail from "./pages/PropertyDetail";
import Blog from "./pages/Blog";
import BlogPostPage from "./pages/BlogPost";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Saved from "./pages/Saved";
import SitemapPage from "./pages/SitemapPage";
import NotFound from "./pages/NotFound";
import AdminLogin from "./app/admin/Login"; // Adjust path if your pages folder structure differs
import AdminDashboard from "./app/admin/Page";
import NewPropertyPage from "./app/admin/properties/New";
import ManageProperties from "./app/admin/properties/Manage";
import EditPropertyPage from "./app/admin/properties/Edit";
import ManageBlog from "./app/admin/blog/Manage";
import NewBlogPostPage from "./app/admin/blog/New";
import EditBlogPostPage from "./app/admin/blog/Edit";
import ChangePasswordPage from "./app/admin/ChangePassword";
const KNOWN_PREFIXES = ["/properties", "/blog", "/about", "/contact", "/sitemap", "/saved", "/admin"];

/**
 * Picks clean URLs (BrowserRouter) when the site is served from a domain root,
 * and falls back to hash URLs when opened from a file, sub-folder or sandbox preview.
 * Force a mode by editing <meta name="router-mode"> in index.html ("browser" | "hash").
 */
function pickRouterMode(): "browser" | "hash" {
  if (typeof window === "undefined") return "browser";
  const forced = document.querySelector('meta[name="router-mode"]')?.getAttribute("content");
  if (forced === "browser" || forced === "hash") return forced;

  const { protocol, pathname } = window.location;
  if (protocol !== "http:" && protocol !== "https:") return "hash";
  if (pathname === "/") return "browser";
  return KNOWN_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`)) ? "browser" : "hash";
}

function AppRoutes() {
  return (
    <Routes>
      {/* Admin Routes (outside main public Layout) */}
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/admin/properties/new" element={<NewPropertyPage />} />
      <Route path="/admin/properties" element={<ManageProperties />} />
      <Route path="/admin/properties/edit/:id" element={<EditPropertyPage />} />
      <Route path="/admin/blog" element={<ManageBlog />} />
<Route path="/admin/blog/new" element={<NewBlogPostPage />} />
<Route path="/admin/blog/edit/:id" element={<EditBlogPostPage />} />
<Route path="/admin/password" element={<ChangePasswordPage />} />
      {/* Public Layout Routes */}
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="properties" element={<Properties />} />
        <Route path="properties/:slug" element={<PropertyDetail />} />
        <Route path="blog" element={<Blog />} />
        <Route path="blog/:slug" element={<BlogPostPage />} />
        <Route path="about" element={<About />} />
        <Route path="contact" element={<Contact />} />
        <Route path="saved" element={<Saved />} />
        <Route path="sitemap" element={<SitemapPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

const mode = pickRouterMode();

export default function App() {
  const Router = mode === "hash" ? HashRouter : BrowserRouter;
  return (
    <Router>
      <AppRoutes />
    </Router>
  );
}