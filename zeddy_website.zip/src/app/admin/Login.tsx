import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Lock, Eye, EyeOff } from "lucide-react";
import { Container } from "@/components/ui";

export default function AdminLogin() {
  const [secret, setSecret] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: secret }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Invalid admin passphrase.");
      }

      // Save the token/password for subsequent requests
      localStorage.setItem("zeddy_admin_token", secret);
      navigate("/admin");
    } catch (err: any) {
      console.error("Login failed:", err);
      setError(err.message || "Invalid admin passphrase.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-sand py-12">
      <Container className="max-w-md">
        <div className="rounded-xl border border-neutral-200 bg-white p-8 shadow-sm sm:p-10">
          <div className="text-center">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600 mb-4">
              <Lock size={24} />
            </span>
            <h1 className="text-2xl font-extrabold text-ink">Admin Portal</h1>
            <p className="mt-2 text-sm text-neutral-600">Enter your admin passphrase to manage listings.</p>
          </div>

          <form onSubmit={handleLogin} className="mt-6 space-y-4">
            <div>
              <label className="block text-sm font-bold text-ink">Passphrase</label>
              <div className="relative mt-1">
                <input
                  type={showPassword ? "text" : "password"}
                  value={secret}
                  onChange={(e) => setSecret(e.target.value)}
                  placeholder="Enter admin secret..."
                  className="w-full rounded-md border border-neutral-300 p-3 pr-10 text-sm focus:border-brand-600 focus:outline-none"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-700"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {error && <p className="text-sm font-bold text-red-600">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-md bg-brand-600 py-3 font-bold text-white hover:bg-brand-700 disabled:opacity-50 transition-colors"
            >
              {loading ? "Authenticating..." : "Sign In to Dashboard"}
            </button>
          </form>
        </div>
      </Container>
    </div>
  );
}