import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Edit, Trash2, Plus, Building2 } from "lucide-react";
import { Container } from "@/components/ui";
import { formatPrice } from "@/lib/format";

export default function ManageProperties() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProperties = () => {
    fetch("/api/properties")
      .then((res) => res.json())
      .then((data) => {
        setItems(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchProperties();
  }, []);

  async function handleDelete(id: string | number) {
    if (!confirm("Are you sure you want to delete this property?")) return;
    const token = localStorage.getItem("zeddy_admin_token");

    try {
      const res = await fetch(`/api/properties/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setItems(items.filter((item) => item.id !== id));
      } else {
        alert("Failed to delete property");
      }
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div className="min-h-screen bg-sand pb-20">
      <header className="border-b border-neutral-200 bg-white py-4 shadow-sm">
        <Container className="flex items-center justify-between">
          <Link to="/admin" className="inline-flex items-center gap-2 text-sm font-bold text-brand-700 hover:underline">
            <ArrowLeft size={16} /> Back to Dashboard
          </Link>
          <Link
            to="/admin/properties/new"
            className="inline-flex items-center gap-1.5 rounded-md bg-brand-600 px-4 py-2 text-sm font-bold text-white hover:bg-brand-700"
          >
            <Plus size={16} /> Add Property
          </Link>
        </Container>
      </header>

      <Container className="mt-10">
        <h1 className="font-display text-2xl font-extrabold text-ink">Manage Properties</h1>
        
        {loading ? (
          <p className="mt-6 text-neutral-500">Loading properties...</p>
        ) : items.length === 0 ? (
          <div className="mt-6 rounded-xl border border-neutral-200 bg-white p-12 text-center">
            <Building2 size={40} className="mx-auto text-neutral-400" />
            <p className="mt-3 font-semibold text-neutral-600">No properties found in database.</p>
          </div>
        ) : (
          <div className="mt-6 overflow-hidden rounded-xl border border-neutral-200 bg-white shadow-sm">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-neutral-200 bg-neutral-50 text-xs font-bold uppercase tracking-wider text-neutral-500">
                  <th className="p-4">Title</th>
                  <th className="p-4">Type</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Price</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 text-sm">
                {items.map((p) => (
                  <tr key={p.id} className="hover:bg-neutral-50/50">
                    <td className="p-4 font-bold text-ink">{p.title}</td>
                    <td className="p-4 text-neutral-600">{p.type}</td>
                    <td className="p-4">
                      <span className={`rounded px-2 py-1 text-xs font-bold uppercase ${p.status === "For Sale" ? "bg-brand-50 text-brand-700" : "bg-amber-50 text-amber-700"}`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-brand-700">{formatPrice(p)}</td>
                    <td className="p-4 text-right space-x-2">
                      <Link
                        to={`/admin/properties/edit/${p.id}`}
                        className="inline-flex items-center gap-1 rounded bg-neutral-100 px-3 py-1.5 font-bold text-neutral-700 hover:bg-neutral-200"
                      >
                        <Edit size={14} /> Edit
                      </Link>
                      <button
                        onClick={() => handleDelete(p.id)}
                        className="inline-flex items-center gap-1 rounded bg-red-50 px-3 py-1.5 font-bold text-red-600 hover:bg-red-100"
                      >
                        <Trash2 size={14} /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Container>
    </div>
  );
}