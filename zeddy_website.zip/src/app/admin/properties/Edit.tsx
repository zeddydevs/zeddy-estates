import { useState, useEffect } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { ArrowLeft, Building2, Plus, Trash2 } from "lucide-react";
import { Container } from "@/components/ui";
import ImageUpload from "@/components/admin/ImageUpload";

export default function EditPropertyPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    summary: "",
    type: "Land",
    status: "For Sale",
    price: "",
    location: "Kisumu",
    address: "",
    landSize: "",
    bedrooms: "",
    bathrooms: "",
    description: "",
    isFeatured: false,
    highlights: [],
    amenities: [],
  });

  const [images, setImages] = useState<string[]>([""]);
  const [newHighlightTitle, setNewHighlightTitle] = useState("");
  const [newHighlightIcon, setNewHighlightIcon] = useState("Check");
  const [newAmenity, setNewAmenity] = useState("");

  useEffect(() => {
    fetch("/api/properties")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          const prop = data.find((p: any) => String(p.id) === String(id));
          if (prop) {
            setFormData({
              title: prop.title || "",
              slug: prop.slug || "",
              summary: prop.summary || "",
              type: prop.type || "Land",
              status: prop.status || "For Sale",
              price: prop.price !== null ? String(prop.price) : "",
              location: prop.location || "Kisumu",
              address: prop.address || "",
              landSize: prop.landSize || "",
              bedrooms: prop.bedrooms !== null ? String(prop.bedrooms) : "",
              bathrooms: prop.bathrooms !== null ? String(prop.bathrooms) : "",
              description: typeof prop.description === "string" ? prop.description : Array.isArray(prop.description) ? prop.description.join("\n\n") : "",
              isFeatured: !!prop.isFeatured,
              highlights: Array.isArray(prop.highlights) ? prop.highlights : [],
              amenities: Array.isArray(prop.amenities) ? prop.amenities : [],
            });
            if (Array.isArray(prop.images) && prop.images.length > 0) {
              setImages(prop.images.map((img: any) => img.url || img.src || ""));
            }
          } else {
            setError("Property not found.");
          }
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setError("Failed to load property details.");
        setLoading(false);
      });
  }, [id]);

  function handleImageChange(index: number, value: string) {
    const updated = [...images];
    updated[index] = value;
    setImages(updated);
  }

  function addImageField() {
    setImages([...images, ""]);
  }

  function removeImageField(index: number) {
    setImages(images.filter((_, i) => i !== index));
  }

  function addHighlight() {
    if (!newHighlightTitle.trim()) return;
    const updatedHighlights = [
      ...(formData.highlights || []),
      { title: newHighlightTitle.trim(), icon: newHighlightIcon },
    ];
    setFormData((prev) => ({ ...prev, highlights: updatedHighlights }));
    setNewHighlightTitle("");
    setNewHighlightIcon("Check");
  }

  function removeHighlight(index: number) {
    const updatedHighlights = formData.highlights.filter((_, i) => i !== index);
    setFormData((prev) => ({ ...prev, highlights: updatedHighlights }));
  }

  function addAmenity() {
    if (!newAmenity.trim()) return;
    setFormData((prev) => ({
      ...prev,
      amenities: [...(prev.amenities || []), newAmenity.trim()],
    }));
    setNewAmenity("");
  }

  function removeAmenity(index: number) {
    setFormData((prev) => ({
      ...prev,
      amenities: prev.amenities.filter((_, i) => i !== index),
    }));
  }

  async function handleUpdate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");

    const token = localStorage.getItem("zeddy_admin_token");

    const payload = {
      ...formData,
      price: formData.price ? Number(formData.price) : null,
      bedrooms: formData.bedrooms ? Number(formData.bedrooms) : null,
      bathrooms: formData.bathrooms ? Number(formData.bathrooms) : null,
      images: images.filter(Boolean).map((url, idx) => ({ url, displayOrder: idx })),
    };

    try {
      const res = await fetch(`/api/properties/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to update property");
      }

      navigate("/admin/properties");
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong.");
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="py-20 text-center font-semibold text-neutral-500">Loading property...</div>;
  }

  return (
    <div className="min-h-screen bg-sand pb-20">
      <header className="border-b border-neutral-200 bg-white py-4 shadow-sm">
        <Container className="flex items-center justify-between">
          <Link to="/admin/properties" className="inline-flex items-center gap-2 text-sm font-bold text-brand-700 hover:underline">
            <ArrowLeft size={16} /> Back to Properties
          </Link>
          <h1 className="font-display text-lg font-extrabold text-ink">Edit Property</h1>
        </Container>
      </header>

      <Container className="mt-10 max-w-3xl">
        <div className="rounded-xl border border-neutral-200 bg-white p-8 shadow-sm">
          <div className="flex items-center gap-3 border-b border-neutral-100 pb-5">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
              <Building2 size={20} />
            </span>
            <div>
              <h2 className="text-xl font-extrabold text-ink">Update Listing</h2>
              <p className="text-sm text-neutral-600">Modify information for property reference #{id}</p>
            </div>
          </div>

          {error && <div className="mt-6 rounded-md bg-red-50 p-4 text-sm font-bold text-red-600">{error}</div>}

          <form onSubmit={handleUpdate} className="mt-6 space-y-6">
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="block text-sm font-bold text-ink">Property Title *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">URL Slug *</label>
                <input
                  type="text"
                  required
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 bg-neutral-50 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-bold text-ink">Short Summary / Tagline *</label>
                <input
                  type="text"
                  required
                  value={formData.summary}
                  onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                  placeholder="Brief one-line summary for property cards"
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Property Type *</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 bg-white p-3 text-sm focus:border-brand-600 focus:outline-none"
                >
                  <option value="Land">Land</option>
                  <option value="House">House</option>
                  <option value="Apartment">Apartment</option>
                  <option value="Commercial">Commercial</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Listing Status *</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 bg-white p-3 text-sm focus:border-brand-600 focus:outline-none"
                >
                  <option value="For Sale">For Sale</option>
                  <option value="For Rent">For Rent</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Price (KES) *</label>
                <input
                  type="number"
                  required
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Location / Area *</label>
                <input
                  type="text"
                  required
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Plot / Land Size</label>
                <input
                  type="text"
                  value={formData.landSize}
                  onChange={(e) => setFormData({ ...formData, landSize: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Bedrooms</label>
                <input
                  type="number"
                  value={formData.bedrooms}
                  onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Bathrooms</label>
                <input
                  type="number"
                  value={formData.bathrooms}
                  onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>
            </div>

            {/* ================= FEATURED SPOTLIGHT TOGGLE & HIGHLIGHTS ================= */}
            <div className="rounded-xl border border-neutral-200 bg-neutral-50 p-5 space-y-4">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="isFeatured"
                  checked={formData.isFeatured}
                  onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                  className="h-5 w-5 rounded border-neutral-300 text-brand-600 focus:ring-brand-500"
                />
                <div>
                  <label htmlFor="isFeatured" className="font-bold text-ink cursor-pointer">
                    Feature as Homepage Spotlight Section
                  </label>
                  <p className="text-xs text-neutral-500">
                    Check this to display this property prominently in the homepage spotlight banner.
                  </p>
                </div>
              </div>

              {formData.isFeatured && (
                <div className="border-t border-neutral-200 pt-4 mt-2 space-y-3">
                  <label className="block text-sm font-bold text-ink">Spotlight Highlight Badges</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. Tarmac Access"
                      value={newHighlightTitle}
                      onChange={(e) => setNewHighlightTitle(e.target.value)}
                      className="flex-1 rounded-md border border-neutral-300 bg-white p-2 text-sm focus:outline-none focus:border-brand-600"
                    />
                    <select
                      value={newHighlightIcon}
                      onChange={(e) => setNewHighlightIcon(e.target.value)}
                      className="rounded-md border border-neutral-300 bg-white p-2 text-sm focus:outline-none focus:border-brand-600"
                    >
                      <option value="Check">Check</option>
                      <option value="Road">Road</option>
                      <option value="FileText">FileText</option>
                      <option value="Zap">Zap</option>
                      <option value="TrendingUp">TrendingUp</option>
                      <option value="ShieldCheck">ShieldCheck</option>
                    </select>
                    <button
                      type="button"
                      onClick={addHighlight}
                      className="rounded-md bg-brand-600 px-4 py-2 text-sm font-bold text-white hover:bg-brand-700"
                    >
                      Add Badge
                    </button>
                  </div>

                  {formData.highlights?.length > 0 && (
                    <div className="space-y-2 mt-2">
                      {formData.highlights.map((h, idx) => (
                        <div key={idx} className="flex items-center justify-between rounded bg-white border border-neutral-200 px-3 py-2 text-sm">
                          <span><strong>{h.title}</strong> <span className="text-xs text-neutral-400">({h.icon})</span></span>
                          <button
                            type="button"
                            onClick={() => removeHighlight(idx)}
                            className="text-red-600 hover:text-red-800 font-bold text-xs"
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* ================= AMENITIES & FEATURES ================= */}
            <div className="rounded-xl border border-neutral-200 bg-white p-5 space-y-4">
              <label className="block text-sm font-bold text-ink">Amenities & Highlights</label>
              <p className="text-xs text-neutral-500">Add key features like foot traffic, security, backup water, etc.</p>
              
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. High foot traffic location"
                  value={newAmenity}
                  onChange={(e) => setNewAmenity(e.target.value)}
                  className="flex-1 rounded-md border border-neutral-300 p-2.5 text-sm focus:outline-none focus:border-brand-600"
                />
                <button
                  type="button"
                  onClick={addAmenity}
                  className="rounded-md bg-brand-600 px-4 py-2 text-sm font-bold text-white hover:bg-brand-700"
                >
                  Add Feature
                </button>
              </div>

              {formData.amenities?.length > 0 && (
                <div className="flex flex-wrap gap-2 pt-2">
                  {formData.amenities.map((amenity, idx) => (
                    <span key={idx} className="inline-flex items-center gap-1.5 rounded-full bg-brand-50 border border-brand-200 px-3 py-1 text-xs font-semibold text-brand-700">
                      {amenity}
                      <button
                        type="button"
                        onClick={() => removeAmenity(idx)}
                        className="text-red-600 hover:text-red-800 font-bold ml-1"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Property Images Upload */}
            <div>
              <label className="block text-sm font-bold text-ink mb-1">Property Images</label>
              <p className="text-xs text-neutral-500 mb-3">Upload new photos from your computer or provide direct URLs.</p>
              
              <div className="space-y-4">
                {images.map((imgUrl, idx) => (
                  <div key={idx} className="flex items-center gap-2 rounded-lg border border-neutral-200 p-3 bg-neutral-50/50">
                    <div className="flex-1">
                      <ImageUpload
                        value={imgUrl}
                        onChange={(url) => handleImageChange(idx, url)}
                        label={`Upload Image ${idx + 1}`}
                      />
                    </div>
                    {images.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeImageField(idx)}
                        className="rounded-md bg-red-50 p-3 text-red-600 hover:bg-red-100 self-start"
                      >
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={addImageField}
                className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-brand-600 hover:underline"
              >
                <Plus size={16} /> Add another image slot
              </button>
            </div>

            <div>
              <label className="block text-sm font-bold text-ink">Description *</label>
              <textarea
                required
                rows={5}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-4 border-t border-neutral-100 pt-6">
              <Link to="/admin/properties" className="rounded-md border border-neutral-300 px-6 py-3 font-bold text-neutral-700 hover:bg-neutral-50">
                Cancel
              </Link>
              <button
                type="submit"
                disabled={saving}
                className="rounded-md bg-brand-600 px-8 py-3 font-bold text-white hover:bg-brand-700 disabled:opacity-50"
              >
                {saving ? "Saving Changes..." : "Update Property"}
              </button>
            </div>
          </form>
        </div>
      </Container>
    </div>
  );
}