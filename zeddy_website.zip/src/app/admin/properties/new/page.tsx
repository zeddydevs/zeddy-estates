import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export default function NewPropertyPage() {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const control = "w-full rounded-md border border-neutral-300 bg-white px-4 py-3 text-sm focus:border-brand-600 focus:outline-none";

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    setError("");

    const formData = new FormData(e.currentTarget);
    const title = formData.get("title") as string;
    
    // Generate slug from title
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)+/g, "");

    const payload = {
      title,
      slug,
      type: formData.get("type"),
      status: formData.get("status"),
      price: formData.get("price") ? Number(formData.get("price")) : null,
      location: formData.get("location"),
      summary: formData.get("summary"),
      description: formData.get("description"),
      imageUrl: formData.get("imageUrl"),
    };

    try {
      const res = await fetch("/api/properties", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error("Failed to save property to database.");
      }

      alert("Property published successfully!");
      navigate("/admin/properties");
    } catch (err: any) {
      console.error("Submission error:", err);
      setError(err.message || "An error occurred while publishing.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-sand pb-16">
      <header className="bg-white border-b border-neutral-200 px-8 py-4 shadow-xs">
        <Link to="/admin/properties" className="inline-flex items-center gap-2 text-sm font-bold text-neutral-600 hover:text-ink">
          <ArrowLeft size={16} /> Back to Properties
        </Link>
      </header>

      <main className="max-w-3xl mx-auto px-6 mt-10">
        <h2 className="text-3xl font-extrabold text-ink mb-6">Add New Property</h2>

        {error && (
          <div className="mb-6 rounded-md bg-red-50 p-4 text-sm font-semibold text-red-700 border border-red-200">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="rounded-xl border border-neutral-200 bg-white p-8 shadow-xs space-y-6">
          <div>
            <label className="mb-1.5 block text-sm font-semibold text-ink">Property Title</label>
            <input name="title" required className={control} placeholder="e.g. Modern 3-Bedroom Villa in Milimani" />
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Type</label>
              <select name="type" className={control}>
                <option value="Land">Land</option>
                <option value="House">House</option>
                <option value="Apartment">Apartment</option>
                <option value="Commercial">Commercial</option>
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Status</label>
              <select name="status" className={control}>
                <option value="For Sale">For Sale</option>
                <option value="For Rent">For Rent</option>
              </select>
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Price in KES (leave blank for Request)</label>
              <input name="price" type="number" className={control} placeholder="e.g. 14800000" />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Location / Neighborhood</label>
              <input name="location" required className={control} placeholder="e.g. Milimani, Kisumu" />
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-semibold text-ink">Cover Image URL</label>
            <input name="imageUrl" required className={control} placeholder="/images/milimani-1.jfif" />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-semibold text-ink">Summary</label>
            <textarea name="summary" rows={2} required className={control} placeholder="Short blurb for listing cards..." />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-semibold text-ink">Full Description</label>
            <textarea name="description" rows={5} required className={control} placeholder="Detailed property description..." />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-md bg-brand-600 py-3 font-bold text-white hover:bg-brand-700 transition-colors disabled:opacity-50"
          >
            {submitting ? "Saving..." : "Save & Publish Property"}
          </button>
        </form>
      </main>
    </div>
  );
}