import { Link } from 'react-router-dom';
import { redirect } from 'next/navigation';
import { verifyAdminSession } from '@/lib/auth';
import { db } from '@/db';
import { faqs } from '@/db/schema';
import { asc, eq } from 'drizzle-orm';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { revalidatePath } from 'next/cache';

async function handleCreateFaq(formData: FormData) {
  'use server';
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const question = formData.get('question') as string;
  const answer = formData.get('answer') as string;

  await db.insert(faqs).values({
    question,
    answer,
    category: 'General',
    displayOrder: 99,
  });

  revalidatePath('/contact');
  revalidatePath('/admin/faqs');
}

async function deleteFaq(formData: FormData) {
  'use server';
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const id = Number(formData.get('id'));
  await db.delete(faqs).where(eq(faqs.id, id));
  revalidatePath('/contact');
  revalidatePath('/admin/faqs');
}

export default async function AdminFaqsPage() {
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const allFaqs = await db.query.faqs.findMany({
    orderBy: [asc(faqs.displayOrder)],
  });

  return (
    <div className="min-h-screen bg-sand pb-16">
      <header className="bg-white border-b border-neutral-200 px-8 py-4 shadow-xs">
        <Link href="/admin/dashboard" className="inline-flex items-center gap-2 text-sm font-bold text-neutral-600 hover:text-ink">
          <ArrowLeft size={16} /> Back to Dashboard
        </Link>
      </header>

      <main className="max-w-5xl mx-auto px-6 mt-10">
        <h2 className="text-3xl font-extrabold text-ink mb-6">Manage Frequently Asked Questions</h2>

        {/* Add FAQ Form */}
        <form action={handleCreateFaq} className="rounded-xl border border-neutral-200 bg-white p-6 shadow-xs mb-8 space-y-4">
          <h3 className="text-lg font-extrabold text-ink">Add New FAQ</h3>
          <div>
            <label className="mb-1 block text-sm font-semibold text-ink">Question</label>
            <input name="question" required className="w-full rounded-md border border-neutral-300 px-4 py-2.5 text-sm focus:outline-none" placeholder="e.g. Can I pay in instalments?" />
          </div>
          <div>
            <label className="mb-1 block text-sm font-semibold text-ink">Answer</label>
            <textarea name="answer" rows={3} required className="w-full rounded-md border border-neutral-300 px-4 py-2.5 text-sm focus:outline-none" placeholder="Detailed answer..." />
          </div>
          <button type="submit" className="inline-flex items-center gap-2 rounded-md bg-brand-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-brand-700">
            <Plus size={16} /> Save FAQ
          </button>
        </form>

        {/* Existing FAQs Table */}
        <div className="rounded-xl border border-neutral-200 bg-white shadow-xs overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-200 bg-neutral-50 text-xs font-extrabold uppercase tracking-wider text-neutral-600">
                <th className="p-4">Question</th>
                <th className="p-4">Answer</th>
                <th className="p-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-sm">
              {allFaqs.map((faq) => (
                <tr key={faq.id} className="hover:bg-neutral-50/50 align-top">
                  <td className="p-4 font-bold text-ink w-1/3">{faq.question}</td>
                  <td className="p-4 text-neutral-600 w-1/2">{faq.answer}</td>
                  <td className="p-4 text-right">
                    <form action={deleteFaq}>
                      <input type="hidden" name="id" value={faq.id} />
                      <button type="submit" className="rounded p-2 text-red-600 hover:bg-red-50 transition-colors" title="Delete FAQ">
                        <Trash2 size={16} />
                      </button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}