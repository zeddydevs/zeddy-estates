import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Building2, FileText, MessageSquare, Plus, LogOut, Settings, List } from "lucide-react";
import { Container } from "@/components/ui";

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ properties: 0, blogs: 0, enquiries: 0 });

  useEffect(() => {
    const token = localStorage.getItem("zeddy_admin_token");
    if (!token) {
      navigate("/admin/login");
      return;
    }

    // Fetch counts or summary data
    Promise.all([
      fetch("/api/properties").then((res) => res.json()),
      fetch("/api/blog").then((res) => res.json()),
      fetch("/api/enquiries").then((res) => res.json()),
    ])
      .then(([props, blogs, enqs]) => {
        setStats({
          properties: Array.isArray(props) ? props.length : 0,
          blogs: Array.isArray(blogs) ? blogs.length : 0,
          enquiries: Array.isArray(enqs) ? enqs.length : 0,
        });
      })
      .catch((err) => console.error("Failed to load admin metrics", err));
  }, [navigate]);

  function handleLogout() {
    localStorage.removeItem("zeddy_admin_token");
    navigate("/admin/login");
  }

  return (
    <div className="min-h-screen bg-sand pb-16">
      <header className="border-b border-neutral-200 bg-white py-4 shadow-sm">
        <Container className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-600 text-white">
              <Settings size={20} />
            </span>
            <h1 className="font-display text-xl font-extrabold text-ink">Zeddy Admin Hub</h1>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/" className="text-sm font-bold text-neutral-600 hover:text-brand-600">
              View Live Site
            </Link>
            <Link
    to="/admin/password"
    className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-bold text-neutral-700 hover:bg-neutral-100 transition-colors"
  >
    <Settings size={18} className="text-brand-600" />
    Settings
  </Link>
            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-1.5 rounded-md bg-red-50 px-3 py-1.5 text-sm font-bold text-red-600 hover:bg-red-100"
            >
              <LogOut size={16} /> Logout
            </button>

          </div>
        </Container>
      </header>

      <Container className="mt-10">
        <div className="grid gap-6 sm:grid-cols-3">
          {/* Properties Card */}
          <div className="rounded-xl border border-neutral-200 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-neutral-500 uppercase">Total Properties</span>
              <Building2 className="text-brand-600" size={24} />
            </div>
            <p className="mt-3 font-display text-3xl font-extrabold text-ink">{stats.properties}</p>
            <div className="mt-4 flex flex-wrap gap-3">
              <Link to="/admin/properties" className="inline-flex items-center gap-1 rounded bg-neutral-100 px-3 py-1.5 text-xs font-bold text-neutral-700 hover:bg-neutral-200">
                <List size={14} /> Manage All
              </Link>
              <Link to="/admin/properties/new" className="inline-flex items-center gap-1 rounded bg-brand-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-brand-700">
                <Plus size={14} /> Add New
              </Link>
            </div>
          </div>

          {/* Blog Articles Card */}
          <div className="rounded-xl border border-neutral-200 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-neutral-500 uppercase">Blog Articles</span>
              <FileText className="text-brand-600" size={24} />
            </div>
            <p className="mt-3 font-display text-3xl font-extrabold text-ink">{stats.blogs}</p>
            <div className="mt-4 flex flex-wrap gap-3">
              <Link to="/admin/blog" className="inline-flex items-center gap-1 rounded bg-neutral-100 px-3 py-1.5 text-xs font-bold text-neutral-700 hover:bg-neutral-200">
                <List size={14} /> Manage All
              </Link>
              <Link to="/admin/blog/new" className="inline-flex items-center gap-1 rounded bg-brand-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-brand-700">
                <Plus size={14} /> Add New
              </Link>
            </div>
          </div>

          {/* Enquiries Card */}
          <div className="rounded-xl border border-neutral-200 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-neutral-500 uppercase">Client Enquiries</span>
              <MessageSquare className="text-brand-600" size={24} />
            </div>
            <p className="mt-3 font-display text-3xl font-extrabold text-ink">{stats.enquiries}</p>
            <span className="mt-4 block text-xs font-semibold uppercase tracking-wider text-neutral-400">Synced from leads API</span>
          </div>
        </div>
      </Container>
    </div>
  );
}