import { Link } from 'react-router-dom';
import { redirect } from 'next/navigation';
import { verifyAdminSession } from '@/lib/auth';
import { db } from '@/db';
import { enquiries, properties } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';
import { ArrowLeft, MessageCircle, Trash2 } from 'lucide-react';
import { revalidatePath } from 'next/cache';

async function updateLeadStatus(formData: FormData) {
  'use server';
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const id = Number(formData.get('id'));
  const status = formData.get('status') as string;

  await db.update(enquiries).set({ status }).where(eq(enquiries.id, id));
  revalidatePath('/admin/leads');
}

async function deleteLead(formData: FormData) {
  'use server';
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const id = Number(formData.get('id'));
  await db.delete(enquiries).where(eq(enquiries.id, id));
  revalidatePath('/admin/leads');
}

export default async function AdminLeadsPage() {
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  // Fetch enquiries with optional property details joined
  const allLeads = await db.query.enquiries.findMany({
    with: {
      property: true,
    },
    orderBy: [desc(enquiries.createdAt)],
  });

  return (
    <div className="min-h-screen bg-sand pb-16">
      <header className="bg-white border-b border-neutral-200 px-8 py-4 flex justify-between items-center shadow-xs">
        <Link href="/admin/dashboard" className="inline-flex items-center gap-2 text-sm font-bold text-neutral-600 hover:text-ink">
          <ArrowLeft size={16} /> Back to Dashboard
        </Link>
      </header>

      <main className="max-w-7xl mx-auto px-6 mt-10">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-extrabold text-ink">Client Enquiries & Leads</h2>
        </div>

        <div className="rounded-xl border border-neutral-200 bg-white shadow-xs overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-200 bg-neutral-50 text-xs font-extrabold uppercase tracking-wider text-neutral-600">
                <th className="p-4">Client</th>
                <th className="p-4">Property Interest</th>
                <th className="p-4">Message</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-sm">
              {allLeads.map((lead) => {
                const whatsappUrl = `https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  `Hello ${lead.name}, thank you for your enquiry regarding Zeddy Real Estates.`
                )}`;

                return (
                  <tr key={lead.id} className="hover:bg-neutral-50/50 align-top">
                    <td className="p-4">
                      <p className="font-bold text-ink">{lead.name}</p>
                      <p className="text-xs text-neutral-500">{lead.phone}</p>
                      {lead.email && <p className="text-xs text-neutral-500">{lead.email}</p>}
                    </td>
                    <td className="p-4">
                      {lead.property ? (
                        <Link href={`/properties/${lead.property.slug}`} target="_blank" className="font-semibold text-brand-700 hover:underline">
                          {lead.property.title}
                        </Link>
                      ) : (
                        <span className="text-neutral-400 italic">General Website Enquiry</span>
                      )}
                    </td>
                    <td className="p-4 text-neutral-700 max-w-xs">{lead.message}</td>
                    <td className="p-4">
                      <form action={updateLeadStatus} className="inline-block">
                        <input type="hidden" name="id" value={lead.id} />
                        <select
                          name="status"
                          defaultValue={lead.status}
                          onChange={(e) => e.target.form?.requestSubmit()}
                          className="rounded-md border border-neutral-300 bg-white px-2.5 py-1.5 text-xs font-bold text-ink focus:outline-none"
                        >
                          <option value="New">New</option>
                          <option value="Contacted">Contacted</option>
                          <option value="Closed">Closed</option>
                        </select>
                      </form>
                    </td>
                    <td className="p-4 text-right space-x-2">
                      <a
                        href={whatsappUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 rounded bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-700 transition-colors"
                      >
                        <MessageCircle size={14} /> WhatsApp
                      </a>
                      <form action={deleteLead} className="inline-block">
                        <input type="hidden" name="id" value={lead.id} />
                        <button type="submit" className="rounded p-1.5 text-red-600 hover:bg-red-50 transition-colors" title="Delete Lead">
                          <Trash2 size={16} />
                        </button>
                      </form>
                    </td>
                  </tr>
                );
              })}
              {allLeads.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-neutral-500">
                    No client enquiries received yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}