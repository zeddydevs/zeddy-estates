import { useState, useEffect } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { ArrowLeft, FileText } from "lucide-react";
import { Container } from "@/components/ui";
import ImageUpload from "@/components/admin/ImageUpload";

export default function EditBlogPostPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    category: "Real Estate Market",
    excerpt: "",
    content: "",
    author: "",
    image: "",
    imageAlt: "",
    readTime: "4 min read",
  });

  useEffect(() => {
    fetch("/api/blog")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          const post = data.find((p: any) => String(p.id) === String(id));
          if (post) {
            setFormData({
              title: post.title || "",
              slug: post.slug || "",
              category: post.category || "Real Estate Market",
              excerpt: post.excerpt || "",
              content: typeof post.content === "string" ? post.content : Array.isArray(post.contentBlocks) ? post.contentBlocks.map(b => b.text).join("\n\n") : "",
              author: post.author || "",
              image: post.coverImage || post.image || "",
              imageAlt: post.imageAlt || "",
              readTime: post.readTime || "4 min read",
            });
          } else {
            setError("Blog post not found.");
          }
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setError("Failed to load article.");
        setLoading(false);
      });
  }, [id]);

  async function handleUpdate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");

    const token = localStorage.getItem("zeddy_admin_token");

    const payload = {
      ...formData,
      coverImage: formData.image,
      contentBlocks: [{ type: "p", text: formData.content }],
    };

    try {
      const res = await fetch(`/api/blog/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to update article");
      }

      navigate("/admin/blog");
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong.");
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="py-20 text-center font-semibold text-neutral-500">Loading article...</div>;
  }

  return (
    <div className="min-h-screen bg-sand pb-20">
      <header className="border-b border-neutral-200 bg-white py-4 shadow-sm">
        <Container className="flex items-center justify-between">
          <Link to="/admin/blog" className="inline-flex items-center gap-2 text-sm font-bold text-brand-700 hover:underline">
            <ArrowLeft size={16} /> Back to Blog Manager
          </Link>
          <h1 className="font-display text-lg font-extrabold text-ink">Edit Article</h1>
        </Container>
      </header>

      <Container className="mt-10 max-w-3xl">
        <div className="rounded-xl border border-neutral-200 bg-white p-8 shadow-sm">
          <div className="flex items-center gap-3 border-b border-neutral-100 pb-5">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
              <FileText size={20} />
            </span>
            <div>
              <h2 className="text-xl font-extrabold text-ink">Update Article</h2>
              <p className="text-sm text-neutral-600">Modify article reference #{id}</p>
            </div>
          </div>

          {error && <div className="mt-6 rounded-md bg-red-50 p-4 text-sm font-bold text-red-600">{error}</div>}

          <form onSubmit={handleUpdate} className="mt-6 space-y-6">
            <div>
              <label className="block text-sm font-bold text-ink">Article Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div className="grid gap-6 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-bold text-ink">URL Slug *</label>
                <input
                  type="text"
                  required
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 bg-neutral-50 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Category *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 bg-white p-3 text-sm focus:border-brand-600 focus:outline-none"
                >
                  <option value="Real Estate Market">Real Estate Market</option>
                  <option value="Buying Guide">Buying Guide</option>
                  <option value="Investment Tips">Investment Tips</option>
                  <option value="Company News">Company News</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Author *</label>
                <input
                  type="text"
                  required
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Read Time *</label>
                <input
                  type="text"
                  required
                  value={formData.readTime}
                  onChange={(e) => setFormData({ ...formData, readTime: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>
            </div>

            {/* Featured Image Upload */}
            <div>
              <label className="block text-sm font-bold text-ink mb-1">Featured Cover Image</label>
              <p className="text-xs text-neutral-500 mb-3">Upload a new cover photo or provide a direct image URL.</p>
              <ImageUpload
                value={formData.image}
                onChange={(url) => setFormData({ ...formData, image: url })}
                label="Upload Cover Image"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-ink">Cover Image Alt Text</label>
              <input
                type="text"
                value={formData.imageAlt}
                onChange={(e) => setFormData({ ...formData, imageAlt: e.target.value })}
                placeholder="Description of the cover image for accessibility"
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-ink">Excerpt / Summary *</label>
              <textarea
                required
                rows={2}
                value={formData.excerpt}
                onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-ink">Full Content *</label>
              <textarea
                required
                rows={8}
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-4 border-t border-neutral-100 pt-6">
              <Link to="/admin/blog" className="rounded-md border border-neutral-300 px-6 py-3 font-bold text-neutral-700 hover:bg-neutral-50">
                Cancel
              </Link>
              <button
                type="submit"
                disabled={saving}
                className="rounded-md bg-brand-600 px-8 py-3 font-bold text-white hover:bg-brand-700 disabled:opacity-50"
              >
                {saving ? "Saving Changes..." : "Update Article"}
              </button>
            </div>
          </form>
        </div>
      </Container>
    </div>
  );
}