import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, FileText } from "lucide-react";
import { Container } from "@/components/ui";
import ImageUpload from "@/components/admin/ImageUpload";

export default function NewBlogPostPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    category: "Real Estate Market",
    excerpt: "",
    content: "",
    author: "Zeddy Team",
    image: "",
    imageAlt: "",
    readTime: "4 min read",
  });

  function handleTitleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const val = e.target.value;
    const generatedSlug = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");

    setFormData((prev) => ({ 
      ...prev, 
      title: val, 
      slug: generatedSlug,
      imageAlt: prev.imageAlt || val 
    }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const token = localStorage.getItem("zeddy_admin_token");

    const payload = {
      ...formData,
      coverImage: formData.image,
      date: new Date().toISOString().split('T')[0],
      contentBlocks: [{ type: "p", text: formData.content }],
    };

    try {
      const res = await fetch("/api/blog", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to create blog post");
      }

      navigate("/admin/blog");
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong.");
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-sand pb-20">
      <header className="border-b border-neutral-200 bg-white py-4 shadow-sm">
        <Container className="flex items-center justify-between">
          <Link to="/admin/blog" className="inline-flex items-center gap-2 text-sm font-bold text-brand-700 hover:underline">
            <ArrowLeft size={16} /> Back to Blog Manager
          </Link>
          <h1 className="font-display text-lg font-extrabold text-ink">Add New Article</h1>
        </Container>
      </header>

      <Container className="mt-10 max-w-3xl">
        <div className="rounded-xl border border-neutral-200 bg-white p-8 shadow-sm">
          <div className="flex items-center gap-3 border-b border-neutral-100 pb-5">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
              <FileText size={20} />
            </span>
            <div>
              <h2 className="text-xl font-extrabold text-ink">Article Details</h2>
              <p className="text-sm text-neutral-600">Write and publish real estate guides and insights.</p>
            </div>
          </div>

          {error && <div className="mt-6 rounded-md bg-red-50 p-4 text-sm font-bold text-red-600">{error}</div>}

          <form onSubmit={handleSubmit} className="mt-6 space-y-6">
            <div>
              <label className="block text-sm font-bold text-ink">Article Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={handleTitleChange}
                placeholder="e.g. A Complete Guide to Buying Land in Kisumu"
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div className="grid gap-6 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-bold text-ink">URL Slug *</label>
                <input
                  type="text"
                  required
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 bg-neutral-50 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Category *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 bg-white p-3 text-sm focus:border-brand-600 focus:outline-none"
                >
                  <option value="Real Estate Market">Real Estate Market</option>
                  <option value="Buying Guide">Buying Guide</option>
                  <option value="Investment Tips">Investment Tips</option>
                  <option value="Company News">Company News</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Author *</label>
                <input
                  type="text"
                  required
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-ink">Read Time *</label>
                <input
                  type="text"
                  required
                  value={formData.readTime}
                  onChange={(e) => setFormData({ ...formData, readTime: e.target.value })}
                  placeholder="e.g. 4 min read"
                  className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
                />
              </div>
            </div>

            {/* Featured Image Upload */}
            <div>
              <label className="block text-sm font-bold text-ink mb-1">Featured Cover Image</label>
              <p className="text-xs text-neutral-500 mb-3">Upload a cover photo or provide a direct image URL.</p>
              <ImageUpload
                value={formData.image}
                onChange={(url) => setFormData({ ...formData, image: url })}
                label="Upload Cover Image"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-ink">Cover Image Alt Text</label>
              <input
                type="text"
                value={formData.imageAlt}
                onChange={(e) => setFormData({ ...formData, imageAlt: e.target.value })}
                placeholder="Description of the cover image for accessibility"
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-ink">Excerpt / Summary *</label>
              <textarea
                required
                rows={2}
                value={formData.excerpt}
                onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                placeholder="Brief summary shown on blog list cards..."
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-ink">Full Content (Markdown or Paragraphs) *</label>
              <textarea
                required
                rows={8}
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                placeholder="Write your article content here..."
                className="mt-1 w-full rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-4 border-t border-neutral-100 pt-6">
              <Link to="/admin/blog" className="rounded-md border border-neutral-300 px-6 py-3 font-bold text-neutral-700 hover:bg-neutral-50">
                Cancel
              </Link>
              <button
                type="submit"
                disabled={loading}
                className="rounded-md bg-brand-600 px-8 py-3 font-bold text-white hover:bg-brand-700 disabled:opacity-50"
              >
                {loading ? "Publishing..." : "Publish Article"}
              </button>
            </div>
          </form>
        </div>
      </Container>
    </div>
  );
}