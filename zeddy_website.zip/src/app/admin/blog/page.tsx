import { Link } from 'react-router-dom';
import { redirect } from 'next/navigation';
import { verifyAdminSession } from '@/lib/auth';
import { db } from '@/db';
import { blogPosts } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';
import { Trash2, Plus, ArrowLeft, FileText } from 'lucide-react';
import { revalidatePath } from 'next/cache';

async function deleteBlogPost(formData: FormData) {
  'use server';
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const id = Number(formData.get('id'));
  await db.delete(blogPosts).where(eq(blogPosts.id, id));
  revalidatePath('/blog');
  revalidatePath('/admin/blog');
}

export default async function AdminBlogPage() {
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const allPosts = await db.query.blogPosts.findMany({
    orderBy: [desc(blogPosts.createdAt)],
  });

  return (
    <div className="min-h-screen bg-sand pb-16">
      <header className="bg-white border-b border-neutral-200 px-8 py-4 flex justify-between items-center shadow-xs">
        <Link href="/admin/dashboard" className="inline-flex items-center gap-2 text-sm font-bold text-neutral-600 hover:text-ink">
          <ArrowLeft size={16} /> Back to Dashboard
        </Link>
        <Link
          href="/admin/blog/new"
          className="inline-flex items-center gap-2 rounded-md bg-brand-600 px-4 py-2 text-sm font-bold text-white hover:bg-brand-700"
        >
          <Plus size={16} /> Add Article
        </Link>
      </header>

      <main className="max-w-7xl mx-auto px-6 mt-10">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-extrabold text-ink">Manage Blog Articles</h2>
        </div>

        <div className="rounded-xl border border-neutral-200 bg-white shadow-xs overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-200 bg-neutral-50 text-xs font-extrabold uppercase tracking-wider text-neutral-600">
                <th className="p-4">Title</th>
                <th className="p-4">Category</th>
                <th className="p-4">Author</th>
                <th className="p-4">Date</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-sm">
              {allPosts.map((post) => (
                <tr key={post.id} className="hover:bg-neutral-50/50">
                  <td className="p-4 font-bold text-ink max-w-md truncate">{post.title}</td>
                  <td className="p-4">
                    <span className="inline-block rounded-full bg-brand-50 text-brand-700 px-3 py-1 text-xs font-bold border border-brand-200">
                      {post.category}
                    </span>
                  </td>
                  <td className="p-4 text-neutral-600">{post.author}</td>
                  <td className="p-4 text-neutral-600">{post.date}</td>
                  <td className="p-4 text-right">
                    <form action={deleteBlogPost} className="inline-block">
                      <input type="hidden" name="id" value={post.id} />
                      <button
                        type="submit"
                        className="rounded p-2 text-red-600 hover:bg-red-50 transition-colors"
                        title="Delete Article"
                      >
                        <Trash2 size={16} />
                      </button>
                    </form>
                  </td>
                </tr>
              ))}
              {allPosts.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-neutral-500">
                    No blog articles found. Create your first post!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}