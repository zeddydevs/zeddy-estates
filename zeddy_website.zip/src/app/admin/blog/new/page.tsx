import { Link } from 'react-router-dom';
import { redirect } from 'next/navigation';
import { verifyAdminSession } from '@/lib/auth';
import { db } from '@/db';
import { blogPosts } from '@/db/schema';
import { ArrowLeft } from 'lucide-react';
import { revalidatePath } from 'next/cache';

async function handleCreateBlogPost(formData: FormData) {
  'use server';
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const title = formData.get('title') as string;
  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
  const category = formData.get('category') as string;
  const author = formData.get('author') as string || 'Zeddy Real Estates';
  const excerpt = formData.get('excerpt') as string;
  const coverImage = formData.get('coverImage') as string;
  const readTime = formData.get('readTime') as string || '5 min read';
  const rawContent = formData.get('content') as string;

  // Convert plaintext multi-paragraph text or JSON blocks into structured JSON blocks format
  const contentBlocks = rawContent
    .split('\n\n')
    .filter(Boolean)
    .map((paragraph) => ({ type: 'p', text: paragraph.trim() }));

  const currentDate = new Date().toISOString().split('T')[0];

  await db.insert(blogPosts).values({
    slug,
    title,
    category,
    author,
    excerpt,
    coverImage,
    readTime,
    date: currentDate,
    tags: [category, 'Kisumu', 'Real Estate'],
    contentBlocks,
  });

  revalidatePath('/blog');
  revalidatePath('/admin/blog');
  redirect('/admin/blog');
}

export default async function NewBlogPostPage() {
  const isAuthed = await verifyAdminSession();
  if (!isAuthed) redirect('/admin/login');

  const control = "w-full rounded-md border border-neutral-300 bg-white px-4 py-3 text-sm focus:border-brand-600 focus:outline-none";

  return (
    <div className="min-h-screen bg-sand pb-16">
      <header className="bg-white border-b border-neutral-200 px-8 py-4 shadow-xs">
        <Link href="/admin/blog" className="inline-flex items-center gap-2 text-sm font-bold text-neutral-600 hover:text-ink">
          <ArrowLeft size={16} /> Back to Blog Articles
        </Link>
      </header>

      <main className="max-w-3xl mx-auto px-6 mt-10">
        <h2 className="text-3xl font-extrabold text-ink mb-6">Write New Article</h2>

        <form action={handleCreateBlogPost} className="rounded-xl border border-neutral-200 bg-white p-8 shadow-xs space-y-6">
          <div>
            <label className="mb-1.5 block text-sm font-semibold text-ink">Article Title</label>
            <input name="title" required className={control} placeholder="e.g. 5 Key Factors When Buying Commercial Land in Kisumu" />
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Category</label>
              <input name="category" required className={control} placeholder="e.g. Buying Guide" />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Read Time</label>
              <input name="readTime" defaultValue="6 min read" className={control} />
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Author Name</label>
              <input name="author" defaultValue="Zeddy Real Estates" className={control} />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-ink">Cover Image URL</label>
              <input name="coverImage" required className={control} placeholder="/images/kisumu.avif" />
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-semibold text-ink">Short Excerpt (for preview cards)</label>
            <textarea name="excerpt" rows={2} required className={control} placeholder="Brief summary of the article..." />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-semibold text-ink">Article Paragraphs (separate paragraphs with blank lines)</label>
            <textarea name="content" rows={8} required className={control} placeholder="Paragraph 1...&#10;&#10;Paragraph 2..." />
          </div>

          <button
            type="submit"
            className="w-full rounded-md bg-brand-600 py-3 font-bold text-white hover:bg-brand-700 transition-colors"
          >
            Publish Article
          </button>
        </form>
      </main>
    </div>
  );
}