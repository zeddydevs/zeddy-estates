import { db } from '@/db';
import { 
  properties as propertiesTable, 
  propertyImages, 
  blogPosts as blogPostsTable, 
  faqs as faqsTable 
} from '@/db/schema';
import { properties } from '@/data/properties';
import { blogPosts } from '@/data/blog';

interface FaqItem {
  q: string;
  a: string;
}

const sampleFaqs: FaqItem[] = [
  {
    q: "How do I book a site visit?",
    a: "Call or WhatsApp us on 0703 287 361, or fill in the enquiry form on any property page. Tell us which property you are interested in and your preferred date, and we will confirm a time and meet you on site.",
  },
  {
    q: "Which areas do you cover?",
    a: "We focus on Kisumu city and its surrounding neighbourhoods, including Milimani, Riat, Nyamasaria, Dunga, Gambogi, Kondele and the CBD. If you are looking in a specific area, let us know and we will help you find options.",
  },
  {
    q: "Should I carry out due diligence before buying?",
    a: "Absolutely. We encourage every buyer to conduct an official search, confirm ownership and boundaries with a licensed surveyor and work with a qualified advocate. We are happy to share the documents we hold for a listing and guide you through the process.",
  },
  {
    q: "Some listings say 'Price on Request'. How do I get the price?",
    a: "Simply call, WhatsApp or email us and mention the property name or reference number. Our team will share the asking price and any available payment options.",
  },
  {
    q: "Can I pay in instalments?",
    a: "Payment terms depend on the property and the seller. Some listings may allow flexible payment plans – ask us about the specific property and we will confirm what is available.",
  },
  {
    q: "Can I list my property with Zeddy Real Estates?",
    a: "Yes. If you want to sell or rent out land, a house, an apartment or a commercial building, contact us with a few details and photos. We will help you price, present and market it.",
  },
];

async function seed() {
  console.log('🌱 Seeding PostgreSQL database for Zeddy Real Estates...');

  try {
    // 1. Clear existing rows in dependency order
    await db.delete(propertyImages);
    await db.delete(propertiesTable);
    await db.delete(blogPostsTable);
    await db.delete(faqsTable);

    // 2. Seed Properties & Gallery Images
    console.log('📦 Seeding properties...');
    for (const p of properties) {
      const [insertedProperty] = await db.insert(propertiesTable).values({
        slug: p.slug,
        title: p.title,
        type: p.type,
        status: p.status,
        price: p.price !== null ? p.price.toString() : null,
        priceNote: p.priceNote ?? null,
        location: p.location,
        area: p.area ?? null,
        address: p.address ?? null,
        mapQuery: p.mapQuery ?? null,
        landSize: p.landSize ?? null,
        floorArea: p.floorArea ?? null,
        bedrooms: p.bedrooms ?? null,
        bathrooms: p.bathrooms ?? null,
        parking: p.parking ?? null,
        floors: p.floors ?? null,
        condition: p.condition ?? null,
        summary: p.summary,
        description: Array.isArray(p.description) ? p.description.join('\n\n') : p.description,
        highlights: p.highlights ?? [],
        amenities: p.amenities ?? [],
        idealFor: p.idealFor ?? [],
        whyInvest: p.whyInvest ?? [],
        tags: p.tags ?? [],
        badge: p.badge ?? null,
        isFeatured: p.featured ?? false,
        datePosted: p.datePosted,
      }).returning({ id: propertiesTable.id });

      if (p.images && p.images.length > 0) {
        await db.insert(propertyImages).values(
          p.images.map((img, index) => ({
            propertyId: insertedProperty.id,
            url: img.src,
            displayOrder: index,
          }))
        );
      }
    }

    // 3. Seed Blog Posts
    console.log('📝 Seeding blog posts...');
    for (const post of blogPosts) {
      await db.insert(blogPostsTable).values({
        slug: post.slug,
        title: post.title,
        category: post.category,
        author: post.author,
        excerpt: post.excerpt,
        coverImage: post.image,
        imageAlt: post.imageAlt,
        readTime: post.readTime,
        date: post.date,
        tags: post.tags ?? [],
        contentBlocks: post.content ?? [],
      });
    }

    // 4. Seed FAQs
    console.log('❓ Seeding FAQs...');
    for (const [index, faq] of sampleFaqs.entries()) {
      await db.insert(faqsTable).values({
        question: faq.q,
        answer: faq.a,
        category: 'General',
        displayOrder: index + 1,
      });
    }

    console.log('✅ All data seeded successfully into PostgreSQL!');
  } catch (error) {
    console.error('❌ Error during seeding:', error);
    process.exit(1);
  }
  process.exit(0);
}

seed();