import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "./schema";

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error("DATABASE_URL environment variable is missing.");
}

// Prevent multiple database connections during hot reloads in development
declare global {
  var postgresClient: postgres.Sql | undefined;
}

let client: postgres.Sql;

if (process.env.NODE_ENV === "production") {
  client = postgres(connectionString, { prepare: false });
} else {
  if (!global.postgresClient) {
    global.postgresClient = postgres(connectionString, { prepare: false });
  }
  client = global.postgresClient;
}

export const db = drizzle(client, { schema });