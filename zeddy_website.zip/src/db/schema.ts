import { pgTable, serial, text, timestamp, integer, boolean, numeric, jsonb } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
// Admin Users Table
export const admins = pgTable('admins', {
  id: serial('id').primaryKey(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  name: text('name').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Properties Table
export const properties = pgTable('properties', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  title: text('title').notNull(),
  type: text('type').notNull(), // 'House', 'Apartment', 'Land', 'Commercial'
  status: text('status').notNull(), // 'For Sale', 'For Rent'
  price: numeric('price', { precision: 12, scale: 2 }), // null = Price on Request
  priceNote: text('price_note'),
  location: text('location').notNull(),
  area: text('area'),
  address: text('address'),
  mapQuery: text('map_query'),
  landSize: text('land_size'),
  floorArea: text('floor_area'),
  bedrooms: integer('bedrooms'),
  bathrooms: integer('bathrooms'),
  parking: integer('parking'),
  floors: integer('floors'),
  condition: text('condition'),
  summary: text('summary').notNull(),
  description: text('description').notNull(), // Joined paragraphs
  highlights: jsonb('highlights').default([]).notNull(), // Array of objects
  amenities: jsonb('amenities').default([]).notNull(), // Array of strings
  idealFor: jsonb('ideal_for').default([]).notNull(), // Array of objects
  whyInvest: jsonb('why_invest').default([]).notNull(), // Array of strings
  tags: jsonb('tags').default([]).notNull(), // Array of strings
  badge: text('badge'),
  isFeatured: boolean('is_featured').default(false).notNull(),
  date_posted: text("date_posted").default(""),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Property Images Table
export const propertyImages = pgTable('property_images', {
  id: serial('id').primaryKey(),
  propertyId: integer('property_id').references(() => properties.id, { onDelete: 'cascade' }).notNull(),
  url: text('url').notNull(),
  displayOrder: integer('display_order').default(0).notNull(),
});

// Blog Posts Table
export const blogPosts = pgTable('blog_posts', {
  id: serial('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  title: text('title').notNull(),
  category: text('category').notNull(),
  author: text('author').notNull(),
  excerpt: text('excerpt').notNull(),
  coverImage: text('cover_image'),
  imageAlt: text('image_alt'),
  readTime: text('read_time').notNull(),
  date: text('date').notNull(),
  tags: jsonb('tags').default([]).notNull(), // Array of strings
  contentBlocks: jsonb('content_blocks').default([]).notNull(), // Structured blocks (h2, p, ul, ol, callout)
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// FAQs Table
export const faqs = pgTable('faqs', {
  id: serial('id').primaryKey(),
  question: text('question').notNull(),
  answer: text('answer').notNull(),
  category: text('category').default('General').notNull(),
  displayOrder: integer('display_order').default(0).notNull(),
});

// Enquiries / Leads Table
export const enquiries = pgTable('enquiries', {
  id: serial('id').primaryKey(),
  propertyId: integer('property_id').references(() => properties.id, { onDelete: 'set null' }),
  name: text('name').notNull(),
  phone: text('phone').notNull(),
  email: text('email'),
  message: text('message').notNull(),
  status: text('status').default('New').notNull(), // 'New', 'Contacted', 'Closed'
  createdAt: timestamp('created_at').defaultNow().notNull(),
});
// Relations Definitions
export const propertiesRelations = relations(properties, ({ many }) => ({
  images: many(propertyImages),
  enquiries: many(enquiries),
}));

export const propertyImagesRelations = relations(propertyImages, ({ one }) => ({
  property: one(properties, {
    fields: [propertyImages.propertyId],
    references: [properties.id],
  }),
}));

export const enquiriesRelations = relations(enquiries, ({ one }) => ({
  property: one(properties, {
    fields: [enquiries.propertyId],
    references: [properties.id],
  }),
}));