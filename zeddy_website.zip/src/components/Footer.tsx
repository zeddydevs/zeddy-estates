import { Link } from "react-router-dom";
import { ArrowRight, Clock, Mail, MapPin, Phone } from "lucide-react";
import Logo from "./Logo";
import WhatsAppIcon from "./WhatsAppIcon";
import { NAV_LINKS, SITE } from "../config/site";
import { telLink, waLink } from "../lib/format";

const TYPE_LINKS = [
  { label: "Land & Plots", to: "/properties?type=Land" },
  { label: "Houses", to: "/properties?type=House" },
  { label: "Apartments", to: "/properties?type=Apartment" },
  { label: "Commercial", to: "/properties?type=Commercial" },
  { label: "Properties for Rent", to: "/properties?status=For%20Rent" },
];

export default function Footer() {
  return (
    <footer className="bg-brand-950 text-white/80">
      <div className="mx-auto max-w-7xl px-4 pb-8 pt-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-12">
          {/* Brand */}
          <div className="lg:col-span-4">
            <Logo variant="light" showTagline />
            <p className="mt-6 max-w-sm text-[15px] leading-relaxed text-white/70">
              Zeddy Real Estates helps buyers, sellers, tenants and investors find secure, high-potential property in
              Kenya with honest advice and guided site visits every step of the way.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href={telLink}
                className="inline-flex items-center gap-2 rounded-md bg-accent-500 px-4 py-2.5 text-sm font-bold text-ink transition-colors hover:bg-accent-400"
              >
                <Phone size={16} aria-hidden="true" /> {SITE.phoneDisplay}
              </a>
              <a
                href={waLink(`Hello ${SITE.name}, I would like to enquire about a property.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-md border border-white/25 px-4 py-2.5 text-sm font-bold text-white transition-colors hover:bg-white hover:text-brand-950"
              >
                <WhatsAppIcon size={16} /> WhatsApp
              </a>
            </div>
          </div>

          {/* Quick links */}
          <nav aria-label="Footer quick links" className="lg:col-span-2">
            <h3 className="text-base font-bold text-white">Quick Links</h3>
            <ul className="mt-5 space-y-3 text-[15px]">
              {NAV_LINKS.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="inline-flex items-center gap-1.5 hover:text-accent-400">
                    <ArrowRight size={14} aria-hidden="true" /> {l.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link to="/sitemap" className="inline-flex items-center gap-1.5 hover:text-accent-400">
                  <ArrowRight size={14} aria-hidden="true" /> Sitemap
                </Link>
              </li>
            </ul>
          </nav>

          {/* Property types */}
          <nav aria-label="Property categories" className="lg:col-span-3">
            <h3 className="text-base font-bold text-white">Browse Properties</h3>
            <ul className="mt-5 space-y-3 text-[15px]">
              {TYPE_LINKS.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="inline-flex items-center gap-1.5 hover:text-accent-400">
                    <ArrowRight size={14} aria-hidden="true" /> {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div className="lg:col-span-3">
            <h3 className="text-base font-bold text-white">Get in Touch</h3>
            <ul className="mt-5 space-y-4 text-[15px]">
              <li className="flex gap-3">
                <MapPin size={18} className="mt-0.5 shrink-0 text-accent-500" aria-hidden="true" />
                <span>{SITE.address.street}</span>
              </li>
              <li className="flex gap-3">
                <Phone size={18} className="mt-0.5 shrink-0 text-accent-500" aria-hidden="true" />
                <a href={telLink} className="hover:text-accent-400">
                  {SITE.phoneDisplay}
                </a>
              </li>
              <li className="flex gap-3">
                <Mail size={18} className="mt-0.5 shrink-0 text-accent-500" aria-hidden="true" />
                <a href={`mailto:${SITE.email}`} className="break-all hover:text-accent-400">
                  {SITE.email}
                </a>
              </li>
              <li className="flex gap-3">
                <Clock size={18} className="mt-0.5 shrink-0 text-accent-500" aria-hidden="true" />
                <span>
                  Mon – Fri: 8:00 AM – 6:00 PM
                  <br />
                  Sat: 8:00 AM – 5:00 PM
                </span>
              </li>
            </ul>
          </div>
        </div>

        
      </div>
    </footer>
  );
}
