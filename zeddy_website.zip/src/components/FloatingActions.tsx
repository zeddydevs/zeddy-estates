import { Phone } from "lucide-react";
import WhatsAppIcon from "./WhatsAppIcon";
import { SITE } from "../config/site";
import { telLink, waLink } from "../lib/format";

/**
 * Fixed pulsing WhatsApp button with a pulsing call button right below it.
 */
export default function FloatingActions() {
  const message = `Hello ${SITE.name}, I would like to enquire about a property.`;

  return (
    <div className="fixed bottom-5 right-4 z-50 flex flex-col items-center gap-4 sm:bottom-6 sm:right-6">
      <a
        href={waLink(message)}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with us on WhatsApp"
        title="Chat on WhatsApp"
        style={{ "--pulse-color": "#25d366" } as React.CSSProperties}
        className="pulse-btn group flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-white shadow-lg transition-transform hover:scale-110 sm:h-16 sm:w-16"
      >
        <WhatsAppIcon size={32} />
        <span className="pointer-events-none absolute right-full mr-3 hidden whitespace-nowrap rounded-md bg-ink px-3 py-1.5 text-sm font-semibold text-white opacity-0 shadow-md transition-opacity group-hover:opacity-100 md:block">
          Chat on WhatsApp
        </span>
      </a>

      <a
        href={telLink}
        aria-label={`Call us on ${SITE.phoneDisplay}`}
        title={`Call ${SITE.phoneDisplay}`}
        style={{ "--pulse-color": "#0f6a31" } as React.CSSProperties}
        className="pulse-btn group flex h-14 w-14 items-center justify-center rounded-full bg-brand-600 text-white shadow-lg transition-transform hover:scale-110 sm:h-16 sm:w-16"
      >
        <Phone size={28} strokeWidth={2.2} aria-hidden="true" />
        <span className="pointer-events-none absolute right-full mr-3 hidden whitespace-nowrap rounded-md bg-ink px-3 py-1.5 text-sm font-semibold text-white opacity-0 shadow-md transition-opacity group-hover:opacity-100 md:block">
          Call {SITE.phoneDisplay}
        </span>
      </a>
    </div>
  );
}
