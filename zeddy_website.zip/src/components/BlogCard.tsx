import { Link } from "react-router-dom";
import { ArrowRight, Calendar, Clock } from "lucide-react";
import type { BlogPost } from "../data/types";
import { formatDate, sized } from "../lib/format";

export default function BlogCard({ post }: { post: any }) {
  // Safely resolve image source supporting coverImage, image, or uploads
  const rawImageSrc = post.coverImage || post.image || "/images/banner.jfif";
  const finalImageSrc = 
    rawImageSrc.startsWith("http") || rawImageSrc.startsWith("/") 
      ? rawImageSrc 
      : sized(rawImageSrc, 800, 500);

  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-xl border border-neutral-200 bg-white transition-shadow duration-300 hover:shadow-xl">
      <div className="relative aspect-[16/10] overflow-hidden bg-neutral-100">
        <img
          src={finalImageSrc}
          alt={post.imageAlt || post.title}
          width={800}
          height={500}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {post.category && (
          <span className="absolute left-3 top-3 rounded-md bg-accent-500 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-ink">
            {post.category}
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-6">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px] text-neutral-500">
          <span className="inline-flex items-center gap-1.5">
            <Calendar size={14} aria-hidden="true" />
            <time dateTime={post.date}>{formatDate(post.date)}</time>
          </span>
          {post.readTime && (
            <span className="inline-flex items-center gap-1.5">
              <Clock size={14} aria-hidden="true" /> {post.readTime}
            </span>
          )}
        </div>
        <h3 className="mt-3 text-xl font-extrabold leading-snug text-ink">
          <Link to={`/blog/${post.slug}`} className="after:absolute after:inset-0 after:content-[''] hover:text-brand-600">
            {post.title}
          </Link>
        </h3>
        <p className="mt-3 line-clamp-3 text-[15px] leading-relaxed text-neutral-600">{post.excerpt}</p>
        <span className="mt-auto inline-flex items-center gap-2 pt-5 text-sm font-bold text-brand-600">
          Read article <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" aria-hidden="true" />
        </span>
      </div>
    </article>
  );
}