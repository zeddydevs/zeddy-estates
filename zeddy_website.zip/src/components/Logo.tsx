import { Link } from "react-router-dom";

/**
 * Vector recreation of the Zeddy Real Estates roof mark.
 * To use the original artwork instead, drop your logo into /public (e.g. logo.png)
 * and replace <LogoMark /> below with <img src="/logo.png" alt="Zeddy Real Estates" />.
 */
export function LogoMark({
  className = "",
  green = "#0f6a31",
  dark = "#111513",
}: {
  className?: string;
  green?: string;
  dark?: string;
}) {
  return (
    <svg
      viewBox="100 80 920 420"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      focusable="false"
    >
      {/* green roof + chimney + diamond */}
      <rect x="265" y="207" width="40" height="78" rx="12" fill={green} />
      <path d="M105 443 L368 180 L458 268 L412 316 L372 276 L245 396 Z" fill={green} />
      <rect x="428" y="208" width="36" height="36" fill={green} transform="rotate(45 446 226)" />
      {/* black main roof */}
      <path d="M410 318 L635 88 L992 446 L872 420 L635 190 L460 366 Z" fill={dark} />
      {/* window */}
      <rect x="595" y="280" width="38" height="38" fill={dark} />
      <rect x="641" y="280" width="38" height="38" fill={dark} />
      <rect x="595" y="326" width="38" height="38" fill={dark} />
      <rect x="641" y="326" width="38" height="38" fill={dark} />
      {/* swoosh */}
      <path d="M105 492 Q560 298 1015 492 Q560 340 105 492 Z" fill={dark} />
    </svg>
  );
}

interface LogoProps {
  variant?: "dark" | "light";
  className?: string;
  showTagline?: boolean;
  asLink?: boolean;
}

export default function Logo({ variant = "dark", className = "", showTagline = false, asLink = true }: LogoProps) {
  const light = variant === "light";
  const content = (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <LogoMark
        className="h-10 w-auto sm:h-11"
        green={light ? "#62b72a" : "#0f6a31"}
        dark={light ? "#ffffff" : "#111513"}
      />
      <span className="flex flex-col leading-none">
        <span
          className={`font-display text-[26px] font-extrabold tracking-tight sm:text-[30px] ${
            light ? "text-accent-500" : "text-brand-600"
          }`}
        >
          ZEDDY
        </span>
        <span
          className={`mt-1 text-[9.5px] font-bold uppercase tracking-[0.34em] sm:text-[10.5px] ${
            light ? "text-white" : "text-ink"
          }`}
        >
          Real Estates
        </span>
        {showTagline && (
          <span className={`mt-1.5 text-[10px] font-medium ${light ? "text-white/70" : "text-neutral-600"}`}>
            Your Property. Our Priority.
          </span>
        )}
      </span>
    </span>
  );

  if (!asLink) return content;
  return (
    <Link to="/" aria-label="Zeddy Real Estates – home" className="inline-flex">
      {content}
    </Link>
  );
}
