import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Expand, X } from "lucide-react";
import type { PropertyImage } from "../data/types";
import { sized } from "../lib/format";

export default function Gallery({ images }: { images: PropertyImage[] }) {
  const [index, setIndex] = useState(0);
  const [open, setOpen] = useState(false);
  const total = images.length;

  const prev = useCallback(() => setIndex((i) => (i - 1 + total) % total), [total]);
  const next = useCallback(() => setIndex((i) => (i + 1) % total), [total]);

  useEffect(() => {
    setIndex(0);
  }, [images]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, prev, next]);

  const current = images[index];

  return (
    <div>
      <div className="relative overflow-hidden rounded-xl bg-neutral-100">
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="block aspect-[16/10] w-full cursor-zoom-in"
          aria-label="Open image gallery full screen"
        >
          <img
            src={sized(current.src, 1400, 875)}
            alt={current.alt}
            width={1400}
            height={875}
            fetchPriority="high"
            className="h-full w-full object-cover"
          />
        </button>

        {total > 1 && (
          <>
            <button
              type="button"
              onClick={prev}
              aria-label="Previous photo"
              className="absolute left-3 top-1/2 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white text-ink shadow-md hover:bg-accent-500"
            >
              <ChevronLeft size={22} />
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Next photo"
              className="absolute right-3 top-1/2 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white text-ink shadow-md hover:bg-accent-500"
            >
              <ChevronRight size={22} />
            </button>
          </>
        )}

        <span className="absolute bottom-3 left-3 rounded-md bg-ink px-3 py-1.5 text-xs font-bold text-white">
          {index + 1} / {total}
        </span>
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label="View full screen"
          className="absolute bottom-3 right-3 inline-flex h-10 w-10 items-center justify-center rounded-md bg-white text-ink shadow-md hover:bg-accent-500"
        >
          <Expand size={18} />
        </button>
      </div>

      {total > 1 && (
        <ul className="no-scrollbar mt-3 flex gap-3 overflow-x-auto pb-1">
          {images.map((img, i) => (
            <li key={img.src} className="shrink-0">
              <button
                type="button"
                onClick={() => setIndex(i)}
                aria-label={`Show photo ${i + 1}`}
                aria-current={i === index}
                className={`block h-16 w-24 overflow-hidden rounded-md border-2 sm:h-20 sm:w-32 ${
                  i === index ? "border-brand-600" : "border-transparent opacity-70 hover:opacity-100"
                }`}
              >
                <img
                  src={sized(img.src, 256, 160)}
                  alt=""
                  width={256}
                  height={160}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </button>
            </li>
          ))}
        </ul>
      )}

      {open && (
        <div
          className="fixed inset-0 z-[80] flex flex-col bg-black"
          role="dialog"
          aria-modal="true"
          aria-label="Photo gallery"
          onClick={() => setOpen(false)}
        >
          <div className="flex items-center justify-between px-4 py-3 text-white">
            <span className="text-sm font-semibold">
              {index + 1} / {total}
            </span>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close gallery"
              className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"
            >
              <X size={22} />
            </button>
          </div>
          <div className="relative flex flex-1 items-center justify-center px-4 pb-6" onClick={(e) => e.stopPropagation()}>
            <img
              src={sized(current.src, 1800, 1200)}
              alt={current.alt}
              className="max-h-full max-w-full rounded-md object-contain"
            />
            {total > 1 && (
              <>
                <button
                  type="button"
                  onClick={prev}
                  aria-label="Previous photo"
                  className="absolute left-3 top-1/2 inline-flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white text-ink hover:bg-accent-500"
                >
                  <ChevronLeft size={24} />
                </button>
                <button
                  type="button"
                  onClick={next}
                  aria-label="Next photo"
                  className="absolute right-3 top-1/2 inline-flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white text-ink hover:bg-accent-500"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
