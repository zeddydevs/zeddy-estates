import { useState, type FormEvent } from "react";
import { CheckCircle2, Mail, Send } from "lucide-react";
import type { Property } from "../data/types";
import { SITE } from "../config/site";
import { absoluteUrl, mailLink, waLink } from "../lib/format";

interface Props {
  property?: Property;
  heading?: string;
  /** Show the preferred visit-date field */
  showDate?: boolean;
  idPrefix?: string;
}

const field =
  "w-full rounded-md border border-neutral-300 bg-white px-4 py-3 text-[15px] text-ink placeholder:text-neutral-400 focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-600/20";

export default function EnquiryForm({ property, heading, showDate = true, idPrefix = "enq" }: Props) {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", date: "", message: "" });
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const buildMessage = () => {
    const lines = [
      `Hello ${SITE.name}, my name is ${form.name}.`,
      property
        ? `I am interested in "${property.title}" (Ref: ${property.id}) – ${absoluteUrl(`/properties/${property.slug}`)}`
        : "I would like to make an enquiry.",
      form.date ? `Preferred site visit date: ${form.date}` : "",
      form.message ? `Message: ${form.message}` : "",
      `Phone: ${form.phone}`,
      form.email ? `Email: ${form.email}` : "",
    ];
    return lines.filter(Boolean).join("\n");
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    window.open(waLink(buildMessage()), "_blank", "noopener,noreferrer");
    setSent(true);
  };

  const today = new Date().toISOString().slice(0, 10);

  if (sent) {
    return (
      <div className="rounded-xl border border-brand-200 bg-brand-50 p-6 text-center" role="status">
        <CheckCircle2 className="mx-auto text-brand-600" size={40} aria-hidden="true" />
        <h3 className="mt-3 text-xl font-extrabold text-brand-900">Thank you, {form.name.split(" ")[0]}!</h3>
        <p className="mt-2 text-[15px] text-neutral-700">
          WhatsApp has opened with your message ready to send. If it didn't open, you can also call us on{" "}
          <a className="font-bold text-brand-700" href={`tel:${SITE.phone}`}>
            {SITE.phoneDisplay}
          </a>
          .
        </p>
        <button
          type="button"
          onClick={() => setSent(false)}
          className="mt-4 text-sm font-bold text-brand-700 underline underline-offset-4"
        >
          Send another enquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4" aria-label={heading ?? "Enquiry form"}>
      {heading && <h3 className="text-xl font-extrabold text-ink">{heading}</h3>}

      <div>
        <label htmlFor={`${idPrefix}-name`} className="mb-1.5 block text-sm font-semibold text-ink">
          Full name <span className="text-red-600">*</span>
        </label>
        <input
          id={`${idPrefix}-name`}
          required
          autoComplete="name"
          value={form.name}
          onChange={set("name")}
          placeholder="e.g. Jane Achieng"
          className={field}
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor={`${idPrefix}-phone`} className="mb-1.5 block text-sm font-semibold text-ink">
            Phone <span className="text-red-600">*</span>
          </label>
          <input
            id={`${idPrefix}-phone`}
            required
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            pattern="[0-9+\s\-]{9,16}"
            title="Enter a valid phone number"
            value={form.phone}
            onChange={set("phone")}
            placeholder="07XX XXX XXX"
            className={field}
          />
        </div>
        <div>
          <label htmlFor={`${idPrefix}-email`} className="mb-1.5 block text-sm font-semibold text-ink">
            Email
          </label>
          <input
            id={`${idPrefix}-email`}
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={set("email")}
            placeholder="you@email.com"
            className={field}
          />
        </div>
      </div>

      {showDate && (
        <div>
          <label htmlFor={`${idPrefix}-date`} className="mb-1.5 block text-sm font-semibold text-ink">
            Preferred site visit date
          </label>
          <input
            id={`${idPrefix}-date`}
            type="date"
            min={today}
            value={form.date}
            onChange={set("date")}
            className={field}
          />
        </div>
      )}

      <div>
        <label htmlFor={`${idPrefix}-message`} className="mb-1.5 block text-sm font-semibold text-ink">
          Message
        </label>
        <textarea
          id={`${idPrefix}-message`}
          rows={4}
          value={form.message}
          onChange={set("message")}
          placeholder={property ? "I would like to know more about this property…" : "How can we help you?"}
          className={`${field} resize-y`}
        />
      </div>

      <button
        type="submit"
        className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-brand-600 px-6 py-4 text-base font-bold text-white transition-colors hover:bg-brand-700"
      >
        <Send size={18} aria-hidden="true" /> Send via WhatsApp
      </button>

      <a
        href={mailLink(
          property ? `Enquiry: ${property.title} (${property.id})` : "Website enquiry",
          buildMessage(),
        )}
        className="inline-flex w-full items-center justify-center gap-2 text-sm font-semibold text-neutral-600 hover:text-brand-700"
      >
        <Mail size={16} aria-hidden="true" /> Prefer email? Send us an email instead
      </a>
    </form>
  );
}
