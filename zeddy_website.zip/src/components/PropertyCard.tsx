import { Link } from "react-router-dom";
import { ArrowUpRight, BedDouble, Bath, Car, MapPin, Ruler } from "lucide-react";
import type { Property } from "../data/types";
import { formatPrice, sized } from "../lib/format";
import { FavoriteButton } from "./ui";

export default function PropertyCard({ property: p, priority = false }: { property: Property; priority?: boolean }) {
  const facts: { icon: typeof Ruler; label: string }[] = [];
  if (p.bedrooms) facts.push({ icon: BedDouble, label: `${p.bedrooms} Beds` });
  if (p.bathrooms) facts.push({ icon: Bath, label: `${p.bathrooms} Baths` });
  facts.push({ icon: Ruler, label: p.floorArea && /sq ft/.test(p.floorArea) ? p.floorArea : p.landSize });
  if (p.parking && facts.length < 4) facts.push({ icon: Car, label: `${p.parking} Parking` });

  // Safely resolve image source supporting .url (uploads), .src, or direct strings
  const firstImage = p.images?.[0];
  const rawImageSrc = 
    typeof firstImage === 'string' 
      ? firstImage 
      : firstImage?.url || firstImage?.src || "/images/banner.jfif";

  const imageAlt = typeof firstImage === 'object' && firstImage?.alt ? firstImage.alt : p.title || "Property";

  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-xl border border-neutral-200 bg-white transition-shadow duration-300 hover:shadow-xl">
      <div className="relative aspect-[4/3] overflow-hidden bg-neutral-100">
        <img
          src={rawImageSrc.startsWith("http") || rawImageSrc.startsWith("/") ? rawImageSrc : sized(rawImageSrc, 800, 600)}
          alt={imageAlt}
          width={800}
          height={600}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute left-3 top-3 flex flex-wrap gap-2">
          <span
            className={`rounded-md px-3 py-1.5 text-xs font-bold uppercase tracking-wide ${
              p.status === "For Sale" ? "bg-brand-600 text-white" : "bg-accent-500 text-ink"
            }`}
          >
            {p.status}
          </span>
        </div>
        {p.badge && (
          <span className="absolute bottom-3 left-3 rounded-md bg-ink px-3 py-1.5 text-xs font-bold text-white">
            {p.badge}
          </span>
        )}
        <FavoriteButton id={p.id} title={p.title} className="absolute right-3 top-3 z-20" />
      </div>

      <div className="flex flex-1 flex-col p-5">
        <p className="text-xs font-bold uppercase tracking-[0.14em] text-brand-600">{p.type}</p>
        <h3 className="mt-2 text-lg font-extrabold leading-snug text-ink">
          <Link
            to={`/properties/${p.slug}`}
            className="after:absolute after:inset-0 after:content-[''] hover:text-brand-600"
          >
            {p.title}
          </Link>
        </h3>
        <p className="mt-2 flex items-center gap-1.5 text-sm text-neutral-600">
          <MapPin size={16} className="shrink-0 text-brand-600" aria-hidden="true" />
          {p.area || p.location}
        </p>

        <ul className="mt-4 flex flex-wrap gap-x-5 gap-y-2 border-t border-neutral-100 pt-4 text-sm text-neutral-700">
          {facts.map(({ icon: Ico, label }) => (
            label ? (
              <li key={label} className="inline-flex items-center gap-1.5">
                <Ico size={16} className="text-brand-600" aria-hidden="true" />
                {label}
              </li>
            ) : null
          ))}
        </ul>

        <div className="mt-auto flex items-end justify-between gap-3 pt-5">
          <div>
            <p className="text-xs font-medium text-neutral-500">{p.price === null ? "Asking price" : p.status === "For Rent" ? "Rent" : "Price"}</p>
            <p className="font-display text-xl font-extrabold text-brand-700">{formatPrice(p)}</p>
          </div>
          <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-50 text-brand-600 transition-colors group-hover:bg-brand-600 group-hover:text-white">
            <ArrowUpRight size={20} aria-hidden="true" />
          </span>
        </div>
      </div>
    </article>
  );
}