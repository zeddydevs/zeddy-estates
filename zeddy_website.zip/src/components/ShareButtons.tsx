import { useState } from "react";
import { Check, Link2, Share2 } from "lucide-react";
import WhatsAppIcon from "./WhatsAppIcon";

export default function ShareButtons({ url, title, className = "" }: { url: string; title: string; className?: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt("Copy this link:", url);
    }
  };

  const nativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title, url });
      } catch {
        /* user cancelled */
      }
    } else {
      copy();
    }
  };

  const btn =
    "inline-flex h-10 items-center justify-center gap-2 rounded-full border border-neutral-200 bg-white px-4 text-sm font-semibold text-ink transition-colors hover:border-brand-600 hover:text-brand-600";

  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      <span className="mr-1 text-sm font-semibold text-neutral-600">Share:</span>
      <a
        href={`https://wa.me/?text=${encodeURIComponent(`${title} – ${url}`)}`}
        target="_blank"
        rel="noopener noreferrer"
        className={btn}
        aria-label="Share on WhatsApp"
      >
        <WhatsAppIcon size={16} /> WhatsApp
      </a>
      <button type="button" onClick={copy} className={btn} aria-label="Copy link">
        {copied ? <Check size={16} /> : <Link2 size={16} />} {copied ? "Copied!" : "Copy link"}
      </button>
      <button type="button" onClick={nativeShare} className={btn} aria-label="Share">
        <Share2 size={16} /> More
      </button>
    </div>
  );
}
