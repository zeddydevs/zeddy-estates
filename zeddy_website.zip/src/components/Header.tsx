import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { CalendarCheck, Clock, Heart, Mail, MapPin, Menu, Phone, X } from "lucide-react";
import Logo from "./Logo";
import WhatsAppIcon from "./WhatsAppIcon";
import { NAV_LINKS, SITE } from "../config/site";
import { telLink, waLink } from "../lib/format";
import { useFavorites } from "../lib/useFavorites";

export default function Header() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const { count } = useFavorites();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      {/* Top info bar */}
      <div className="hidden bg-brand-900 text-[13px] text-white/90 md:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2 sm:px-6 lg:px-8">
          <div className="flex items-center gap-6">
            <a href={telLink} className="inline-flex items-center gap-2 hover:text-accent-400">
              <Phone size={14} aria-hidden="true" /> {SITE.phoneDisplay}
            </a>
            <a href={`mailto:${SITE.email}`} className="inline-flex items-center gap-2 hover:text-accent-400">
              <Mail size={14} aria-hidden="true" /> {SITE.email}
            </a>
          </div>
          <div className="flex items-center gap-6">
            <span className="inline-flex items-center gap-2">
              <MapPin size={14} aria-hidden="true" /> {SITE.address.street}
            </span>
            <span className="inline-flex items-center gap-2">
              <Clock size={14} aria-hidden="true" /> Mon – Sat: 8:00 AM – 6:00 PM
            </span>
          </div>
        </div>
      </div>

      <header className="sticky top-0 z-40 border-b border-neutral-200 bg-white">
        <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between px-4 sm:h-[76px] sm:px-6 lg:px-8">
          <Logo />

          <nav aria-label="Main navigation" className="hidden items-center gap-1 lg:flex">
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === "/"}
                className={({ isActive }) =>
                  `relative px-4 py-2 text-[15px] font-semibold transition-colors ${
                    isActive ? "text-brand-600" : "text-ink hover:text-brand-600"
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {link.label}
                    <span
                      className={`absolute inset-x-4 -bottom-[13px] h-[3px] bg-brand-600 transition-opacity ${
                        isActive ? "opacity-100" : "opacity-0"
                      }`}
                    />
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            

            <a
              href={waLink(`Hello ${SITE.name}, I would like to book a site visit.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden items-center gap-2 rounded-md bg-brand-600 px-5 py-3 text-sm font-bold text-white transition-colors hover:bg-brand-700 sm:inline-flex"
            >
              <CalendarCheck size={18} aria-hidden="true" /> Book a Site Visit
            </a>

            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-neutral-200 text-ink lg:hidden"
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {open && (
          <div
            id="mobile-menu"
            className="absolute inset-x-0 top-full max-h-[calc(100vh-76px)] overflow-y-auto border-t border-neutral-200 bg-white shadow-xl lg:hidden"
          >
            <nav aria-label="Mobile navigation" className="mx-auto flex max-w-7xl flex-col px-4 py-4 sm:px-6">
              {NAV_LINKS.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === "/"}
                  className={({ isActive }) =>
                    `border-b border-neutral-100 py-4 text-lg font-semibold ${
                      isActive ? "text-brand-600" : "text-ink"
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              
              <div className="mt-5 grid grid-cols-2 gap-3">
                <a
                  href={telLink}
                  className="inline-flex items-center justify-center gap-2 rounded-md bg-brand-600 px-4 py-3.5 font-bold text-white"
                >
                  <Phone size={18} aria-hidden="true" /> Call
                </a>
                <a
                  href={waLink(`Hello ${SITE.name}, I would like to enquire about a property.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-md bg-whatsapp-dark px-4 py-3.5 font-bold text-white"
                >
                  <WhatsAppIcon size={18} /> WhatsApp
                </a>
              </div>
            </nav>
          </div>
        )}
      </header>
    </>
  );
}
