import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { LogOut } from 'lucide-react';

export async function logoutAdmin() {
  'use server';
  const cookieStore = await cookies();
  cookieStore.delete('zeddy_admin_session');
  redirect('/admin/login');
}

export default function LogoutButton() {
  return (
    <form action={logoutAdmin}>
      <button
        type="submit"
        className="inline-flex items-center gap-2 rounded-md border border-neutral-300 bg-white px-4 py-2 text-sm font-bold text-neutral-700 hover:bg-neutral-50 transition-colors"
      >
        <LogOut size={16} /> Logout
      </button>
    </form>
  );
}