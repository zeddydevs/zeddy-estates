import { useState } from "react";
import { Upload, Loader2, CheckCircle2 } from "lucide-react";

interface ImageUploadProps {
  value: string;
  onChange: (url: string) => void;
  label?: string;
}

export default function ImageUpload({ value, onChange, label = "Upload Image" }: ImageUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setSuccess(false);
    const token = localStorage.getItem("zeddy_admin_token");

    const uploadData = new FormData();
    uploadData.append("image", file);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token || "zeddy-admin-secret"}`,
        },
        body: uploadData,
      });

      if (!res.ok) throw new Error("Upload failed");

      const data = await res.json();
      onChange(data.url);
      setUploading(false);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert("Failed to upload image");
      setUploading(false);
    }
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-3">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="/uploads/image.jpg or paste URL"
          className="flex-1 rounded-md border border-neutral-300 p-3 text-sm focus:border-brand-600 focus:outline-none"
        />
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-md bg-neutral-900 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-black">
          {uploading ? (
            <Loader2 size={16} className="animate-spin" />
          ) : success ? (
            <CheckCircle2 size={16} className="text-emerald-400" />
          ) : (
            <Upload size={16} />
          )}
          <span>{uploading ? "Uploading..." : label}</span>
          <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
        </label>
      </div>
      {value && (
        <div className="relative mt-2 h-24 w-32 overflow-hidden rounded-md border border-neutral-200 bg-neutral-50">
          <img src={value} alt="Preview" className="h-full w-full object-cover" />
        </div>
      )}
    </div>
  );
}