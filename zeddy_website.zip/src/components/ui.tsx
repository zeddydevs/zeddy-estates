import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ChevronRight, Heart, Phone } from "lucide-react";
import { LogoMark } from "./Logo";
import WhatsAppIcon from "./WhatsAppIcon";
import { SITE } from "../config/site";
import { telLink, waLink } from "../lib/format";
import { useFavorites } from "../lib/useFavorites";

export function Container({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 ${className}`}>{children}</div>;
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  light = false,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
  light?: boolean;
}) {
  return (
    <div className={`${align === "center" ? "mx-auto text-center" : ""} max-w-2xl`}>
      {eyebrow && (
        <p
          className={`mb-3 inline-flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.18em] ${
            light ? "text-accent-400" : "text-brand-600"
          }`}
        >
          <span className={`h-[3px] w-8 ${light ? "bg-accent-400" : "bg-accent-500"}`} aria-hidden="true" />
          {eyebrow}
        </p>
      )}
      <h2 className={`text-3xl font-extrabold leading-tight sm:text-4xl ${light ? "text-white" : "text-ink"}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-4 text-base leading-relaxed sm:text-lg ${light ? "text-white/75" : "text-neutral-600"}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}

export function Breadcrumbs({
  items,
  light = false,
}: {
  items: { label: string; to?: string }[];
  light?: boolean;
}) {
  return (
    <nav aria-label="Breadcrumb">
      <ol className={`flex flex-wrap items-center gap-1.5 text-sm ${light ? "text-white/70" : "text-neutral-500"}`}>
        {items.map((item, i) => {
          const last = i === items.length - 1;
          return (
            <li key={item.label} className="flex items-center gap-1.5">
              {item.to && !last ? (
                <Link to={item.to} className={light ? "hover:text-white" : "hover:text-brand-600"}>
                  {item.label}
                </Link>
              ) : (
                <span aria-current={last ? "page" : undefined} className={light ? "font-semibold text-white" : "font-semibold text-ink"}>
                  {item.label}
                </span>
              )}
              {!last && <ChevronRight size={14} aria-hidden="true" />}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

export function PageHero({
  title,
  subtitle,
  breadcrumbs,
  children,
}: {
  title: string;
  subtitle?: string;
  breadcrumbs: { label: string; to?: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden bg-brand-900">
      <LogoMark
        className="pointer-events-none absolute -right-10 top-1/2 hidden h-64 w-auto -translate-y-1/2 opacity-60 md:block lg:right-10 lg:h-72"
        green="#0c5728"
        dark="#0a4521"
      />
      <Container className="relative py-12 sm:py-16">
        <Breadcrumbs items={breadcrumbs} light />
        <h1 className="mt-5 max-w-3xl text-3xl font-extrabold leading-tight text-white sm:text-5xl">{title}</h1>
        {subtitle && <p className="mt-4 max-w-2xl text-base leading-relaxed text-white/75 sm:text-lg">{subtitle}</p>}
        {children}
      </Container>
    </section>
  );
}

export function FavoriteButton({ id, title, className = "" }: { id: string; title: string; className?: string }) {
  const { isSaved, toggle } = useFavorites();
  const saved = isSaved(id);
  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggle(id);
      }}
      aria-pressed={saved}
      aria-label={saved ? `Remove ${title} from saved properties` : `Save ${title}`}
      title={saved ? "Remove from saved" : "Save property"}
      className={`inline-flex h-10 w-10 items-center justify-center rounded-full border transition-colors ${
        saved
          ? "border-brand-600 bg-brand-600 text-white"
          : "border-neutral-200 bg-white text-ink hover:border-brand-600 hover:text-brand-600"
      } ${className}`}
    >
      <Heart size={18} fill={saved ? "currentColor" : "none"} aria-hidden="true" />
    </button>
  );
}

export function CtaBand({
  title = "Ready to find your next property?",
  text = "Book a site visit today – our team will show you around and answer every question.",
}: {
  title?: string;
  text?: string;
}) {
  return (
    <section className="bg-brand-600">
      <Container className="flex flex-col items-start justify-between gap-8 py-14 lg:flex-row lg:items-center">
        <div className="max-w-2xl">
          <p className="text-[13px] font-bold uppercase tracking-[0.18em] text-accent-400">Book a site visit today</p>
          <h2 className="mt-3 text-3xl font-extrabold leading-tight text-white sm:text-4xl">{title}</h2>
          <p className="mt-3 text-lg text-white/85">{text}</p>
        </div>
        <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
          <a
            href={telLink}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-white px-7 py-4 text-base font-bold text-brand-800 transition-colors hover:bg-accent-500 hover:text-ink"
          >
            <Phone size={20} aria-hidden="true" /> {SITE.phoneDisplay}
          </a>
          <a
            href={waLink(`Hello ${SITE.name}, I would like to book a site visit.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 rounded-md bg-ink px-7 py-4 text-base font-bold text-white transition-colors hover:bg-black"
          >
            <WhatsAppIcon size={20} /> WhatsApp Us
          </a>
        </div>
      </Container>
    </section>
  );
}
