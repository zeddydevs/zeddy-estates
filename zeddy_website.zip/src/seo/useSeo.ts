import { useEffect } from "react";
import { SITE } from "../config/site";
import { absoluteUrl } from "../lib/format";
import type { PageMeta } from "./meta";

type MetaAttr = "name" | "property";

function setMeta(attr: MetaAttr, key: string, content?: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!content) {
    el?.remove();
    return;
  }
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setLink(rel: string, href: string, extra: Record<string, string> = {}) {
  const selector = `link[rel="${rel}"]${extra.hreflang ? `[hreflang="${extra.hreflang}"]` : ""}`;
  let el = document.head.querySelector<HTMLLinkElement>(selector);
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", rel);
    Object.entries(extra).forEach(([k, v]) => el!.setAttribute(k, v));
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

function setJsonLd(data?: Record<string, unknown>[]) {
  let el = document.getElementById("page-jsonld");
  if (!el) {
    el = document.createElement("script");
    el.id = "page-jsonld";
    el.setAttribute("type", "application/ld+json");
    document.head.appendChild(el);
  }
  el.textContent = JSON.stringify(data && data.length ? data : {});
}

/** Applies title, description, canonical, Open Graph, Twitter and JSON-LD for the current page. */
export function applySeo(meta: PageMeta) {
  const url = absoluteUrl(meta.path);
  const image = meta.image ?? SITE.defaultOgImage;

  document.title = meta.title;
  setMeta("name", "description", meta.description);
  setMeta("name", "keywords", meta.keywords?.join(", "));
  setMeta(
    "name",
    "robots",
    meta.noindex
      ? "noindex, nofollow"
      : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
  );
  setLink("canonical", url);
  setLink("alternate", url, { hreflang: "en-ke" });

  setMeta("property", "og:type", meta.type === "article" ? "article" : "website");
  setMeta("property", "og:url", url);
  setMeta("property", "og:title", meta.title);
  setMeta("property", "og:description", meta.description);
  setMeta("property", "og:image", image);
  setMeta("property", "og:image:alt", meta.imageAlt ?? meta.title);
  setMeta("property", "article:published_time", meta.publishedTime);

  setMeta("name", "twitter:title", meta.title);
  setMeta("name", "twitter:description", meta.description);
  setMeta("name", "twitter:image", image);

  setJsonLd(meta.jsonLd);
}

export function useSeo(meta: PageMeta) {
  const key = JSON.stringify(meta);
  useEffect(() => {
    applySeo(meta);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
}
