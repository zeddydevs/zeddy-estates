import { SITE } from "../config/site";
import type { BlogPost, Property } from "../data/types";
import type { Faq } from "../data/faq";
import { absoluteUrl } from "../lib/format";

type Json = Record<string, unknown>;

export const ORG_ID = `${SITE.url}/#organization`;
export const WEBSITE_ID = `${SITE.url}/#website`;

export const breadcrumbSchema = (items: { name: string; path: string }[]): Json => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: items.map((item, i) => ({
    "@type": "ListItem",
    position: i + 1,
    name: item.name,
    item: absoluteUrl(item.path),
  })),
});

export const faqSchema = (faqs: Faq[]): Json => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a },
  })),
});

export const itemListSchema = (name: string, items: { name: string; path: string }[]): Json => ({
  "@context": "https://schema.org",
  "@type": "ItemList",
  name,
  numberOfItems: items.length,
  itemListElement: items.map((item, i) => ({
    "@type": "ListItem",
    position: i + 1,
    url: absoluteUrl(item.path),
    name: item.name,
  })),
});

export const propertySchema = (p: Property): Json => {
  const url = absoluteUrl(`/properties/${p.slug}`);
  const isHouse = p.type === "House";
  const place: Json = {
    "@type": isHouse ? "SingleFamilyResidence" : p.type === "Apartment" ? "Apartment" : "Place",
    name: p.title,
    address: {
      "@type": "PostalAddress",
      streetAddress: p.address,
      addressLocality: "Kisumu",
      addressRegion: SITE.address.region,
      addressCountry: SITE.address.country,
    },
    geo: { "@type": "GeoCoordinates", latitude: SITE.geo.lat, longitude: SITE.geo.lng },
    ...(p.bedrooms ? { numberOfBedrooms: p.bedrooms } : {}),
    ...(p.bathrooms ? { numberOfBathroomsTotal: p.bathrooms } : {}),
    ...(p.floorArea && /\d/.test(p.floorArea) && /sq ft/.test(p.floorArea)
      ? {
          floorSize: {
            "@type": "QuantitativeValue",
            value: Number(p.floorArea.replace(/[^\d]/g, "")),
            unitCode: "FTK",
          },
        }
      : {}),
    amenityFeature: p.amenities.map((a) => ({ "@type": "LocationFeatureSpecification", name: a, value: true })),
  };

  const offers: Json | undefined =
    p.price === null
      ? undefined
      : {
          "@type": "Offer",
          url,
          price: p.price,
          priceCurrency: "KES",
          availability: "https://schema.org/InStock",
          businessFunction:
            p.status === "For Sale"
              ? "http://purl.org/goodrelations/v1#Sell"
              : "http://purl.org/goodrelations/v1#LeaseOut",
          ...(p.pricePeriod === "month"
            ? {
                priceSpecification: {
                  "@type": "UnitPriceSpecification",
                  price: p.price,
                  priceCurrency: "KES",
                  unitCode: "MON",
                },
              }
            : {}),
          seller: { "@id": ORG_ID },
        };

  return {
    "@context": "https://schema.org",
    "@type": "RealEstateListing",
    "@id": `${url}#listing`,
    url,
    name: p.title,
    description: p.summary,
    datePosted: p.datePosted,
    inLanguage: "en-KE",
    image: p.images.map((i) => i.src),
    about: place,
    ...(offers ? { offers } : {}),
    provider: { "@id": ORG_ID },
    isPartOf: { "@id": WEBSITE_ID },
  };
};

export const blogPostSchema = (post: BlogPost): Json => {
  const url = absoluteUrl(`/blog/${post.slug}`);
  return {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "@id": `${url}#article`,
    mainEntityOfPage: { "@type": "WebPage", "@id": url },
    headline: post.title,
    description: post.excerpt,
    image: [post.image],
    datePublished: post.date,
    dateModified: post.date,
    articleSection: post.category,
    keywords: post.tags.join(", "),
    inLanguage: "en-KE",
    author: { "@type": "Organization", name: post.author, url: SITE.url },
    publisher: { "@id": ORG_ID },
  };
};

export const webPageSchema = (name: string, path: string, description: string, type = "WebPage"): Json => ({
  "@context": "https://schema.org",
  "@type": type,
  name,
  url: absoluteUrl(path),
  description,
  inLanguage: "en-KE",
  isPartOf: { "@id": WEBSITE_ID },
  about: { "@id": ORG_ID },
});
