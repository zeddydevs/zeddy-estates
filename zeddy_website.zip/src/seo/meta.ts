import { SITE } from "../config/site";
import { properties } from "../data/properties";
import { blogPosts } from "../data/blog";
import { faqs } from "../data/faq";
import type { BlogPost, Property } from "../data/types";
import { truncate } from "../lib/format";
import {
  blogPostSchema,
  breadcrumbSchema,
  faqSchema,
  itemListSchema,
  propertySchema,
  webPageSchema,
} from "./schema";

export interface PageMeta {
  path: string;
  title: string;
  description: string;
  h1: string;
  image?: string;
  imageAlt?: string;
  type?: "website" | "article";
  keywords?: string[];
  noindex?: boolean;
  jsonLd?: Record<string, unknown>[];
  /** Internal links rendered in the <noscript> fallback for crawlers */
  links?: { label: string; path: string }[];
  /** Sitemap hints */
  changefreq?: "daily" | "weekly" | "monthly" | "yearly";
  priority?: number;
  lastmod?: string;
  sitemapImages?: { src: string; alt: string }[];
  publishedTime?: string;
}

const BASE_KEYWORDS = ["Zeddy Real Estates", "real estate Kisumu", "property Kisumu", "Kenya real estate"];
const today = () => new Date().toISOString().slice(0, 10);

export const homeMeta = (): PageMeta => ({
  path: "/",
  title: "Zeddy Real Estates | Property for Sale & Rent in Kisumu, Kenya",
  description:
    "Zeddy Real Estates – Your Property. Our Priority. Browse verified land, houses, apartments and commercial property for sale and rent in Kisumu, Kenya. Book a site visit on 0703 287 361.",
  h1: "Find Your Perfect Property in Kisumu, Kenya",
  image: SITE.defaultOgImage,
  imageAlt: "Modern residential property listed by Zeddy Real Estates in Kisumu",
  keywords: [...BASE_KEYWORDS, "land for sale Kisumu", "houses for sale Kisumu", "apartments for rent Kisumu", "plots for sale Kisumu"],
  jsonLd: [
    webPageSchema("Zeddy Real Estates – Property in Kisumu", "/", "Land, houses, apartments and commercial property for sale and rent in Kisumu, Kenya."),
    itemListSchema(
      "Featured properties in Kisumu",
      properties.map((p) => ({ name: p.title, path: `/properties/${p.slug}` })),
    ),
  ],
  links: properties.map((p) => ({ label: p.title, path: `/properties/${p.slug}` })),
  changefreq: "weekly",
  priority: 1,
  lastmod: today(),
});

export const propertiesMeta = (): PageMeta => ({
  path: "/properties",
  title: "Properties for Sale & Rent in Kisumu | Zeddy Real Estates",
  description:
    "Search land, houses, apartments and commercial property for sale and to let in Kisumu – Milimani, Riat Hills, Nyamasaria, Dunga, Gambogi and the CBD. Filter by type, status and bedrooms.",
  h1: "Properties for Sale & Rent in Kisumu",
  image: properties[0]?.images?.[0]?.src || SITE.defaultOgImage,
  imageAlt: properties[0]?.images?.[0]?.alt || "Property",
  keywords: [...BASE_KEYWORDS, "property listings Kisumu", "plots for sale Kisumu", "houses to let Kisumu"],
  jsonLd: [
    webPageSchema("Properties in Kisumu", "/properties", "Browse all Zeddy Real Estates listings in Kisumu.", "CollectionPage"),
    itemListSchema(
      "Properties in Kisumu",
      properties.map((p) => ({ name: p.title, path: `/properties/${p.slug}` })),
    ),
    breadcrumbSchema([
      { name: "Home", path: "/" },
      { name: "Properties", path: "/properties" },
    ]),
  ],
  links: properties.map((p) => ({ label: p.title, path: `/properties/${p.slug}` })),
  changefreq: "daily",
  priority: 0.9,
  lastmod: today(),
});

export const propertyMeta = (p: Partial<Property> & { slug?: string } = {}): PageMeta => {
  const title = p?.title ? `${p.title} | Zeddy Real Estates` : "Property Details | Zeddy Real Estates";
  const descRaw = p?.summary || (Array.isArray(p?.description) ? p.description[0] : p?.description) || "Explore verified real estate properties in Kisumu.";
  const description = truncate(descRaw);
  const fallbackImg = p?.images?.[0]?.src || p?.images?.[0]?.url || SITE.defaultOgImage;
  const fallbackAlt = p?.images?.[0]?.alt || p?.title || "Property image";

  return {
    path: `/properties/${p?.slug || ""}`,
    title,
    description,
    h1: p?.title || "Property Details",
    image: fallbackImg,
    imageAlt: fallbackAlt,
    keywords: [
      ...BASE_KEYWORDS,
      p?.type ? `${p.type.toLowerCase()} ${p?.status ? p.status.toLowerCase() : ""} ${p?.location || ""}` : "",
      p?.location ? `${p.location} Kisumu` : "",
      ...(p?.tags || []),
    ].filter(Boolean),
    jsonLd: [
      ...(p?.id ? [propertySchema(p as Property)] : []),
      breadcrumbSchema([
        { name: "Home", path: "/" },
        { name: "Properties", path: "/properties" },
        ...(p?.title ? [{ name: p.title, path: `/properties/${p.slug}` }] : []),
      ]),
    ],
    links: [
      { label: "All properties", path: "/properties" },
      { label: "Contact us", path: "/contact" },
    ],
    changefreq: "weekly",
    priority: 0.8,
    lastmod: p?.datePosted || today(),
    sitemapImages: Array.isArray(p?.images) ? p.images : [{ src: fallbackImg, alt: fallbackAlt }],
  };
};

export const blogIndexMeta = (): PageMeta => ({
  path: "/blog",
  title: "Real Estate Blog & Property Tips | Zeddy Real Estates",
  description:
    "Guides, market insights and practical tips on buying land, investing, building and selling property in Kisumu and across Kenya from the Zeddy Real Estates team.",
  h1: "Real Estate Blog & Property Tips",
  image: blogPosts[0]?.image || SITE.defaultOgImage,
  imageAlt: blogPosts[0]?.imageAlt || "Blog",
  keywords: [...BASE_KEYWORDS, "real estate blog Kenya", "how to buy land in Kisumu", "property investment tips"],
  jsonLd: [
    webPageSchema("Zeddy Real Estates Blog", "/blog", "Property guides and insights for Kisumu.", "CollectionPage"),
    breadcrumbSchema([
      { name: "Home", path: "/" },
      { name: "Blog", path: "/blog" },
    ]),
  ],
  links: blogPosts.map((b) => ({ label: b.title, path: `/blog/${b.slug}` })),
  changefreq: "weekly",
  priority: 0.7,
  lastmod: blogPosts[0]?.date || today(),
});

export const blogPostMeta = (post: Partial<BlogPost> & { slug?: string } = {}): PageMeta => {
  const title = post?.title ? `${post.title} | Zeddy Real Estates` : "Article | Zeddy Real Estates";
  const description = truncate(post?.excerpt || "");
  const image = post?.image || SITE.defaultOgImage;
  const imageAlt = post?.imageAlt || post?.title || "Article image";

  return {
    path: `/blog/${post?.slug || ""}`,
    title,
    description,
    h1: post?.title || "Article",
    image,
    imageAlt,
    type: "article",
    keywords: [...BASE_KEYWORDS, ...(post?.tags || [])],
    jsonLd: [
      ...(post?.id ? [blogPostSchema(post as BlogPost)] : []),
      breadcrumbSchema([
        { name: "Home", path: "/" },
        { name: "Blog", path: "/blog" },
        ...(post?.title ? [{ name: post.title, path: `/blog/${post.slug}` }] : []),
      ]),
    ],
    links: [
      { label: "All articles", path: "/blog" },
      { label: "Browse properties", path: "/properties" },
    ],
    changefreq: "monthly",
    priority: 0.6,
    lastmod: post?.date || today(),
    publishedTime: post?.date || today(),
    sitemapImages: [{ src: image, alt: imageAlt }],
  };
};

export const aboutMeta = (): PageMeta => ({
  path: "/about",
  title: "About Zeddy Real Estates | Trusted Property Agents in Kisumu",
  description:
    "Learn about Zeddy Real Estates – Your Property. Our Priority. We help buyers, sellers, tenants and investors find secure, high-potential property in Kisumu, Kenya.",
  h1: "About Zeddy Real Estates",
  image: SITE.defaultOgImage,
  keywords: [...BASE_KEYWORDS, "about Zeddy Real Estates", "real estate agents Kisumu"],
  jsonLd: [
    webPageSchema("About Zeddy Real Estates", "/about", "Trusted property agents in Kisumu, Kenya.", "AboutPage"),
    breadcrumbSchema([
      { name: "Home", path: "/" },
      { name: "About Us", path: "/about" },
    ]),
  ],
  changefreq: "monthly",
  priority: 0.6,
  lastmod: today(),
});

export const contactMeta = (): PageMeta => ({
  path: "/contact",
  title: "Contact Us | Zeddy Real Estates Kisumu – Call 0703 287 361",
  description:
    "Book a site visit or ask about a property. Call or WhatsApp Zeddy Real Estates on 0703 287 361 or email zeddyrealestates@gmail.com. Based in Kisumu, Kenya.",
  h1: "Contact Zeddy Real Estates",
  image: SITE.defaultOgImage,
  keywords: [...BASE_KEYWORDS, "contact real estate agent Kisumu", "book site visit Kisumu"],
  jsonLd: [
    webPageSchema("Contact Zeddy Real Estates", "/contact", "Call, WhatsApp or email our Kisumu team.", "ContactPage"),
    faqSchema(faqs),
    breadcrumbSchema([
      { name: "Home", path: "/" },
      { name: "Contact", path: "/contact" },
    ]),
  ],
  changefreq: "yearly",
  priority: 0.7,
  lastmod: today(),
});

export const sitemapPageMeta = (): PageMeta => ({
  path: "/sitemap",
  title: "Sitemap | Zeddy Real Estates",
  description: "Find every page of the Zeddy Real Estates website – properties, blog articles, company information and contact details.",
  h1: "Sitemap",
  image: SITE.defaultOgImage,
  jsonLd: [
    breadcrumbSchema([
      { name: "Home", path: "/" },
      { name: "Sitemap", path: "/sitemap" },
    ]),
  ],
  changefreq: "monthly",
  priority: 0.3,
  lastmod: today(),
});

export const savedMeta = (): PageMeta => ({
  path: "/saved",
  title: "Saved Properties | Zeddy Real Estates",
  description: "Your shortlisted Zeddy Real Estates properties.",
  h1: "Saved Properties",
  noindex: true,
});

export const notFoundMeta = (): PageMeta => ({
  path: "/404",
  title: "Page Not Found | Zeddy Real Estates",
  description: "Sorry, we could not find the page you were looking for.",
  h1: "Page not found",
  noindex: true,
});

/** Every indexable page – used by the sitemap and pre-render scripts. */
export const getAllPages = (): PageMeta[] => [
  homeMeta(),
  propertiesMeta(),
  ...properties.map(propertyMeta),
  blogIndexMeta(),
  ...blogPosts.map(blogPostMeta),
  aboutMeta(),
  contactMeta(),
  sitemapPageMeta(),
];