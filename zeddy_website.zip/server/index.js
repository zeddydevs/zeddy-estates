import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import multer from 'multer';
import { db } from '../src/db/index.ts';
import { properties, propertyImages, blogPosts, faqs, enquiries, admins } from '../src/db/schema.ts';
import { desc, eq } from 'drizzle-orm';
import bcrypt from 'bcrypt';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const verifyAdmin = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: "Unauthorized. Admin access required." });
    }
    const token = authHeader.split(' ')[1];

    const adminRecord = await db.query.admins.findFirst();
    if (!adminRecord) {
      return res.status(401).json({ error: "No admin account configured." });
    }

    const isMatch = await bcrypt.compare(token, adminRecord.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid session or password." });
    }

    req.admin = adminRecord;
    next();
  } catch (err) {
    console.error("Auth verification error:", err);
    return res.status(401).json({ error: "Authentication failed." });
  }
};

const app = express();
app.use(cors());
app.use(express.json());

// --- MULTER STORAGE CONFIGURATION & FOLDER AUTO-CREATION ---
const uploadDir = path.join(__dirname, '../public/uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + '-' + file.originalname.replace(/\s+/g, '_'));
  },
});
const upload = multer({ storage });

app.use('/uploads', express.static(uploadDir));

// --- UPLOAD API ---
app.post('/api/upload', verifyAdmin, upload.single('image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    res.json({ url: fileUrl });
  } catch (err) {
    console.error("Error uploading file:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- PROPERTIES API (PUBLIC) ---
app.get('/api/properties', async (req, res) => {
  try {
    const data = await db.query.properties.findMany({
      with: { 
        images: { 
          orderBy: (images, { asc }) => [asc(images.displayOrder)] 
        } 
      },
      orderBy: [desc(properties.createdAt)],
    });
    res.json(data);
  } catch (err) {
    console.error("Error fetching properties:", err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/properties/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    const property = await db.query.properties.findFirst({
      where: eq(properties.slug, slug),
      with: {
        images: {
          orderBy: (images, { asc }) => [asc(images.displayOrder)]
        }
      }
    });

    if (!property) {
      return res.status(404).json({ error: "Property not found" });
    }

    res.json(property);
  } catch (err) {
    console.error("Error fetching property by slug:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- PROPERTIES API (PROTECTED ADMIN CRUD) ---
app.post('/api/properties', verifyAdmin, async (req, res) => {
  try {
    const { images, ...propertyData } = req.body;

    const payload = {
      ...propertyData,
      summary: propertyData.summary || propertyData.title || "",
      date_posted: propertyData.date_posted || new Date().toISOString().split('T')[0],
      price: propertyData.price !== null && propertyData.price !== "" ? Number(propertyData.price) : null,
      bedrooms: propertyData.bedrooms !== null && propertyData.bedrooms !== "" ? Number(propertyData.bedrooms) : null,
      bathrooms: propertyData.bathrooms !== null && propertyData.bathrooms !== "" ? Number(propertyData.bathrooms) : null,
    };

    const newProp = await db.insert(properties).values(payload).returning();
    if (!newProp.length) {
      return res.status(500).json({ error: "Failed to create property" });
    }

    const propertyId = newProp[0].id;

    if (Array.isArray(images) && images.length > 0) {
      const imageValues = images.map((img, idx) => ({
        propertyId: propertyId,
        url: typeof img === 'string' ? img : img.url,
        displayOrder: img.displayOrder !== undefined ? img.displayOrder : idx,
      }));
      await db.insert(propertyImages).values(imageValues);
    }

    const fullProperty = await db.query.properties.findFirst({
      where: eq(properties.id, propertyId),
      with: {
        images: {
          orderBy: (images, { asc }) => [asc(images.displayOrder)]
        }
      }
    });

    res.json(fullProperty);
  } catch (err) {
    console.error("Error creating property:", err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/properties/:id', verifyAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { images, ...propertyData } = req.body;

    const payload = {
      ...propertyData,
      summary: propertyData.summary || propertyData.title || "",
      date_posted: propertyData.date_posted || new Date().toISOString().split('T')[0],
      price: propertyData.price !== null && propertyData.price !== "" ? Number(propertyData.price) : null,
      bedrooms: propertyData.bedrooms !== null && propertyData.bedrooms !== "" ? Number(propertyData.bedrooms) : null,
      bathrooms: propertyData.bathrooms !== null && propertyData.bathrooms !== "" ? Number(propertyData.bathrooms) : null,
    };

    const updated = await db.update(properties)
      .set(payload)
      .where(eq(properties.id, id))
      .returning();

    if (!updated.length) {
      return res.status(404).json({ error: "Property not found" });
    }

    if (Array.isArray(images)) {
      await db.delete(propertyImages).where(eq(propertyImages.propertyId, id));

      if (images.length > 0) {
        const imageValues = images.map((img, idx) => ({
          propertyId: Number(id),
          url: typeof img === 'string' ? img : img.url,
          displayOrder: img.displayOrder !== undefined ? img.displayOrder : idx,
        }));
        await db.insert(propertyImages).values(imageValues);
      }
    }

    const fullProperty = await db.query.properties.findFirst({
      where: eq(properties.id, id),
      with: {
        images: {
          orderBy: (images, { asc }) => [asc(images.displayOrder)]
        }
      }
    });

    res.json(fullProperty);
  } catch (err) {
    console.error("Error updating property:", err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/properties/:id', verifyAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    await db.delete(properties).where(eq(properties.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error("Error deleting property:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- BLOG POSTS API (PUBLIC) ---
app.get('/api/blog', async (req, res) => {
  try {
    const data = await db.query.blogPosts.findMany({
      orderBy: [desc(blogPosts.date)],
    });
    res.json(data);
  } catch (err) {
    console.error("Error fetching blog posts:", err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/blog/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    const post = await db.query.blogPosts.findFirst({
      where: eq(blogPosts.slug, slug),
    });

    if (!post) {
      return res.status(404).json({ error: "Blog post not found" });
    }

    res.json(post);
  } catch (err) {
    console.error("Error fetching blog post by slug:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- BLOG POSTS API (PROTECTED ADMIN CRUD) ---
app.post('/api/blog', verifyAdmin, async (req, res) => {
  try {
    const payload = {
      ...req.body,
      category: req.body.category || "Real Estate Market",
      readTime: req.body.readTime || req.body.read_time || "4 min read",
      date: req.body.date || new Date().toISOString().split('T')[0],
      coverImage: req.body.coverImage || req.body.cover_image || req.body.image || "",
      imageAlt: req.body.imageAlt || req.body.image_alt || req.body.title || "",
      tags: Array.isArray(req.body.tags) ? req.body.tags : [],
      contentBlocks: Array.isArray(req.body.contentBlocks) 
        ? req.body.contentBlocks 
        : [{ type: "p", text: req.body.content || "" }],
    };
    delete payload.read_time;
    delete payload.cover_image;
    delete payload.image_alt;
    delete payload.image;
    delete payload.content;

    const newPost = await db.insert(blogPosts).values(payload).returning();
    res.json(newPost[0]);
  } catch (err) {
    console.error("Error creating blog post:", err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/blog/:id', verifyAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const payload = {
      ...req.body,
      category: req.body.category || "Real Estate Market",
      readTime: req.body.readTime || req.body.read_time || "4 min read",
      date: req.body.date || new Date().toISOString().split('T')[0],
      coverImage: req.body.coverImage || req.body.cover_image || req.body.image || "",
      imageAlt: req.body.imageAlt || req.body.image_alt || req.body.title || "",
      tags: Array.isArray(req.body.tags) ? req.body.tags : [],
      contentBlocks: Array.isArray(req.body.contentBlocks) 
        ? req.body.contentBlocks 
        : [{ type: "p", text: req.body.content || "" }],
    };
    delete payload.read_time;
    delete payload.cover_image;
    delete payload.image_alt;
    delete payload.image;
    delete payload.content;

    const updated = await db.update(blogPosts).set(payload).where(eq(blogPosts.id, id)).returning();
    if (!updated.length) return res.status(404).json({ error: "Blog post not found" });
    res.json(updated[0]);
  } catch (err) {
    console.error("Error updating blog post:", err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/blog/:id', verifyAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    await db.delete(blogPosts).where(eq(blogPosts.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error("Error deleting blog post:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- FAQS API ---
app.get('/api/faqs', async (req, res) => {
  try {
    const data = await db.query.faqs.findMany();
    res.json(data);
  } catch (err) {
    console.error("Error fetching FAQs:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- ENQUIRIES / LEADS API ---
app.get('/api/enquiries', async (req, res) => {
  try {
    const data = await db.query.enquiries.findMany({
      orderBy: [desc(enquiries.createdAt)],
    });
    res.json(data);
  } catch (err) {
    console.error("Error fetching enquiries:", err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/enquiries', async (req, res) => {
  try {
    const lead = await db.insert(enquiries).values(req.body).returning();
    res.json(lead[0]);
  } catch (err) {
    console.error("Error creating enquiry:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- ADMIN LOGIN API ---
app.post('/api/admin/login', async (req, res) => {
  try {
    const { password } = req.body;
    if (!password) {
      return res.status(400).json({ error: "Password is required." });
    }

    let adminRecord = await db.query.admins.findFirst();

    if (!adminRecord) {
      const defaultHash = await bcrypt.hash('admin@123', 10);
      const inserted = await db.insert(admins).values({
        email: 'admin@zeddy.co.ke',
        name: 'Zeddy Admin',
        passwordHash: defaultHash,
      }).returning();
      adminRecord = inserted[0];
    }

    const isMatch = await bcrypt.compare(password, adminRecord.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid password." });
    }

    res.json({ success: true, token: password });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- CHANGE ADMIN PASSWORD API ---
app.put('/api/admin/password', verifyAdmin, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: "Current and new passwords are required." });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: "New password must be at least 6 characters long." });
    }

    const adminRecord = await db.query.admins.findFirst();
    if (!adminRecord) {
      return res.status(404).json({ error: "Admin record not found." });
    }

    const isMatch = await bcrypt.compare(currentPassword, adminRecord.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: "Current password is incorrect." });
    }

    const newPasswordHash = await bcrypt.hash(newPassword, 10);
    await db.update(admins)
      .set({ passwordHash: newPasswordHash, updatedAt: new Date() })
      .where(eq(admins.id, adminRecord.id));

    res.json({ success: true, message: "Password updated successfully!" });
  } catch (err) {
    console.error("Error updating admin password:", err);
    res.status(500).json({ error: err.message });
  }
});

// --- PRODUCTION STATIC SERVING ---
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../dist')));
  app.get(/^(?!\/api).+/, (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/index.html'));
  });
}

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 API Server running on http://localhost:${PORT}`);
});