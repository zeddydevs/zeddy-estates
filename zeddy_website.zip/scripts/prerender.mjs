/**
 * Static SEO pre-rendering (run AFTER `npm run build`):
 *
 *   npm run build && node scripts/prerender.mjs
 *
 * For every page it writes dist/<route>/index.html – a copy of the built app whose
 * <title>, meta description, canonical, Open Graph, Twitter tags, JSON-LD and
 * <noscript> content are specific to that page. Search engines and social-media
 * crawlers (WhatsApp, Facebook, X) therefore see the correct preview instantly,
 * even before JavaScript runs. The React app then takes over as normal.
 */
import fs from "node:fs";
import path from "node:path";
import { loadSeo, root } from "./_load.mjs";

const dist = path.join(root, "dist");
const templatePath = path.join(dist, "index.html");
if (!fs.existsSync(templatePath)) {
  console.error("dist/index.html not found – run `npm run build` first.");
  process.exit(1);
}

const { getAllPages, notFoundMeta, savedMeta, SITE, absoluteUrl } = await loadSeo();
const template = fs.readFileSync(templatePath, "utf8");

const escAttr = (s) =>
  String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const escText = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function setMeta(html, attr, key, content) {
  const re = new RegExp(`<meta\\s+[^>]*${attr}="${key}"[^>]*>`, "i");
  if (content === undefined || content === null || content === "") return html.replace(re, () => "");
  const tag = `<meta ${attr}="${key}" content="${escAttr(content)}" />`;
  return re.test(html) ? html.replace(re, () => tag) : html.replace("</head>", () => `${tag}\n</head>`);
}

function setLink(html, rel, href, hreflang) {
  const re = new RegExp(`<link\\s+[^>]*rel="${rel}"[^>]*${hreflang ? `hreflang="${hreflang}"` : ""}[^>]*>`, "i");
  const tag = `<link rel="${rel}"${hreflang ? ` hreflang="${hreflang}"` : ""} href="${escAttr(href)}" />`;
  return re.test(html) ? html.replace(re, () => tag) : html.replace("</head>", () => `${tag}\n</head>`);
}

function render(meta) {
  const url = absoluteUrl(meta.path);
  const image = meta.image ?? SITE.defaultOgImage;
  let html = template;

  html = html.replace(/<title>[\s\S]*?<\/title>/, () => `<title>${escText(meta.title)}</title>`);
  html = setMeta(html, "name", "description", meta.description);
  html = setMeta(html, "name", "keywords", meta.keywords?.join(", "));
  html = setMeta(
    html,
    "name",
    "robots",
    meta.noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
  );
  html = setLink(html, "canonical", url);
  html = setLink(html, "alternate", url, "en-ke");

  html = setMeta(html, "property", "og:type", meta.type === "article" ? "article" : "website");
  html = setMeta(html, "property", "og:url", url);
  html = setMeta(html, "property", "og:title", meta.title);
  html = setMeta(html, "property", "og:description", meta.description);
  html = setMeta(html, "property", "og:image", image);
  html = setMeta(html, "property", "og:image:alt", meta.imageAlt ?? meta.title);
  if (meta.publishedTime) html = setMeta(html, "property", "article:published_time", meta.publishedTime);
  html = setMeta(html, "name", "twitter:title", meta.title);
  html = setMeta(html, "name", "twitter:description", meta.description);
  html = setMeta(html, "name", "twitter:image", image);

  const ld = JSON.stringify(meta.jsonLd && meta.jsonLd.length ? meta.jsonLd : {}).replace(/</g, "\\u003c");
  html = html.replace(
    /<script type="application\/ld\+json" id="page-jsonld">[\s\S]*?<\/script>/,
    () => `<script type="application/ld+json" id="page-jsonld">${ld}</script>`,
  );

  const links = [
    { label: "Home", path: "/" },
    { label: "Properties", path: "/properties" },
    { label: "Blog", path: "/blog" },
    { label: "About us", path: "/about" },
    { label: "Contact", path: "/contact" },
    { label: "Sitemap", path: "/sitemap" },
    ...(meta.links ?? []),
  ];
  const seen = new Set();
  const listItems = links
    .filter((l) => (seen.has(l.path) ? false : seen.add(l.path)))
    .map((l) => `<li><a href="${escAttr(l.path === "/" ? "/" : `${l.path}/`)}">${escText(l.label)}</a></li>`)
    .join("");

  const noscript = `<!--seo-noscript-start-->
    <noscript>
      <main style="font-family: Arial, sans-serif; max-width: 720px; margin: 40px auto; padding: 0 16px; line-height: 1.6">
        <h1>${escText(meta.h1)}</h1>
        <p>${escText(meta.description)}</p>
        <p>Call or WhatsApp <a href="tel:${SITE.phone}">${SITE.phoneDisplay}</a> · <a href="mailto:${SITE.email}">${SITE.email}</a></p>
        <ul>${listItems}</ul>
      </main>
    </noscript>
    <!--seo-noscript-end-->`;
  html = html.replace(/<!--seo-noscript-start-->[\s\S]*?<!--seo-noscript-end-->/, () => noscript);

  return html;
}

let count = 0;
for (const meta of [...getAllPages(), savedMeta()]) {
  if (meta.path === "/") {
    fs.writeFileSync(templatePath, render(meta));
  } else {
    const dir = path.join(dist, ...meta.path.split("/").filter(Boolean));
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, "index.html"), render(meta));
  }
  count++;
}

// 404 page for hosts that support a custom 404.html (GitHub Pages, Netlify, Cloudflare Pages…)
fs.writeFileSync(path.join(dist, "404.html"), render(notFoundMeta()));

console.log(`✔ Pre-rendered ${count} pages + 404.html into dist/`);
