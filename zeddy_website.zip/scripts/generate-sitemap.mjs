/**
 * Generates public/sitemap.xml from the site data (properties + blog posts).
 *
 *   node scripts/generate-sitemap.mjs
 *
 * Run it whenever you add/remove a property or blog post, or change SITE.url.
 */
import fs from "node:fs";
import path from "node:path";
import { loadSeo, root } from "./_load.mjs";

const { getAllPages, absoluteUrl } = await loadSeo();

const esc = (s) =>
  String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");

const pages = getAllPages().filter((p) => !p.noindex);

const urls = pages
  .map((p) => {
    const images = (p.sitemapImages ?? [])
      .map(
        (img) => `
    <image:image>
      <image:loc>${esc(img.src)}</image:loc>
      <image:title>${esc(img.alt)}</image:title>
    </image:image>`,
      )
      .join("");
    return `  <url>
    <loc>${esc(absoluteUrl(p.path))}</loc>
    <lastmod>${p.lastmod ?? new Date().toISOString().slice(0, 10)}</lastmod>
    <changefreq>${p.changefreq ?? "monthly"}</changefreq>
    <priority>${(p.priority ?? 0.5).toFixed(1)}</priority>${images}
  </url>`;
  })
  .join("\n");

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
${urls}
</urlset>
`;

const out = path.join(root, "public", "sitemap.xml");
fs.writeFileSync(out, xml);

// keep robots.txt in sync with the configured domain
const { SITE } = await loadSeo();
const robots = `# Zeddy Real Estates – robots.txt
User-agent: *
Allow: /

# Sitemap (update the domain if you change SITE.url in src/config/site.ts)
Sitemap: ${SITE.url}/sitemap.xml
`;
fs.writeFileSync(path.join(root, "public", "robots.txt"), robots);

console.log(`✔ sitemap.xml written with ${pages.length} URLs → ${path.relative(root, out)}`);
