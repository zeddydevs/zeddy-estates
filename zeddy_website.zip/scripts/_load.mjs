import path from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";

export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

/**
 * Bundles the shared TypeScript SEO/data modules on the fly (esbuild ships with Vite)
 * so the Node scripts and the React app always use exactly the same data.
 */
export async function loadSeo() {
  const result = await build({
    stdin: {
      contents: `
        export * from "./src/seo/meta.ts";
        export { SITE } from "./src/config/site.ts";
        export { properties } from "./src/data/properties.ts";
        export { blogPosts } from "./src/data/blog.ts";
        export { absoluteUrl } from "./src/lib/format.ts";
      `,
      resolveDir: root,
      loader: "ts",
    },
    bundle: true,
    format: "esm",
    platform: "node",
    write: false,
    logLevel: "silent",
  });
  const code = result.outputFiles[0].text;
  return import(`data:text/javascript;base64,${Buffer.from(code).toString("base64")}`);
}
